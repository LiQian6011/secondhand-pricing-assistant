import os, sys, json, re
BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"
os.chdir(BASE)
sys.path.insert(0, BASE)

errors = []

# 1. Check .env
print("=" * 60)
print("1. .env 文件检查")
print("=" * 60)
with open(".env", "r") as f:
    env_content = f.read().strip()
if not env_content:
    errors.append(".env 文件为空！缺少 OPENAI_API_KEY 等配置")
    print("  [FAIL] .env 为空")
else:
    for line in env_content.split("\n"):
        if line.strip() and not line.startswith("#"):
            k = line.split("=")[0].strip()
            print(f"  {k}=***")

# 2. Check CSV encoding
print()
print("=" * 60)
print("2. CSV 数据检查")
print("=" * 60)
csv_path = "app/knowledge/secondhand_data.csv"
with open(csv_path, "r", encoding="utf-8") as f:
    lines = f.readlines()
print(f"  行数: {len(lines)}")
print(f"  表头: {lines[0].strip()[:100]}")
# check for garbled text
sample = lines[1] if len(lines) > 1 else ""
try:
    sample.encode("utf-8").decode("utf-8")
    print(f"  编码: UTF-8 OK")
except:
    errors.append("CSV 编码异常")
    print(f"  [FAIL] 编码异常")

# 3. Check diagnosis.py for encoding issues
print()
print("=" * 60)
print("3. diagnosis.py 编码检查")
print("=" * 60)
with open("app/agents/diagnosis.py", "r", encoding="utf-8") as f:
    diag = f.read()
# check for garbled Chinese
garbled_patterns = ["缁", "鍏", "澶", "鍔", "姣", "瀹"]
found_garbled = [p for p in garbled_patterns if p in diag]
if found_garbled:
    errors.append(f"diagnosis.py 包含乱码字符: {found_garbled}")
    print(f"  [FAIL] 发现乱码: {found_garbled}")
else:
    print("  [OK] 无乱码")

# 4. Check recommend.py for encoding
print()
print("=" * 60)
print("4. recommend.py 编码检查")
print("=" * 60)
with open("app/agents/recommend.py", "r", encoding="utf-8") as f:
    rec = f.read()
found_garbled = [p for p in garbled_patterns if p in rec]
if found_garbled:
    errors.append(f"recommend.py 包含乱码字符: {found_garbled}")
    print(f"  [FAIL] 发现乱码: {found_garbled}")
else:
    print("  [OK] 无乱码")

# 5. Check plan.py for encoding
print()
print("=" * 60)
print("5. plan.py 编码检查")
print("=" * 60)
with open("app/agents/plan.py", "r", encoding="utf-8") as f:
    plan = f.read()
found_garbled = [p for p in garbled_patterns if p in plan]
if found_garbled:
    errors.append(f"plan.py 包含乱码字符: {found_garbled}")
    print(f"  [FAIL] 发现乱码: {found_garbled}")
else:
    print("  [OK] 无乱码")

# 6. Check api.py for encoding
print()
print("=" * 60)
print("6. api.py 编码检查")
print("=" * 60)
with open("app/routes/api.py", "r", encoding="utf-8") as f:
    api = f.read()
found_garbled = [p for p in garbled_patterns if p in api]
if found_garbled:
    errors.append(f"api.py 包含乱码字符: {found_garbled}")
    print(f"  [FAIL] 发现乱码: {found_garbled}")
else:
    print("  [OK] 无乱码")

# 7. Check price_lookup.py for env var names
print()
print("=" * 60)
print("7. price_lookup.py 环境变量检查")
print("=" * 60)
with open("app/tools/price_lookup.py", "r", encoding="utf-8") as f:
    pl = f.read()
# check if it uses correct env var names
if "OPENAI_API_KEY" in pl and "OPENAI_BASE_URL" in pl:
    print("  [OK] 使用 OPENAI_API_KEY / OPENAI_BASE_URL")
else:
    errors.append("price_lookup.py 环境变量名不匹配")
    print("  [FAIL] 环境变量名不匹配")

# 8. Check recommend.py env var names
print()
print("=" * 60)
print("8. recommend.py 环境变量检查")
print("=" * 60)
if "OPENAI_API_KEY" in rec:
    print("  [OK] 使用 OPENAI_API_KEY")
else:
    errors.append("recommend.py 未使用 OPENAI_API_KEY")
    print("  [FAIL] 未使用 OPENAI_API_KEY")

# 9. Check frontend files
print()
print("=" * 60)
print("9. 前端文件检查")
print("=" * 60)
for fn in ["frontend/index.html", "frontend/app.js"]:
    fp = os.path.join(BASE, fn)
    if os.path.exists(fp):
        sz = os.path.getsize(fp)
        print(f"  [OK] {fn} ({sz} bytes)")
    else:
        errors.append(f"{fn} 不存在")
        print(f"  [FAIL] {fn} 不存在")

# 10. Check pyproject.toml
print()
print("=" * 60)
print("10. pyproject.toml 检查")
print("=" * 60)
with open("pyproject.toml", "r") as f:
    toml = f.read()
if "fastapi" in toml and "langchain" in toml.lower():
    print("  [OK] 依赖声明完整")
else:
    errors.append("pyproject.toml 缺少关键依赖")
    print("  [FAIL] 缺少关键依赖")

# Summary
print()
print("=" * 60)
print("总结")
print("=" * 60)
if errors:
    print(f"发现 {len(errors)} 个问题：")
    for i, e in enumerate(errors, 1):
        print(f"  {i}. {e}")
else:
    print("所有检查通过！")