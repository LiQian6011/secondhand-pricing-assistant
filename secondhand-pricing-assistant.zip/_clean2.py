path = "/home/wjx1202/projects/secondhand-pricing-assistant/.env"
with open(path) as f:
    content = f.read()
# Remove duplicate comment line at end
content = content.rstrip()
if content.endswith("# Vision model for image recognition"):
    content = content[:content.rfind("# Vision model for image recognition")].rstrip()
content += "\n# Vision model for image recognition\nVISION_MODEL=glm-4v-flash\n"
with open(path, "w") as f:
    f.write(content)
print("Fixed .env")