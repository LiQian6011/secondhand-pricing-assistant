const { createApp } = Vue;
const API_BASE = window.location.origin + "/api";

const BRAND_MAP = {
    "iphone": "Apple", "ipad": "Apple", "macbook": "Apple", "imac": "Apple",
    "airpods": "Apple", "apple watch": "Apple", "mac mini": "Apple",
    "huawei": "\u534e\u4e3a", "mate": "\u534e\u4e3a", "pura": "\u534e\u4e3a", "nova": "\u534e\u4e3a",
    "xiaomi": "\u5c0f\u7c73", "redmi": "\u5c0f\u7c73", "\u7ea2\u7c73": "\u5c0f\u7c73", "mi ": "\u5c0f\u7c73",
    "oppo": "OPPO", "reno": "OPPO", "find": "OPPO",
    "vivo": "vivo", "iqoo": "vivo",
    "samsung": "\u4e09\u661f", "galaxy": "\u4e09\u661f",
    "nintendo": "Nintendo", "switch": "Nintendo",
    "sony": "Sony", "playstation": "Sony", "ps5": "Sony", "ps4": "Sony",
    "thinkpad": "Lenovo", "lenovo": "Lenovo",
    "asus": "ASUS", "rog": "ASUS",
    "dell": "Dell",
    "surface": "Microsoft",
    "kindle": "Amazon",
};

const MODEL_PATTERNS = [
    { re: /iphone\s*(15\s*pro\s*max|15\s*pro|15\s*plus|15|14\s*pro\s*max|14\s*pro|14\s*plus|14|13\s*pro\s*max|13\s*pro|13\s*mini|13|12\s*pro|12|se\d?|11)/i, prefix: "iPhone " },
    { re: /ipad\s*(pro\s*\d*|air\s*\d*|mini\s*\d*|\d+)/i, prefix: "iPad " },
    { re: /macbook\s*(pro\s*\d*|air\s*\d*)/i, prefix: "MacBook " },
    { re: /switch\s*(oled|lite)?/i, prefix: "Switch " },
    { re: /ps(5|4)/i, prefix: "PS" },
    { re: /mate\s*(60\s*pro|60|50\s*pro|50|40\s*pro|40)/i, prefix: "Mate " },
    { re: /pura\s*(70\s*pro|70)/i, prefix: "Pura " },
    { re: /nova\s*(12\s*pro|12|11)/i, prefix: "Nova " },
    { re: /(\u7ea2\u7c73|redmi)\s*(k60\s*pro|k60|k70\s*pro|k70|note\s*\d+)/i, prefix: "" },
    { re: /thinkpad\s*(x1|t14|t16|e14|p14)/i, prefix: "ThinkPad " },
    { re: /surface\s*(pro\s*\d*|laptop\s*\d*|go)/i, prefix: "Surface " },
    { re: /airpods\s*(pro\s*\d*|max|\d*)/i, prefix: "AirPods " },
    { re: /apple\s*watch\s*(ultra|se|s\d|series\s*\d)/i, prefix: "Apple Watch " },
    { re: /kindle\s*(paperwhite|oasis|voyage)/i, prefix: "Kindle " },
];

const CONDITION_PATTERNS = [
    { re: /\u5168\u65b0/, val: "\u5168\u65b0\u672a\u62c6" },
    { re: /99\u65b0/, val: "99\u65b0" },
    { re: /95\u65b0/, val: "95\u65b0" },
    { re: /9\u6210\u65b0/, val: "9\u6210\u65b0" },
    { re: /85\u65b0/, val: "85\u65b0" },
    { re: /8\u6210\u65b0/, val: "8\u6210\u65b0" },
    { re: /7\u6210\u65b0/, val: "7\u6210\u65b0" },
    { re: /\u5168\u529f\u80fd\u6b63\u5e38/, val: "\u529f\u80fd\u5b8c\u597d" },
    { re: /\u65e0\u62c6\u4fee/, val: "\u65e0\u62c6\u4fee" },
    { re: /\u5728\u4fdd/, val: "\u5728\u4fdd" },
    { re: /\u8f7b\u5fae\u4f7f\u7528\u75d5\u8ff9/, val: "\u8f7b\u5fae\u4f7f\u7528\u75d5\u8ff9" },
    { re: /\u65e0\u5212\u75d5/, val: "\u5c4f\u5e55\u65e0\u5212\u75d5" },
];

function autoParse(text) {
    const source = typeof text === "string" ? text : (text == null ? "" : String(text));
    if (!source || source.length < 3) return { brand: "", model: "", condition: "" };
    const lower = source.toLowerCase();
    let brand = "";
    for (const [key, val] of Object.entries(BRAND_MAP)) {
        if (lower.includes(key)) { brand = val; break; }
    }
    let model = "";
    for (const p of MODEL_PATTERNS) {
        const m = source.match(p.re);
        if (m) { model = (p.prefix + m[1].trim().replace(/\s+/g, " ")).trim(); break; }
    }
    let conditions = [];
    for (const p of CONDITION_PATTERNS) {
        if (p.re.test(source)) { conditions.push(p.val); }
    }
    const condition = conditions.join(" | ");
    return { brand, model, condition };
}

createApp({
    data() {
        return {
            page: "home",
            form: { description: "", brand: "", model: "", condition: "" },
            loading: { diagnosis: false, recommend: false, plan: false },
            result: { diagnosis: null, recommend: null, plan: "" },
            error: null,
            autoFilled: { brand: false, model: false, condition: false },
            debounceTimer: null,
            infoPreview: null,
            appearancePreview: null,
            recognizedInfo: null,
            recognizedAppearance: null,
            recognizingInfo: false,
            recognizingAppearance: false,
        };
    },
    watch: {
        "form.description"(val) {
            clearTimeout(this.debounceTimer);
            this.debounceTimer = setTimeout(() => {
                const parsed = autoParse(val);
                if (parsed.brand && !this.form.brand) {
                    this.form.brand = parsed.brand;
                    this.autoFilled.brand = true;
                    setTimeout(() => { this.autoFilled.brand = false; }, 1500);
                }
                if (parsed.model && !this.form.model) {
                    this.form.model = parsed.model;
                    this.autoFilled.model = true;
                    setTimeout(() => { this.autoFilled.model = false; }, 1500);
                }
                if (parsed.condition && !this.form.condition) {
                    this.form.condition = parsed.condition;
                    this.autoFilled.condition = true;
                    setTimeout(() => { this.autoFilled.condition = false; }, 1500);
                }
            }, 400);
        },
    },
    methods: {
        renderMarkdown(text) {
            if (!text) return "";
            return marked.parse(text);
        },
        renderReport(report) {
            if (!report) return "";
            const text = String(report);
            const lines = text.split('\n');
            const out = [];
            let inTable = false;
            let tableSeen = false;
            for (let i = 0; i < lines.length; i++) {
                const l = lines[i];
                const t = l.trim();
                if (!tableSeen && t.startsWith('|')) {
                    // start of the first table — skip until blank line after table
                    inTable = true;
                    tableSeen = true;
                    continue;
                }
                if (inTable) {
                    if (t === '') {
                        inTable = false;
                    }
                    continue;
                }
                out.push(l);
            }
            return out.join('\n');
        },
        reAutoParse() {
            const parsed = autoParse(this.form.description);
            if (parsed.brand) this.form.brand = parsed.brand;
            if (parsed.model) this.form.model = parsed.model;
            if (parsed.condition) this.form.condition = parsed.condition;
            this.autoFilled.brand = !!parsed.brand;
            this.autoFilled.model = !!parsed.model;
            this.autoFilled.condition = !!parsed.condition;
            setTimeout(() => {
                this.autoFilled.brand = false;
                this.autoFilled.model = false;
                this.autoFilled.condition = false;
            }, 1500);
        },
        composeRecognizedDescription() {
            const normalizeText = (value) => {
                if (!value && value !== 0) return "";
                if (typeof value === "string") return value.trim();
                if (Array.isArray(value)) {
                    return value.map(normalizeText).filter(Boolean).join("；");
                }
                if (typeof value === "object") {
                    return Object.entries(value)
                        .map(([key, val]) => {
                            const text = normalizeText(val);
                            return text ? `${key}：${text}` : "";
                        })
                        .filter(Boolean)
                        .join("；");
                }
                return String(value);
            };

            const info = this.recognizedInfo || {};
            const appearance = this.recognizedAppearance || {};
            const parts = [];
            const brand = this.form.brand || info.brand || "";
            const model = this.form.model || info.model || "";
            const condition = this.form.condition || appearance.condition || "";

            if (brand) parts.push(`品牌：${brand}`);
            if (model) parts.push(`型号：${model}`);
            if (condition) parts.push(`成色：${condition}`);

            const infoText = normalizeText(info.description);
            const appearanceText = normalizeText(appearance.details);
            if (infoText) parts.push(`设备信息：${infoText}`);
            if (appearanceText) parts.push(`外观信息：${appearanceText}`);

            if (parts.length > 0) {
                this.form.description = parts.join("；");
            }
        },
        async uploadInfoImage(event) {
            const file = event.target.files[0];
            if (!file) return;
            if (!file.type.startsWith("image/")) { this.error = "\u8bf7\u4e0a\u4f20\u56fe\u7247\u6587\u4ef6"; return; }
            this.infoPreview = URL.createObjectURL(file);
            this.recognizingInfo = true;
            this.error = null;
            try {
                const formData = new FormData();
                formData.append("file", file);
                const res = await fetch(API_BASE + "/recognize-info", { method: "POST", body: formData });
                const data = await res.json();
                if (data.success) {
                    this.recognizedInfo = data;
                    if (data.description) this.form.description = data.description;
                    if (data.brand) this.form.brand = data.brand;
                    if (data.model) this.form.model = data.model;
                    this.composeRecognizedDescription();
                    this.autoFilled.brand = !!data.brand;
                    this.autoFilled.model = !!data.model;
                    setTimeout(() => { this.autoFilled.brand = false; this.autoFilled.model = false; }, 2000);
                } else { this.error = data.message || "\u4fe1\u606f\u8bc6\u522b\u5931\u8d25"; }
            } catch (e) { this.error = "\u4fe1\u606f\u8bc6\u522b\u5931\u8d25\uff1a" + e.message; }
            this.recognizingInfo = false;
        },
        async uploadAppearanceImage(event) {
            const file = event.target.files[0];
            if (!file) return;
            if (!file.type.startsWith("image/")) { this.error = "\u8bf7\u4e0a\u4f20\u56fe\u7247\u6587\u4ef6"; return; }
            this.appearancePreview = URL.createObjectURL(file);
            this.recognizingAppearance = true;
            this.error = null;
            try {
                const formData = new FormData();
                formData.append("file", file);
                const res = await fetch(API_BASE + "/recognize-appearance", { method: "POST", body: formData });
                const data = await res.json();
                if (data.success) {
                    this.recognizedAppearance = data;
                    if (data.condition) this.form.condition = data.condition;
                    this.composeRecognizedDescription();
                    this.autoFilled.condition = !!data.condition;
                    setTimeout(() => { this.autoFilled.condition = false; }, 2000);
                } else { this.error = data.message || "\u5916\u89c2\u8bc6\u522b\u5931\u8d25"; }
            } catch (e) { this.error = "\u5916\u89c2\u8bc6\u522b\u5931\u8d25\uff1a" + e.message; }
            this.recognizingAppearance = false;
        },
        clearInfoImage() {
            this.infoPreview = null;
            const input = document.getElementById("info-image-input");
            if (input) input.value = "";
        },
        clearAppearanceImage() {
            this.appearancePreview = null;
            const input = document.getElementById("appearance-image-input");
            if (input) input.value = "";
        },
        go(target) {
            this.error = null;
            if (target === "diagnosis") {
                this.page = "diagnosis";
                if (this.form.description && !this.result.diagnosis) {
                    this.runDiagnosis();
                }
            } else if (target === "recommend") {
                this.page = "recommend";
                if (this.form.description && !this.result.recommend) {
                    this.runRecommend();
                }
            } else if (target === "plan") {
                this.page = "plan";
                if (this.form.description && !this.result.recommend) {
                    this.runRecommend().then(() => {
                        if (!this.result.plan) this.runPlan();
                    });
                } else if (this.form.description && !this.result.plan) {
                    this.runPlan();
                }
            } else {
                this.page = "home";
            }
        },
        async runDiagnosis() {
            this.loading.diagnosis = true;
            this.error = null;
            try {
                const res = await fetch(API_BASE + "/diagnose", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(this.form),
                });
                const data = await res.json();
                if (data.success) { this.result.diagnosis = data; }
                else { this.error = data.message || "\u8bca\u65ad\u5931\u8d25"; }
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.diagnosis = false;
        },
        async runRecommend() {
            this.loading.recommend = true;
            this.error = null;
            try {
                const payload = Object.assign({}, this.form);
                if (this.result.diagnosis) { payload.diagnosis = this.result.diagnosis.data; }
                const res = await fetch(API_BASE + "/recommend", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload),
                });
                const data = await res.json();
                if (data.success) {
                    this.result.recommend = data;
                    if (data.diagnosis && !this.result.diagnosis) { this.result.diagnosis = { data: data.diagnosis, report: "" }; }
                } else { this.error = data.message || "\u63a8\u8350\u5931\u8d25"; }
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.recommend = false;
        },
        async runPlan() {
            this.loading.plan = true;
            this.error = null;
            this.result.plan = "";
            try {
                const payload = Object.assign({}, this.form);
                if (this.result.recommend && Array.isArray(this.result.recommend.recommendations)) {
                    payload.platform_data = this.result.recommend.recommendations
                        .map(item => `${item.name}：${item.price_range}`)
                        .join("\n");
                }
                const res = await fetch(API_BASE + "/generate-plan", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload),
                });
                const reader = res.body.getReader();
                const decoder = new TextDecoder();
                let buffer = "";
                let currentEvent = "";
                let currentData = "";
                let fullText = "";
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split("\n");
                    buffer = lines.pop();
                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (trimmed.startsWith("event:")) {
                            currentEvent = trimmed.slice(6).trim();
                            currentData = "";
                        } else if (trimmed.startsWith("data:")) {
                            currentData += (currentData ? "\n" : "") + trimmed.slice(5).trim();
                        } else if (trimmed === "") {
                            if (currentEvent === "delta" && currentData) {
                                fullText += currentData;
                            } else if (currentEvent === "end" && currentData) {
                                fullText = currentData;
                            }
                            currentEvent = "";
                            currentData = "";
                        }
                    }
                }
                if (currentEvent === "delta" && currentData) { fullText += currentData; }
                else if (currentEvent === "end" && currentData) { fullText = currentData; }
                this.result.plan = fullText;
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.plan = false;
        },
    },
}).mount("#app");
