path = "/home/wjx1202/projects/secondhand-pricing-assistant/.env"
with open(path, "a") as f:
    f.write("\n# Vision model for image recognition\nVISION_MODEL=glm-4v-flash\n")
print("VISION_MODEL added to .env")