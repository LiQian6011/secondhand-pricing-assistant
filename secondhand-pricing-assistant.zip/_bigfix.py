import os

BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"

def write(rel_path, content):
    path = os.path.join(BASE, rel_path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: {rel_path}")

# ===== plan.py =====
write("app/agents/plan.py", 'import os\nfrom typing import AsyncGenerator\nfrom langchain_openai import ChatOpenAI\nfrom langchain_core.messages import SystemMessage, HumanMessage\n\nSYSTEM_PROMPT = (\n    "\u4f60\u662f\u4e00\u4f4d\u8d44\u6df1\u4e8c\u624b3C\u4ea7\u54c1\u8425\u9500\u987e\u95ee\uff0c\u7cbe\u901a\u5404\u54c1\u724c\u6570\u7801\u4ea7\u54c1\u7684\u5e02\u573a\u884c\u60c5\u3001\u6298\u65e7\u89c4\u5f8b\u4e0e\u4ea4\u6613\u6280\u5de7\u3002"\n    "\u4f60\u7684\u4efb\u52a1\u662f\u6839\u636e\u7528\u6237\u63d0\u4f9b\u7684\u7269\u54c1\u4fe1\u606f\uff0c\u751f\u6210\u4e00\u4efd\u4e13\u4e1a\u3001\u53ef\u6267\u884c\u7684\u5b9a\u4ef7\u7b56\u7565\u4e0e\u9500\u552e\u65b9\u6848\u3002"\n    "\u8bed\u6c14\u8981\u6c42\uff1a\u4e13\u4e1a\u3001\u53ef\u4fe1\u3001\u6709\u884c\u52a8\u529b\u3002"\n)\n\nUSER_PROMPT_TEMPLATE = (\n    "\u8bf7\u6839\u636e\u4ee5\u4e0b\u7269\u54c1\u4fe1\u606f\u751f\u6210\u5b8c\u6574\u7684\u5b9a\u4ef7\u7b56\u7565\u4e0e\u9500\u552e\u65b9\u6848\uff1a\\n\\n"\n    "**\u7269\u54c1\u4fe1\u606f**\\n"\n    "- \u7269\u54c1\u63cf\u8ff0\uff1a{description}\\n"\n    "- \u54c1\u724c\uff1a{brand}\\n"\n    "- \u578b\u53f7\uff1a{model}\\n"\n    "- \u6210\u8272\u8bc4\u7ea7\uff1a{condition}\\n\\n"\n    "**\u65b9\u6848\u7ed3\u6784\u8981\u6c42**\\n"\n    "1. **\u5b9a\u4ef7\u7b56\u7565**\uff1a\u57fa\u4e8e\u6210\u8272\u548c\u5f53\u524d\u5e02\u573a\u884c\u60c5\uff0c\u7ed9\u51fa\u5177\u4f53\u5efa\u8bae\u552e\u4ef7\uff0c\u5e76\u8bf4\u660e\u5b9a\u4ef7\u903b\u8f91\u3002\\n"\n    "2. **\u5546\u54c1\u6587\u6848\uff08\u5356\u70b9\u63d0\u70bc\uff09**\uff1a\u64b0\u5199\u7ea6100\u5b57\u5546\u54c1\u63cf\u8ff0\uff0c\u7a81\u51fa\u6838\u5fc3\u5356\u70b9\u3002\\n"\n    "3. **\u4ea4\u6613\u5efa\u8bae**\uff1a\u7ed9\u51fa\u4ea4\u6613\u65f6\u7684\u6ce8\u610f\u4e8b\u9879\u3002\\n"\n    "4. **\u9884\u671f\u6210\u4ea4\u5468\u671f**\uff1a\u9884\u4f30\u5728\u5408\u7406\u5b9a\u4ef7\u4e0b\uff0c\u5927\u6982\u591a\u4e45\u80fd\u5356\u51fa\u3002\\n"\n)\n\n\nasync def generate_plan_stream(\n    description: str,\n    brand: str,\n    model: str,\n    condition: str,\n) -> AsyncGenerator[dict, None]:\n    llm = ChatOpenAI(\n        model=os.getenv("OPENAI_MODEL", "glm-4-flash"),\n        temperature=0.7,\n        api_key=os.getenv("OPENAI_API_KEY", ""),\n        base_url=os.getenv("OPENAI_BASE_URL", ""),\n    )\n    messages = [\n        SystemMessage(content=SYSTEM_PROMPT),\n        HumanMessage(\n            content=USER_PROMPT_TEMPLATE.format(\n                description=description,\n                brand=brand,\n                model=model,\n                condition=condition,\n            )\n        ),\n    ]\n    full_text = ""\n    try:\n        async for chunk in llm.astream(messages):\n            delta = chunk.content or ""\n            if delta:\n                full_text += delta\n                yield {"event": "delta", "data": delta}\n    except Exception as e:\n        yield {"event": "error", "data": f"\u751f\u6210\u5931\u8d25: {e}"}\n        return\n    yield {"event": "end", "data": full_text}\n')

# ===== api.py =====
write("app/routes/api.py", 'from fastapi import APIRouter, Request\nfrom pydantic import BaseModel\nfrom typing import Optional\nfrom app.agents.diagnosis import DiagnosisAgent\nfrom app.agents.recommend import RecommendAgent\nfrom app.agents.plan import generate_plan_stream\nfrom app.tools.price_lookup import get_price_lookup_tool\n\nrouter = APIRouter(prefix="/api", tags=["secondhand"])\n\n\nclass DiagnosisRequest(BaseModel):\n    description: str\n    brand: Optional[str] = ""\n    model: Optional[str] = ""\n    condition: Optional[str] = ""\n\n\nclass RecommendRequest(BaseModel):\n    description: str\n    brand: Optional[str] = ""\n    model: Optional[str] = ""\n    condition: Optional[str] = ""\n    diagnosis: Optional[dict] = None\n\n\nclass PlanRequest(BaseModel):\n    description: str\n    brand: Optional[str] = ""\n    model: Optional[str] = ""\n    condition: Optional[str] = ""\n\n\nclass PriceLookupRequest(BaseModel):\n    query: str\n\n\n@router.post("/diagnose", summary="\u7269\u54c1\u6210\u8272\u8bca\u65ad")\nasync def diagnose_item(request: DiagnosisRequest):\n    agent = DiagnosisAgent(\n        description=request.description,\n        brand=request.brand or "",\n        model=request.model or "",\n        condition=request.condition or "",\n    )\n    result = agent.diagnose()\n    return {\n        "success": True,\n        "data": result.to_dict(),\n        "report": agent.generate_report(),\n    }\n\n\n@router.post("/recommend", summary="\u4ea4\u6613\u5e73\u53f0\u63a8\u8350\uff08Top-3\uff09")\nasync def recommend_platforms(request: RecommendRequest):\n    from app.knowledge.vector_store import get_vector_store\n\n    diagnosis = request.diagnosis\n    if not diagnosis:\n        diag_agent = DiagnosisAgent(\n            description=request.description,\n            brand=request.brand or "",\n            model=request.model or "",\n            condition=request.condition or "",\n        )\n        diagnosis = diag_agent.diagnose().to_dict()\n\n    knowledge_results = []\n    try:\n        vector_store = get_vector_store()\n        query = f"{request.brand} {request.model} {request.description}".strip()\n        knowledge_results = vector_store.search(query, top_k=3)\n    except Exception as e:\n        print(f"\u5411\u91cf\u68c0\u7d22\u5931\u8d25: {e}")\n\n    agent = RecommendAgent(\n        description=request.description,\n        brand=request.brand or "",\n        model=request.model or "",\n        condition=request.condition or "",\n        diagnosis_result=diagnosis,\n        knowledge_results=knowledge_results,\n    )\n    recs = agent.recommend()\n    return {\n        "success": True,\n        "diagnosis": diagnosis,\n        "knowledge_references": [\n            {"document": r.get("document", ""), "metadata": r.get("metadata", {})}\n            for r in knowledge_results\n        ],\n        "recommendations": [\n            {"rank": r.rank, "name": r.name, "reason": r.reason, "price_range": r.price_range}\n            for r in recs\n        ],\n        "report": agent.generate_report(),\n    }\n\n\n@router.post("/generate-plan", summary="\u5b9a\u4ef7\u7b56\u7565\u65b9\u6848\u751f\u6210\uff08SSE\u6d41\u5f0f\uff09")\nasync def generate_plan_endpoint(request: Request, plan_request: PlanRequest):\n    from sse_starlette.sse import EventSourceResponse\n\n    async def event_generator():\n        async for event in generate_plan_stream(\n            description=plan_request.description,\n            brand=plan_request.brand or "",\n            model=plan_request.model or "",\n            condition=plan_request.condition or "",\n        ):\n            if await request.is_disconnected():\n                break\n            yield event\n\n    return EventSourceResponse(event_generator(), media_type="text/event-stream")\n\n\n@router.post("/price-lookup", summary="\u67e5\u8be2\u4e8c\u624b\u5e02\u573a\u53c2\u8003\u4ef7")\nasync def price_lookup(request: PriceLookupRequest):\n    tool = get_price_lookup_tool()\n    result = tool._run(request.query)\n    return {"success": True, "query": request.query, "price": result}\n\n\n@router.get("/health", summary="\u5065\u5eb7\u68c0\u67e5")\nasync def health_check():\n    return {"status": "ok", "service": "secondhand-pricing-assistant"}\n')

# ===== app.js =====
write("frontend/app.js", """const { createApp } = Vue;
const API_BASE = window.location.origin + "/api";

createApp({
    data() {
        return {
            form: { description: "", brand: "", model: "", condition: "" },
            loading: { diagnosis: false, recommend: false, plan: false },
            result: { diagnosis: null, recommend: null, plan: "" },
            error: null,
        };
    },
    methods: {
        renderMarkdown(text) {
            if (!text) return "";
            return marked.parse(text);
        },
        async runDiagnosis() {
            this.loading.diagnosis = true;
            this.error = null;
            try {
                const res = await fetch(API_BASE + "/diagnose", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(this.form),
                });
                const data = await res.json();
                if (data.success) { this.result.diagnosis = data; }
                else { this.error = data.message || "\u8bca\u65ad\u5931\u8d25"; }
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.diagnosis = false;
        },
        async runRecommend() {
            this.loading.recommend = true;
            this.error = null;
            try {
                const payload = Object.assign({}, this.form);
                if (this.result.diagnosis) { payload.diagnosis = this.result.diagnosis.data; }
                const res = await fetch(API_BASE + "/recommend", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload),
                });
                const data = await res.json();
                if (data.success) {
                    this.result.recommend = data;
                    if (data.diagnosis) { this.result.diagnosis = { data: data.diagnosis, report: "" }; }
                } else { this.error = data.message || "\u63a8\u8350\u5931\u8d25"; }
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.recommend = false;
        },
        async runPlan() {
            this.loading.plan = true;
            this.error = null;
            this.result.plan = "";
            try {
                const res = await fetch(API_BASE + "/generate-plan", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(this.form),
                });
                const reader = res.body.getReader();
                const decoder = new TextDecoder();
                let buffer = "";
                let currentEvent = "";
                let currentData = "";
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split("\\n");
                    buffer = lines.pop();
                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (trimmed.startsWith("event:")) {
                            currentEvent = trimmed.slice(6).trim();
                            currentData = "";
                        } else if (trimmed.startsWith("data:")) {
                            currentData += (currentData ? "\\n" : "") + trimmed.slice(5).trim();
                        } else if (trimmed === "") {
                            if (currentEvent === "delta" && currentData) {
                                this.result.plan += currentData;
                            } else if (currentEvent === "end" && currentData) {
                                this.result.plan = currentData;
                            }
                            currentEvent = "";
                            currentData = "";
                        }
                    }
                }
                if (currentEvent === "delta" && currentData) { this.result.plan += currentData; }
                else if (currentEvent === "end" && currentData) { this.result.plan = currentData; }
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.plan = false;
        },
    },
}).mount("#app");
""")

# ===== index.html =====
write("frontend/index.html", """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>\u4e8c\u624b\u95f2\u7f6e\u5b9a\u4ef7\u667a\u80fd\u52a9\u624b</title>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh;padding:20px}
.container{max-width:900px;margin:0 auto;background:#fff;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,0.3);overflow:hidden}
.header{background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);color:#fff;padding:30px;text-align:center}
.header h1{font-size:28px;margin-bottom:8px}
.header p{opacity:0.9;font-size:14px}
.content{padding:30px}
.form-group{margin-bottom:20px}
.form-group label{display:block;margin-bottom:8px;font-weight:600;color:#333}
.form-group input,.form-group textarea{width:100%;padding:12px 16px;border:2px solid #e0e0e0;border-radius:8px;font-size:14px;transition:border-color 0.3s}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:#667eea}
.form-group textarea{min-height:100px;resize:vertical}
.row{display:flex;gap:16px}
.row .form-group{flex:1}
.btn-group{display:flex;gap:12px;margin-top:24px;flex-wrap:wrap}
.btn{flex:1;min-width:140px;padding:14px 24px;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;transition:all 0.3s;color:#fff}
.btn-diagnosis{background:#667eea}.btn-diagnosis:hover{background:#5a6fd6;transform:translateY(-2px)}
.btn-recommend{background:#764ba2}.btn-recommend:hover{background:#6a4190;transform:translateY(-2px)}
.btn-plan{background:linear-gradient(135deg,#f093fb 0%,#f5576c 100%)}.btn-plan:hover{transform:translateY(-2px)}
.btn:disabled{opacity:0.6;cursor:not-allowed;transform:none!important}
.result{margin-top:30px;padding:24px;background:#f8f9fa;border-radius:12px;border-left:4px solid #667eea}
.result h3{margin-bottom:16px;color:#333}
.result table{width:100%;border-collapse:collapse;margin:16px 0;background:#fff;border-radius:8px;overflow:hidden}
.result th,.result td{padding:12px 16px;text-align:left;border-bottom:1px solid #e0e0e0}
.result th{background:#667eea;color:#fff;font-weight:600}
.result tr:hover{background:#f5f5f5}
.loading{text-align:center;padding:40px;color:#667eea}
.plan-content{line-height:1.8;color:#444}
.error{color:#e74c3c;padding:16px;background:#fdf2f2;border-radius:8px;margin-top:16px}
</style>
</head>
<body>
<div id="app">
<div class="container">
<div class="header">
<h1>\u2709\ufe0f \u4e8c\u624b\u95f2\u7f6e\u5b9a\u4ef7\u667a\u80fd\u52a9\u624b</h1>
<p>AI \u9a71\u52a8\u7684\u6210\u8272\u8bca\u65ad \u2022 \u5e73\u53f0\u63a8\u8350 \u2022 \u5b9a\u4ef7\u7b56\u7565\u751f\u6210</p>
</div>
<div class="content">
<div class="form-group">
<label>\u7269\u54c1\u63cf\u8ff0</label>
<textarea v-model="form.description" placeholder="\u8bf7\u8be6\u7ec6\u63cf\u8ff0\u7269\u54c1\u72b6\u51b5\uff0c\u4f8b\u5982\uff1aiPhone 14 Pro 256G \u56fd\u884c \u5728\u4fdd3\u4e2a\u6708 \u7535\u6c60\u5065\u5eb792% \u5916\u89c2\u65e0\u5212\u75d5 \u529f\u80fd\u6b63\u5e38 \u7bb1\u8bf4\u5168"></textarea>
</div>
<div class="row">
<div class="form-group"><label>\u54c1\u724c</label><input v-model="form.brand" placeholder="\u5982\uff1aApple\u3001\u534e\u4e3a\u3001\u5c0f\u7c73"></div>
<div class="form-group"><label>\u578b\u53f7</label><input v-model="form.model" placeholder="\u5982\uff1aiPhone 14 Pro"></div>
</div>
<div class="form-group"><label>\u6210\u8272\u8865\u5145</label><input v-model="form.condition" placeholder="\u8865\u5145\u6210\u8272\u4fe1\u606f\uff0c\u5982\uff1a99\u65b0\u3001\u8f7b\u5fae\u5212\u75d5\u3001\u65e0\u62c6\u4fee"></div>
<div class="btn-group">
<button class="btn btn-diagnosis" @click="runDiagnosis" :disabled="loading.diagnosis">{{ loading.diagnosis ? '\u8bca\u65ad\u4e2d...' : '\u6210\u8272\u8bca\u65ad' }}</button>
<button class="btn btn-recommend" @click="runRecommend" :disabled="loading.recommend">{{ loading.recommend ? '\u63a8\u8350\u4e2d...' : '\u5e73\u53f0\u63a8\u8350' }}</button>
<button class="btn btn-plan" @click="runPlan" :disabled="loading.plan">{{ loading.plan ? '\u751f\u6210\u4e2d...' : '\u5b9a\u4ef7\u7b56\u7565' }}</button>
</div>
<div v-if="result.diagnosis" class="result">
<h3>\u6210\u8272\u8bca\u65ad\u62a5\u544a</h3>
<div v-html="renderMarkdown(result.diagnosis.report)"></div>
</div>
<div v-if="result.recommend" class="result">
<h3>\u4ea4\u6613\u5e73\u53f0\u63a8\u8350</h3>
<div v-html="renderMarkdown(result.recommend.report)"></div>
</div>
<div v-if="result.plan || loading.plan" class="result">
<h3>\u5b9a\u4ef7\u7b56\u7565\u65b9\u6848</h3>
<div v-if="loading.plan && !result.plan" class="loading">\u6b63\u5728\u751f\u6210\u65b9\u6848...</div>
<div v-if="result.plan" class="plan-content" v-html="renderMarkdown(result.plan)"></div>
</div>
<div v-if="error" class="error">{{ error }}</div>
</div>
</div>
</div>
<script src="/static/app.js"></script>
</body>
</html>
""")

# Verify all
files = ["app/agents/plan.py", "app/routes/api.py", "frontend/app.js", "frontend/index.html"]
for f in files:
    path = os.path.join(BASE, f)
    content = open(path, encoding="utf-8").read()
    if f.endswith(".py"):
        try:
            compile(content, f, "exec")
            print(f"VERIFY {f}: OK")
        except SyntaxError as e:
            print(f"VERIFY {f}: FAIL - {e}")
    else:
        print(f"VERIFY {f}: {len(content)} chars written")

print("\nAll done!")