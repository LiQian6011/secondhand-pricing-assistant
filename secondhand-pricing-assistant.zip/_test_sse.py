import os, json, requests
from dotenv import load_dotenv
load_dotenv()

BASE = "http://localhost:8000/api"

print("=== 测试 SSE 流式 ===")
r = requests.post(BASE + "/generate-plan", json={
    "description": "iPhone 14 Pro 256G 国行",
    "brand": "Apple",
    "model": "iPhone 14 Pro",
    "condition": "99新",
}, stream=True, timeout=30)

print("Status:", r.status_code)
print("Headers:", dict(r.headers))
print()
for line in r.iter_lines(decode_unicode=True):
    print("LINE:", line)