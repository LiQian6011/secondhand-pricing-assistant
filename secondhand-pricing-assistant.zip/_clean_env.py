path = "/home/wjx1202/projects/secondhand-pricing-assistant/.env"
with open(path) as f:
    lines = f.readlines()
seen = set()
result = []
for line in lines:
    key = line.split("=")[0].strip() if "=" in line and not line.strip().startswith("#") else ""
    if key and key in seen:
        continue
    if key:
        seen.add(key)
    result.append(line)
with open(path, "w") as f:
    f.writelines(result)
print("Cleaned .env")