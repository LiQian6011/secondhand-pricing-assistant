from fastapi import APIRouter, Request, UploadFile, File
from pydantic import BaseModel
from typing import Optional
from app.agents.diagnosis import DiagnosisAgent
from app.agents.recommend import RecommendAgent
from app.agents.plan import generate_plan_stream
from app.agents.recognizer import recognize_info_image, recognize_appearance_image
from app.tools.price_lookup import get_price_lookup_tool

router = APIRouter(prefix="/api", tags=["secondhand"])


class DiagnosisRequest(BaseModel):
    description: str
    brand: Optional[str] = ""
    model: Optional[str] = ""
    condition: Optional[str] = ""
    platform_data: Optional[str] = ""


class RecommendRequest(BaseModel):
    description: str
    brand: Optional[str] = ""
    model: Optional[str] = ""
    condition: Optional[str] = ""
    platform_data: Optional[str] = ""
    diagnosis: Optional[dict] = None


class PlanRequest(BaseModel):
    description: str
    brand: Optional[str] = ""
    model: Optional[str] = ""
    condition: Optional[str] = ""
    platform_data: Optional[str] = ""


class PriceLookupRequest(BaseModel):
    query: str


@router.post("/diagnose", summary="物品成色诊断")
async def diagnose_item(request: DiagnosisRequest):
    agent = DiagnosisAgent(
        description=request.description,
        brand=request.brand or "",
        model=request.model or "",
        condition=request.condition or "",
    )
    result = agent.diagnose()
    return {
        "success": True,
        "data": result.to_dict(),
        "report": agent.generate_report(),
    }


@router.post("/recommend", summary="交易平台推荐（Top-3）")
async def recommend_platforms(request: RecommendRequest):
    from app.knowledge.vector_store import get_vector_store

    diagnosis = request.diagnosis
    if not diagnosis:
        diag_agent = DiagnosisAgent(
            description=request.description,
            brand=request.brand or "",
            model=request.model or "",
            condition=request.condition or "",
        )
        diagnosis = diag_agent.diagnose().to_dict()

    knowledge_results = []
    try:
        vector_store = get_vector_store()
        query = f"{request.brand} {request.model} {request.description}".strip()
        knowledge_results = vector_store.search(query, top_k=3)
    except Exception as e:
        print(f"向量检索失败: {e}")

    agent = RecommendAgent(
        description=request.description,
        brand=request.brand or "",
        model=request.model or "",
        condition=request.condition or "",
        diagnosis_result=diagnosis,
        knowledge_results=knowledge_results,
    )
    recs = agent.recommend()
    # API 层保底：若后端推荐项不足 3 个，使用选定平台和估算价补足
    if len(recs) < 3:
        try:
            selected = agent._select_platforms()
            est_low, est_high = agent._estimate_price()
            for name, profile in selected:
                if any(r.name == name for r in recs):
                    continue
                ratio = profile.get("price_ratio", (0.8, 1.0))
                low = max(200, int(est_low * ratio[0]))
                high = min(15000, int(est_high * ratio[1]))
                recs.append(type(recs[0])(**{ "rank": len(recs) + 1, "name": name, "reason": agent._build_reason(name, profile, agent._infer_category(), False), "price_range": f"{low}-{high}元" }))
                if len(recs) >= 3:
                    break
        except Exception:
            pass
    return {
        "success": True,
        "diagnosis": diagnosis,
        "knowledge_references": [
            {"document": r.get("document", ""), "metadata": r.get("metadata", {})}
            for r in knowledge_results
        ],
        "recommendations": [
            {"rank": r.rank, "name": r.name, "reason": r.reason, "price_range": r.price_range}
            for r in recs
        ],
        "report": agent.generate_report(),
    }


@router.post("/generate-plan", summary="定价策略方案生成（SSE流式）")
async def generate_plan_endpoint(request: Request, plan_request: PlanRequest):
    from sse_starlette.sse import EventSourceResponse

    platform_data = plan_request.platform_data or ""
    if not platform_data:
        try:
            from app.agents.diagnosis import DiagnosisAgent
            from app.agents.recommend import RecommendAgent

            diagnosis = DiagnosisAgent(
                description=plan_request.description,
                brand=plan_request.brand or "",
                model=plan_request.model or "",
                condition=plan_request.condition or "",
            ).diagnose().to_dict()
            knowledge_results = []
            try:
                from app.knowledge.vector_store import get_vector_store
                vector_store = get_vector_store()
                query = f"{plan_request.brand} {plan_request.model} {plan_request.description}".strip()
                knowledge_results = vector_store.search(query, top_k=3)
            except Exception:
                knowledge_results = []
            recs = RecommendAgent(
                description=plan_request.description,
                brand=plan_request.brand or "",
                model=plan_request.model or "",
                condition=plan_request.condition or "",
                diagnosis_result=diagnosis,
                knowledge_results=knowledge_results,
            ).recommend()
            platform_data = "\n".join(f"{r.name}：{r.price_range}" for r in recs)
        except Exception as exc:
            print(f"生成定价策略平台数据失败: {exc}")
            platform_data = ""

    async def event_generator():
        async for event in generate_plan_stream(
            description=plan_request.description,
            brand=plan_request.brand or "",
            model=plan_request.model or "",
            condition=plan_request.condition or "",
            platform_data=platform_data,
        ):
            if await request.is_disconnected():
                break
            yield event

    return EventSourceResponse(event_generator(), media_type="text/event-stream")


@router.post("/recognize-info", summary="设备信息截图识别")
async def recognize_info_endpoint(file: UploadFile = File(...)):
    image_bytes = await file.read()
    if len(image_bytes) > 10 * 1024 * 1024:
        return {"success": False, "message": "图片大小超过10MB限制"}
    result = recognize_info_image(image_bytes, file.filename or "")
    return result


@router.post("/recognize-appearance", summary="设备外观照片识别")
async def recognize_appearance_endpoint(file: UploadFile = File(...)):
    image_bytes = await file.read()
    if len(image_bytes) > 10 * 1024 * 1024:
        return {"success": False, "message": "图片大小超过10MB限制"}
    result = recognize_appearance_image(image_bytes, file.filename or "")
    return result


@router.post("/price-lookup", summary="查询二手市场参考价")
async def price_lookup(request: PriceLookupRequest):
    tool = get_price_lookup_tool()
    result = tool._run(request.query)
    return {"success": True, "query": request.query, "price": result}


@router.get("/health", summary="健康检查")
async def health_check():
    return {"status": "ok", "service": "secondhand-pricing-assistant"}
