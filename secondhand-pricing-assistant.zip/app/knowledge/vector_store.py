import os
import csv
import re
from typing import List, Dict, Optional, Tuple


class SecondhandVectorStore:
    def __init__(
        self,
        csv_path: Optional[str] = None,
        collection_name: str = "secondhand_knowledge",
        persist_directory: Optional[str] = None,
    ):
        self.csv_path = csv_path or os.path.join(
            os.path.dirname(__file__), "secondhand_data.csv"
        )
        self.collection_name = collection_name
        self.persist_directory = persist_directory or os.path.join(
            os.path.dirname(__file__), "chroma_db"
        )

        self.documents: List[Dict] = self._load_csv_raw()
        self._use_vector = False
        self._collection = None

        try:
            import chromadb
            from chromadb.utils.embedding_functions import DefaultEmbeddingFunction

            print("[VectorStore] \u4f7f\u7528 ChromaDB \u5185\u7f6e ONNX embedding...")
            self.client = chromadb.PersistentClient(path=self.persist_directory)
            self._collection = self.client.get_or_create_collection(
                name=self.collection_name,
                embedding_function=DefaultEmbeddingFunction(),
            )
            if self._collection.count() == 0 and self.documents:
                self._build_index()
            self._use_vector = True
            print(f"[VectorStore] \u5411\u91cf\u7d22\u5f15\u5c31\u7eea\uff0c\u5171 {self._collection.count()} \u6761")
        except Exception as e:
            print(f"[VectorStore] \u5411\u91cf\u5e93\u521d\u59cb\u5316\u5931\u8d25\uff0c\u4f7f\u7528\u5173\u952e\u8bcd\u5339\u914d\u5156\u5e95: {e}")
            self._use_vector = False

    def _load_csv_raw(self) -> List[Dict]:
        if not os.path.exists(self.csv_path):
            return []
        docs = []
        with open(self.csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for idx, row in enumerate(reader):
                text = " | ".join([f"{k}: {v}" for k, v in row.items()])
                docs.append({"id": f"doc_{idx}", "document": text, "metadata": row})
        return docs

    def _build_index(self) -> None:
        texts = [d["document"] for d in self.documents]
        ids = [d["id"] for d in self.documents]
        metas = [d["metadata"] for d in self.documents]
        self._collection.add(documents=texts, ids=ids, metadatas=metas)

    def search(self, query: str, top_k: int = 3) -> List[Dict]:
        if self._use_vector and self._collection is not None:
            try:
                results = self._collection.query(query_texts=[query], n_results=top_k)
                out = []
                for i in range(len(results["ids"][0])):
                    out.append({
                        "id": results["ids"][0][i],
                        "document": results["documents"][0][i],
                        "metadata": results["metadatas"][0][i],
                        "distance": results["distances"][0][i],
                    })
                return out
            except Exception as e:
                print(f"[VectorStore] \u5411\u91cf\u68c0\u7d22\u5931\u8d25\uff0c\u964d\u7ea7\u5173\u952e\u8bcd\u5339\u914d: {e}")
        return self._keyword_search(query, top_k)

    def _keyword_search(self, query: str, top_k: int) -> List[Dict]:
        tokens = set(re.findall(r"[\w\u4e00-\u9fff]+", query))
        scores = []
        for doc in self.documents:
            text = doc["document"]
            score = sum(1 for t in tokens if t and t in text)
            scores.append((score, doc))
        scores.sort(key=lambda x: x[0], reverse=True)
        out = []
        for score, doc in scores[:top_k]:
            if score > 0:
                out.append({**doc, "distance": -float(score)})
        return out


_vector_store: Optional[SecondhandVectorStore] = None


def get_vector_store() -> SecondhandVectorStore:
    global _vector_store
    if _vector_store is None:
        _vector_store = SecondhandVectorStore()
    return _vector_store