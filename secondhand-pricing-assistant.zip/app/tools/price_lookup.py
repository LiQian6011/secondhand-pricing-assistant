import os
from langchain.tools import BaseTool
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


class PriceLookupTool(BaseTool):
    """二手物品价格查询工具：通过大模型查询当前市场参考价"""
    name: str = "price_lookup"
    description: str = (
        "查询二手物品在当前市场的参考价格区间。"
        "输入应包含物品品牌、型号、成色等描述信息，"
        "输出为市场参考价格区间（元）。"
    )

    def _run(self, query: str) -> str:
        api_key = os.getenv("OPENAI_API_KEY")
        base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        model = os.getenv("OPENAI_MODEL", "glm-4-flash")
        if not api_key:
            return "错误：未配置 OPENAI_API_KEY，无法查询价格。"
        llm = ChatOpenAI(model=model, temperature=0.3, api_key=api_key, base_url=base_url)
        system_prompt = (
            "你是一位二手3C产品行情专家，熟悉各大品牌手机、平板、笔记本、相机等产品的二手市场价。"
            "请根据用户提供的信息，给出一个合理的市场参考价格区间（人民币）。"
            "只输出价格区间，格式如：3000-3500元。不要输出其他解释。"
        )
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"请查询以下物品的市场参考价：{query}"),
        ]
        try:
            response = llm.invoke(messages)
            return response.content.strip()
        except Exception as e:
            return f"价格查询失败：{str(e)}"

    async def _arun(self, query: str) -> str:
        api_key = os.getenv("OPENAI_API_KEY")
        base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        model = os.getenv("OPENAI_MODEL", "glm-4-flash")
        if not api_key:
            return "错误：未配置 OPENAI_API_KEY，无法查询价格。"
        llm = ChatOpenAI(model=model, temperature=0.3, api_key=api_key, base_url=base_url)
        system_prompt = (
            "你是一位二手3C产品行情专家，熟悉各大品牌手机、平板、笔记本、相机等产品的二手市场价。"
            "请根据用户提供的信息，给出一个合理的市场参考价格区间（人民币）。"
            "只输出价格区间，格式如：3000-3500元。不要输出其他解释。"
        )
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"请查询以下物品的市场参考价：{query}"),
        ]
        try:
            response = await llm.ainvoke(messages)
            return response.content.strip()
        except Exception as e:
            return f"价格查询失败：{str(e)}"


def get_price_lookup_tool() -> PriceLookupTool:
    return PriceLookupTool()
