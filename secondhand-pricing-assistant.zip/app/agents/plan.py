import os
import re
from typing import AsyncGenerator, List, Tuple

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

load_dotenv()

SYSTEM_PROMPT = (
    "你是资深二手数码产品鉴定师和卖家顾问，精通品牌、成色、平台行情和成交策略。"
    "要求根据用户信息输出具有真实交易参考价值的定价策略，注重可执行性和真实性，不输出空泛建议。"
)

USER_PROMPT_TEMPLATE = (
    "请根据以下物品信息生成一份真实可执行的定价与销售方案：\n\n"
    "**物品信息**\n"
    "- 物品描述：{description}\n"
    "- 品牌：{brand}\n"
    "- 型号：{model}\n"
    "- 用户自述成色：{condition}\n"
    "{platform_section}\n"
    "**输出格式要求**\n"
    "1. 最终建议售价：给出一个具体整数，说明定价逻辑。\n"
    "2. 商品文案：150字左右，突出核心卖点。\n"
    "3. 交易建议：至少三条具体操作建议。\n"
    "4. 预期成交周期：给出合理时长。\n"
    "必须基于实际成色、平台行情和用户描述，不要输出空洞模板。\n"
)


def _extract_platform_ranges(platform_data: str) -> List[Tuple[int, int]]:
    ranges: List[Tuple[int, int]] = []
    if not platform_data:
        return ranges
    for match in re.finditer(r"(?:(?:[\u4e00-\u9fffA-Za-z]+)\s*[:：])?\s*(\d{3,})\s*[-~]\s*(\d{3,})\s*元?", platform_data):
        low = int(match.group(1))
        high = int(match.group(2))
        if high >= low:
            ranges.append((low, high))
    return ranges


def _clamp_price_to_platform_range(price: int, platform_data: str) -> int:
    ranges = _extract_platform_ranges(platform_data)
    if not ranges:
        return price
    min_price = min(low for low, _ in ranges)
    max_price = max(high for _, high in ranges)
    return max(min_price, min(price, max_price))


def _fallback_plan_text(description: str, brand: str, model: str, condition: str, platform_data: str) -> str:
    ranges = _extract_platform_ranges(platform_data)
    if ranges:
        lows = [low for low, _ in ranges]
        highs = [high for _, high in ranges]
        low = min(lows)
        high = max(highs)
        mid = int((low + high) / 2)
        anchor = _clamp_price_to_platform_range(mid, platform_data)
        platform_line = f"根据平台参考区间 {platform_data}，最终建议售价必须在 {low}~{high} 元之间，且不能低于最低售价或超过最高售价。建议以 {anchor} 元为中心价位。"
    else:
        base = 6000 if "iphone" in f"{brand} {model} {description}".lower() else 2500
        if "99新" in condition or "95新" in condition:
            base = int(base * 0.9)
        elif "85新" in condition or "7成" in condition:
            base = int(base * 0.7)
        anchor = str(base)
        platform_line = "根据市场参考价和成色判断，建议以中间价位为主，不追高、不低价出手。"

    name = f"{brand} {model}".strip() or "该设备"
    summary = (
        "## 1. 最终建议售价\n"
        f"推荐将 {name} 定价为 {anchor} 元。{platform_line}"
        "这类物品若成色与描述一致，定价应确保处在平台可成交区间内，既不低于最低售价，也不超过平台最高售价。\n\n"
        "## 2. 商品文案\n"
        f"{name}，{condition}，保养良好，功能正常，外观整洁，适合想要低折旧入手的用户。"
        "重点强调原装状态、保修/来源清晰、电池和功能正常，配件齐全。"
        "可直接用于发布在交易平台，突出真实可靠、低风险的交易体验。\n\n"
        "## 3. 交易建议\n"
        "- 只通过平台交易，保留聊天记录和验机截图；\n"
        "- 发货前拍视频留证，确认电池健康、功能和外观状态；\n"
        "- 语气坚定但不强硬，拒绝到手刀、现金交易、隐形价格压力；\n"
        "- 如有保修记录，优先展示来源、保修和购买凭证。\n\n"
        "## 4. 预期成交周期\n"
        "在合理定价且信息完整的前提下，通常 3-7 天即可完成首轮沟通，7-14 天内可成交。"
    )
    return summary


async def generate_plan_stream(
    description: str,
    brand: str,
    model: str,
    condition: str,
    platform_data: str = "",
) -> AsyncGenerator[dict, None]:
    platform_section = ""
    if platform_data:
        platform_section = (
            "\n**平台参考区间**\n"
            + platform_data
            + "\n**约束**：最终建议售价必须在上述平台最低售价和最高售价之间，不能低于最低售价，也不能超过最高售价；如需偏离区间中值，必须说明原因。\n"
        )

    api_key = os.getenv("OPENAI_API_KEY", "")
    base_url = os.getenv("OPENAI_BASE_URL", "")
    if not api_key or not base_url:
        fallback = _fallback_plan_text(description, brand, model, condition, platform_data)
        yield {"event": "delta", "data": fallback}
        yield {"event": "end", "data": fallback}
        return

    llm = ChatOpenAI(
        model=os.getenv("OPENAI_MODEL", "glm-4-flash"),
        temperature=0.6,
        api_key=api_key,
        base_url=base_url,
    )

    messages = [
        SystemMessage(content=SYSTEM_PROMPT),
        HumanMessage(
            content=USER_PROMPT_TEMPLATE.format(
                description=description,
                brand=brand,
                model=model,
                condition=condition,
                platform_section=platform_section,
            )
        ),
    ]

    full_text = ""
    try:
        async for chunk in llm.astream(messages):
            delta = chunk.content or ""
            if delta:
                full_text += delta
                yield {"event": "delta", "data": delta}
    except Exception as e:
        fallback = _fallback_plan_text(description, brand, model, condition, platform_data)
        yield {"event": "delta", "data": f"\n[自动回退规则分析]\n{fallback}"}
        yield {"event": "end", "data": fallback}
        return

    if platform_data:
        ranges = _extract_platform_ranges(platform_data)
        if ranges:
            low = min(v for v, _ in ranges)
            high = max(v for _, v in ranges)
            for match in re.finditer(r"最终建议售价[:：]?\s*(\d+)\s*元", full_text):
                price = int(match.group(1))
                clamped = max(low, min(price, high))
                if clamped != price:
                    full_text = full_text.replace(match.group(1), str(clamped), 1)
            if "最终建议售价" in full_text:
                full_text = full_text.replace(f"{low}~{high}", f"{low}~{high}")

    yield {"event": "end", "data": full_text}
