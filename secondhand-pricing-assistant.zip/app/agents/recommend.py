import os
import re
import json
from typing import Dict, List, Optional, Tuple
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


class PlatformRecommendation(BaseModel):
    rank: int
    name: str
    reason: str
    price_range: str
    advantage: str = ""


PLATFORM_PROFILES = {
    "闲鱼": {
        "price_ratio": (0.95, 1.0),
        "tags": ["流量最大", "同城自提", "个人卖家"],
        "best_for": ["精品", "稀缺款", "自提方便"],
        "worst_for": ["急用钱", "不想打包"],
    },
    "转转": {
        "price_ratio": (0.88, 0.95),
        "tags": ["3C垂直", "验机报告", "官方保障"],
        "best_for": ["手机", "电脑", "想要验机证"],
        "worst_for": ["非3C类"],
    },
    "京东拍拍": {
        "price_ratio": (0.80, 0.88),
        "tags": ["官方回收", "拍卖", "极速到账"],
        "best_for": ["急用钱", "不想打包", "信任官方"],
        "worst_for": ["想卖高价"],
    },
    "爱回收": {
        "price_ratio": (0.75, 0.85),
        "tags": ["上门回收", "即时到账", "免费上门"],
        "best_for": ["急用钱", "大件不便寄", "简单快捷"],
        "worst_for": ["想卖高价", "精品溢价"],
    },
    "回收宝": {
        "price_ratio": (0.78, 0.86),
        "tags": ["在线估价", "顺丰包邮", "透明报价"],
        "best_for": ["手机", "电脑", "不想见面交易"],
        "worst_for": ["想卖最高价"],
    },
    "多抽鱼": {
        "price_ratio": (0.90, 0.98),
        "tags": ["书籍专精", "自动估价", "品质保证"],
        "best_for": ["书籍", "Kindle", "游戏卡带"],
        "worst_for": ["电子产品"],
    },
    "笔记本吧": {
        "price_ratio": (0.92, 1.02),
        "tags": ["精准受众", "论坛交易", "可溢价"],
        "best_for": ["笔记本", "电脑", "稀缺配置"],
        "worst_for": ["手机", "小物"],
    },
    "优品拍拍": {
        "price_ratio": (0.82, 0.90),
        "tags": ["专业验机", "质检报告", "买家信任"],
        "best_for": ["手机", "想要验机报告"],
        "worst_for": ["急用钱"],
    },
    "小米有品": {
        "price_ratio": (0.85, 0.92),
        "tags": ["小米官方", "品质保证", "一手交易"],
        "best_for": ["小米产品", "华为产品"],
        "worst_for": ["Apple产品"],
    },
}


class RecommendAgent:
    def __init__(
        self,
        description: str,
        brand: str = "",
        model: str = "",
        condition: str = "",
        diagnosis_result: Optional[Dict] = None,
        knowledge_results: Optional[List[Dict]] = None,
    ):
        self.description = description
        self.brand = brand
        self.model = model
        self.condition = condition
        self.diagnosis = diagnosis_result or {}
        self.knowledge_results = knowledge_results or []

    def _estimate_price(self) -> Tuple[int, int]:
        text = f"{self.brand} {self.model} {self.description} {self.condition}".lower()
        price_map = {
            "iphone 15 pro max": (6500, 8500),
            "iphone 15 pro": (5500, 7500),
            "iphone 15": (4000, 5500),
            "iphone 14 pro max": (5000, 7000),
            "iphone 14 pro": (4500, 6500),
            "iphone 14": (3000, 4500),
            "iphone 13 pro": (3500, 5000),
            "iphone 13": (2500, 3800),
            "macbook pro": (6000, 12000),
            "macbook air": (4000, 7000),
            "ipad pro": (4000, 7000),
            "ipad air": (2500, 4000),
            "ipad": (1500, 2500),
            "switch oled": (1500, 2000),
            "switch": (1000, 1500),
            "ps5": (2000, 3500),
            "redmibook": (1500, 3000),
            "thinkpad": (2000, 5000),
        }
        for key, price in price_map.items():
            if key in text:
                low, high = price
                grade = self.diagnosis.get("综合评级", "")
                if "S" in grade or "极品" in grade:
                    return (int(low * 0.9), int(high * 0.95))
                elif "A" in grade or "优秀" in grade:
                    return (int(low * 0.8), int(high * 0.85))
                elif "B" in grade or "良好" in grade:
                    return (int(low * 0.7), int(high * 0.75))
                elif "C" in grade or "一般" in grade:
                    return (int(low * 0.6), int(high * 0.65))
                else:
                    return (int(low * 0.5), int(high * 0.55))

        if any(k in text for k in ["vivo", "oppo", "oneplus", "xiaomi", "华为", "荣耀", "手机"]):
            low, high = (1200, 3500)
        elif any(k in text for k in ["macbook", "笔记本", "电脑", "thinkpad", "redmibook"]):
            low, high = (1800, 5200)
        elif any(k in text for k in ["ipad", "平板"]):
            low, high = (900, 2600)
        elif any(k in text for k in ["switch", "ps5", "游戏机"]):
            low, high = (800, 2400)
        else:
            low, high = (500, 2000)

        grade = self.diagnosis.get("综合评级", "")
        if "S" in grade or "极品" in grade:
            return (int(low * 0.95), int(high * 1.05))
        elif "A" in grade or "优秀" in grade:
            return (int(low * 0.9), int(high * 1.0))
        elif "B" in grade or "良好" in grade:
            return (int(low * 0.8), int(high * 0.9))
        elif "C" in grade or "一般" in grade:
            return (int(low * 0.7), int(high * 0.8))
        return (int(low * 0.8), int(high * 0.9))

    def _extract_market_price(self) -> Optional[Tuple[int, int]]:
        if not self.knowledge_results:
            return None
        for r in self.knowledge_results:
            meta = r.get("metadata", {})
            for key in ["参考价低", "价格区间", "参考价高"]:
                if key in meta and isinstance(meta[key], str):
                    m = re.search(r"(\d+)", meta[key])
                    if m:
                        low = int(m.group(1))
                        if "参考价高" in meta and isinstance(meta["参考价高"], str):
                            high_m = re.search(r"(\d+)", meta["参考价高"])
                            if high_m:
                                return (low, int(high_m.group(1)))
                        break
            doc = r.get("document", "")
            m = re.search(r"参考价低:\s*(\d+)\s*\|\s*参考价高:\s*(\d+)", doc)
            if m:
                return (int(m.group(1)), int(m.group(2)))
            m = re.search(r"(\d+)-(\d+)元", doc)
            if m:
                return (int(m.group(1)), int(m.group(2)))
        return None

    def _infer_category(self) -> str:
        text = f"{self.brand}{self.model}{self.description}"
        if any(k in text for k in ["iPhone", "手机", "华为", "小米", "OPPO", "vivo", "红米"]):
            return "手机"
        if any(k in text for k in ["MacBook", "笔记本", "电脑", "ThinkPad", "RedmiBook"]):
            return "电脑"
        if any(k in text for k in ["iPad", "平板"]):
            return "平板"
        if any(k in text for k in ["Switch", "PS5", "游戏机"]):
            return "游戏机"
        return "通用"

    def _select_platforms(self) -> List[Tuple[str, Dict]]:
        cat = self._infer_category()
        grade = self.diagnosis.get("综合评级", "")
        is_premium = "S" in grade or "A" in grade or "极品" in grade or "优秀" in grade
        if cat == "手机":
            names = ["闲鱼", "转转", "京东拍拍", "爱回收", "回收宝", "优品拍拍"]
        elif cat == "电脑":
            names = ["闲鱼", "笔记本吧", "转转", "爱回收", "回收宝"]
        elif cat == "平板":
            names = ["闲鱼", "转转", "京东拍拍", "爱回收", "回收宝"]
        elif cat == "游戏机":
            names = ["闲鱼", "转转", "多抽鱼", "京东拍拍"]
        else:
            names = ["闲鱼", "转转", "京东拍拍", "爱回收"]
        result = []
        for n in names:
            if n in PLATFORM_PROFILES:
                result.append((n, PLATFORM_PROFILES[n]))
        return result

    def _build_reason(self, name: str, profile: Dict, cat: str, is_premium: bool) -> str:
        tags = " | ".join(profile["tags"])
        if is_premium:
            if name in ["闲鱼", "笔记本吧"]:
                return f"精品可溢价10-20%，{tags}。建议多拍细节图+视频验机，强调在保状态。"
            elif name in ["转转", "优品拍拍"]:
                return f"提供官方验机报告，{tags}。精品有验机背书更容易成交。"
            elif name in ["京东拍拍", "爱回收", "回收宝"]:
                return f"价格偏低但极速到账，{tags}。适合急用钱、不想打包的场景。"
        else:
            if name in ["闲鱼", "笔记本吧"]:
                return f"自定价灵活，{tags}。建议实拍细节+坦诚说明瑕疵，定价略低更易成交。"
            elif name in ["转转", "优品拍拍"]:
                return f"验机增信任，{tags}。成色一般的物品有验机报告更容易卖出。"
            elif name in ["京东拍拍", "爱回收", "回收宝"]:
                return f"回收价低但省心，{tags}。成色一般时与其他平台差价不大，省去沟通成本。"
        return tags

    def _real_platform_ranges(self) -> Dict[str, Tuple[int, int]]:
        raw_rows = list(self.knowledge_results)
        if not raw_rows:
            try:
                from app.knowledge.vector_store import get_vector_store
                vector_store = get_vector_store()
                query = f"{self.brand} {self.model} {self.description} {self.condition}".strip()
                raw_rows = vector_store.search(query, top_k=8)
                if not raw_rows:
                    category = self._infer_category()
                    raw_rows = [
                        {"document": doc["document"], "metadata": doc["metadata"]}
                        for doc in vector_store.documents
                        if category in doc["document"] or category in (doc["metadata"].get("品类", "") if isinstance(doc.get("metadata"), dict) else "")
                    ][:8]
            except Exception as e:
                print(f"读取真实平台数据失败: {e}")

        result: Dict[str, List[Tuple[int, int]]] = {}
        target_brand = self.brand.strip().lower()
        target_model = self.model.strip().lower()
        target_cat = self._infer_category()

        for row in raw_rows:
            meta = row.get("metadata", {}) if isinstance(row.get("metadata"), dict) else {}
            doc_text = row.get("document", "")
            text_all = f"{doc_text} {' '.join(str(v) for v in meta.values())}".lower()

            # 先尝试使用 metadata 中的型号/品牌进行高可信度匹配
            meta_model = (meta.get("型号") or meta.get("model") or "").strip().lower()
            meta_brand = (meta.get("品牌") or meta.get("brand") or "").strip().lower()
            norm_target_model = re.sub(r"\s+", "", target_model.lower())
            norm_meta_model = re.sub(r"\s+", "", meta_model)

            matched = False
            # 如果 metadata 中有明确型号，优先使用 metadata 精确或包含匹配
            if meta_model:
                if norm_target_model and (norm_target_model in norm_meta_model or norm_meta_model in norm_target_model or target_model.lower() in meta_model):
                    matched = True
            # 若 metadata 型号不足，要求正文同时包含品牌与型号（严格子串匹配）
            if not matched:
                brand_hit = not target_brand or target_brand in text_all
                model_hit = not target_model or (target_model.lower() in text_all) or (norm_target_model and norm_target_model in text_all.replace(" ", ""))
                cat_hit = not target_cat or target_cat in text_all
                if brand_hit and model_hit:
                    matched = True
            if not matched:
                continue

            platform = meta.get("平台") or meta.get("platform") or ""
            if not platform:
                m = re.search(r"平台[:：]\s*([^|]+)", doc_text)
                if m:
                    platform = m.group(1).strip()
            if not platform:
                continue

            low = None
            high = None
            if "参考价低" in meta and str(meta.get("参考价低", "")).strip():
                low_match = re.search(r"(\d+)", str(meta.get("参考价低", "")))
                if low_match:
                    low = int(low_match.group(1))
            if "参考价高" in meta and str(meta.get("参考价高", "")).strip():
                high_match = re.search(r"(\d+)", str(meta.get("参考价高", "")))
                if high_match:
                    high = int(high_match.group(1))
            if low is None or high is None:
                m = re.search(r"参考价低[:：]?\s*(\d+)\s*\|\s*参考价高[:：]?\s*(\d+)", doc_text)
                if m:
                    low, high = int(m.group(1)), int(m.group(2))
                else:
                    m = re.search(r"(\d+)\s*[-~]\s*(\d+)\s*元", doc_text)
                    if m:
                        low, high = int(m.group(1)), int(m.group(2))

            if low is not None and high is not None and low <= high:
                result.setdefault(platform, []).append((low, high))

        ranges: Dict[str, Tuple[int, int]] = {}
        for platform, vals in result.items():
            lows = [low for low, _ in vals]
            highs = [high for _, high in vals]
            ranges[platform] = (int(sum(lows) / len(lows)), int(sum(highs) / len(highs)))

        # 如果严格匹配的同款同型号数据不足 3 个，尝试宽松匹配（仅品牌或仅品类）来补足真实平台数据
        if len(ranges) < 3:
            relaxed = {}
            for row in raw_rows:
                meta = row.get("metadata", {}) if isinstance(row.get("metadata"), dict) else {}
                doc_text = row.get("document", "")
                text_all = f"{doc_text} {' '.join(str(v) for v in meta.values())}".lower()
                platform = meta.get("平台") or meta.get("platform") or ""
                if not platform:
                    m = re.search(r"平台[:：]\s*([^|]+)", doc_text)
                    if m:
                        platform = m.group(1).strip()
                if not platform:
                    continue

                if platform in ranges:
                    continue

                # 宽松条件：品牌匹配或品类匹配
                brand_hit = not target_brand or target_brand in text_all
                cat_hit = not target_cat or target_cat in text_all
                if not (brand_hit or cat_hit):
                    continue

                low = None
                high = None
                if "参考价低" in meta and str(meta.get("参考价低", "")).strip():
                    low_match = re.search(r"(\d+)", str(meta.get("参考价低", "")))
                    if low_match:
                        low = int(low_match.group(1))
                if "参考价高" in meta and str(meta.get("参考价高", "")).strip():
                    high_match = re.search(r"(\d+)", str(meta.get("参考价高", "")))
                    if high_match:
                        high = int(high_match.group(1))
                if low is None or high is None:
                    m = re.search(r"参考价低[:：]?\s*(\d+)\s*\|\s*参考价高[:：]?\s*(\d+)", doc_text)
                    if m:
                        low, high = int(m.group(1)), int(m.group(2))
                    else:
                        m = re.search(r"(\d+)\s*[-~]\s*(\d+)\s*元", doc_text)
                        if m:
                            low, high = int(m.group(1)), int(m.group(2))

                if low is not None and high is not None and low <= high:
                    relaxed.setdefault(platform, []).append((low, high))

            for platform, vals in relaxed.items():
                if platform in ranges:
                    continue
                lows = [low for low, _ in vals]
                highs = [high for _, high in vals]
                ranges[platform] = (int(sum(lows) / len(lows)), int(sum(highs) / len(highs)))

        # 最后保底：如果仍然不足 3 个平台，使用估算价格和平台比率生成后备平台范围
        if len(ranges) < 3:
            est_low, est_high = self._estimate_price()
            for name, profile in self._select_platforms():
                if name in ranges:
                    continue
                ratio = profile.get("price_ratio", (0.8, 1.0))
                p_low = max(200, int(est_low * ratio[0]))
                p_high = min(15000, int(est_high * ratio[1]))
                if p_low <= p_high:
                    ranges[name] = (p_low, p_high)
                if len(ranges) >= 3:
                    break

        return ranges

    def recommend(self) -> List[PlatformRecommendation]:
        real_ranges = self._real_platform_ranges()
        if real_ranges:
            cat = self._infer_category()
            grade = self.diagnosis.get("综合评级", "")
            is_premium = "S" in grade or "A" in grade or "极品" in grade or "优秀" in grade
            recs: List[PlatformRecommendation] = []
            selected = self._select_platforms()

            # 先按真实平台均价（低价）排序，优先使用真实平台数据
            ordered = sorted(real_ranges.items(), key=lambda x: x[1][0])
            ordered_names = [name for name, _ in ordered]

            # 补足：把选定平台按顺序加入（避免遗漏常见平台）
            for name, _ in selected:
                if name not in ordered_names:
                    ordered_names.append(name)

            est_low, est_high = self._estimate_price()
            for idx, name in enumerate(ordered_names[:3], 1):
                profile = PLATFORM_PROFILES.get(name, {"tags": ["平台"], "price_ratio": (0.8, 1.0)})
                if name in real_ranges:
                    low, high = real_ranges[name]
                else:
                    ratio = profile.get("price_ratio", (0.8, 1.0))
                    low = max(200, int(est_low * ratio[0]))
                    high = min(15000, int(est_high * ratio[1]))
                reason = self._build_reason(name, profile, cat, is_premium)
                recs.append(PlatformRecommendation(
                    rank=idx,
                    name=name,
                    reason=reason,
                    price_range=f"{low}-{high}元",
                    advantage=profile["tags"][0] if profile.get("tags") else "",
                ))
            if recs:
                return recs

        market = self._extract_market_price() or self._estimate_price()
        base_low, base_high = market
        cat = self._infer_category()
        grade = self.diagnosis.get("综合评级", "")
        is_premium = "S" in grade or "A" in grade or "极品" in grade or "优秀" in grade
        platforms = self._select_platforms()

        api_key = os.getenv("OPENAI_API_KEY")
        if api_key:
            try:
                llm_recs = self._llm_recommend(base_low, base_high, cat, platforms)
                if llm_recs:
                    return llm_recs
            except Exception as e:
                print(f"推荐 LLM 调用失败，使用规则兖底: {e}")

        return self._rule_based_recommend(base_low, base_high, cat, is_premium, platforms)

    def _normalize_price_range(self, price_range: str, base_low: int, base_high: int) -> str:
        if not price_range:
            return f"{max(200, int(base_low * 0.7))}-{min(15000, int(base_high * 1.25))}元"
        match = re.search(r"(\d+)\s*[-~]\s*(\d+)", str(price_range))
        if not match:
            return f"{max(200, int(base_low * 0.7))}-{min(15000, int(base_high * 1.25))}元"
        low = int(match.group(1))
        high = int(match.group(2))

        low = max(200, low)
        low = min(low, max(200, int(base_high * 1.05)))
        high = max(high, low + 200)
        high = min(high, 15000)

        lower_bound = max(200, int(base_low * 0.6))
        upper_bound = min(15000, int(base_high * 1.25))
        low = max(lower_bound, min(low, upper_bound))
        high = max(low + 200, min(high, upper_bound))
        return f"{low}-{high}元"

    def _llm_recommend(self, base_low: int, base_high: int, cat: str, platforms: List) -> Optional[List[PlatformRecommendation]]:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return None
        platform_info = ""
        for name, profile in platforms:
            ratio = profile["price_ratio"]
            p_low = int(base_low * ratio[0])
            p_high = int(base_high * ratio[1])
            platform_info += f"- {name}: 估价{p_low}-{p_high}元，特点：{'/'.join(profile['tags'])}\n"

        system_prompt = (
            "你是二手3C产品交易平台推荐专家。"
            "根据物品信息、成色诊断和各平台特点，推荐最适合的 5 个交易平台。"
            "每个平台必须有差异化的价格和推荐理由，体现各平台的独特优势。"
            "价格必须保持在真实二手市场区间，不能脱离该物品的合理估价范围。"
        )
        user_prompt = (
            f"物品：{self.brand} {self.model}\n"
            f"描述：{self.description}\n"
            f"成色：{self.condition}\n"
            f"诊断：{self.diagnosis}\n"
            f"知识库：{self._knowledge_text()}\n"
            f"基准估价：{base_low}-{base_high}元\n\n"
            f"各平台估价与特点：\n{platform_info}\n"
            "请返回 JSON 数组，每个元素格式：\n"
            '{"name":"平台名","reason":"差异化推荐理由(30-60字)","price_range":"xxx-xxx元","advantage":"该平台独特优势(10-20字)"}'
        )
        llm = ChatOpenAI(
            model=os.getenv("OPENAI_MODEL", "glm-4-flash"),
            temperature=0.4,
            api_key=os.getenv("OPENAI_API_KEY", ""),
            base_url=os.getenv("OPENAI_BASE_URL", ""),
        )
        resp = llm.invoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ])
        raw = resp.content.strip()
        if not raw:
            return None
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
        if m:
            raw = m.group(1).strip()
        m2 = re.search(r"\[.*\]", raw, re.DOTALL)
        if m2:
            raw = m2.group(0)
        items = json.loads(raw)
        recs = []
        for i, it in enumerate(items[:5], 1):
            price_range = self._normalize_price_range(str(it.get("price_range", "")), base_low, base_high)
            recs.append(PlatformRecommendation(
                rank=i,
                name=str(it.get("name", "")),
                reason=str(it.get("reason", "")),
                price_range=price_range,
                advantage=str(it.get("advantage", "")),
            ))
        return recs

    def _rule_based_recommend(self, base_low: int, base_high: int, cat: str, is_premium: bool, platforms: List) -> List[PlatformRecommendation]:
        recs = []
        for i, (name, profile) in enumerate(platforms, 1):
            ratio = profile["price_ratio"]
            p_low = int(base_low * ratio[0])
            p_high = int(base_high * ratio[1])

            if p_low < 200:
                p_low = 200
            if p_high < p_low:
                p_high = p_low + 200
            if p_high > 15000:
                p_high = 15000

            reason = self._build_reason(name, profile, cat, is_premium)
            advantage = profile["tags"][0] if profile["tags"] else ""
            recs.append(PlatformRecommendation(
                rank=i, name=name, reason=reason,
                price_range=f"{p_low}-{p_high}元",
                advantage=advantage,
            ))
        return recs

    def _knowledge_text(self) -> str:
        if not self.knowledge_results:
            return "(无知识库数据)"
        lines = []
        for r in self.knowledge_results[:3]:
            lines.append(f"- {r.get('document', '')}")
        return "\n".join(lines)

    def generate_report(self) -> str:
        recs = self.recommend()
        est = self._estimate_price()
        cat = self._infer_category()
        grade = self.diagnosis.get("综合评级", "未知")

        sanitized_recs = []
        for r in recs:
            sanitized = PlatformRecommendation(
                rank=r.rank,
                name=r.name,
                reason=r.reason,
                price_range=self._normalize_price_range(r.price_range, *est),
                advantage=r.advantage,
            )
            sanitized_recs.append(sanitized)

        md = "## 交易平台推荐报告\n\n"
        md += f"**物品类别**: {cat} | **诊断评级**: {grade} | **基准估价**: {est[0]}-{est[1]}元\n\n"
        md += "| 排名 | 平台 | 建议售价 | 独特优势 | 推荐理由 |\n"
        md += "|:---:|:---|:---:|:---|:---|\n"
        for r in sanitized_recs:
            adv = r.advantage if r.advantage else "-"
            md += f"| {r.rank} | **{r.name}** | {r.price_range} | {adv} | {r.reason} |\n"
        md += "\n### 各平台价差对比\n\n"
        if len(sanitized_recs) >= 2:
            prices = []
            for r in sanitized_recs:
                m = re.search(r"(\d+)-(\d+)", r.price_range)
                if m:
                    prices.append((r.name, (int(m.group(1)) + int(m.group(2))) // 2))
            if len(prices) >= 2:
                prices.sort(key=lambda x: x[1], reverse=True)
                md += f"最高价平台 **{prices[0][0]}** 均价约{prices[0][1]}元，最低价平台 **{prices[-1][0]}** 均价约{prices[-1][1]}元，差价约{prices[0][1]-prices[-1][1]}元。\n\n"
        md += "### 小贴士\n\n"
        md += "- 精品物品优先选闲鱼/论坛，可溢价 10-20%\n"
        md += "- 急用钱选爱回收/京东拍拍，价低但极速到账\n"
        md += "- 发布时多拍细节图+功能视频，注明在保状态\n"
        return md
