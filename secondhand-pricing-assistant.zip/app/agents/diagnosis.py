import re
from dataclasses import dataclass
from typing import Dict, List


@dataclass
class DiagnosisResult:
    appearance_score: float
    functionality_score: float
    accessories_score: float
    warranty_score: float
    overall_grade: str
    summary: str

    def to_dict(self) -> Dict:
        return {
            "外观完整性": self.appearance_score,
            "功能可用性": self.functionality_score,
            "配件齐全度": self.accessories_score,
            "保修与来源": self.warranty_score,
            "综合评级": self.overall_grade,
            "总结": self.summary,
        }


class DiagnosisAgent:
    def __init__(self, description: str = "", brand: str = "", model: str = "", condition: str = ""):
        self.description = description
        self.brand = brand
        self.model = model
        self.condition = condition
        self.text = f"{description} {brand} {model} {condition}".strip()

    def _score_from_keywords(self, positive: Dict[str, float], negative: Dict[str, float], base: float = 7.0) -> float:
        text = self.text.lower()
        score = base
        for keyword, delta in negative.items():
            if keyword.lower() in text:
                score += delta
        for keyword, delta in positive.items():
            if keyword.lower() in text:
                score += delta
        return max(1.0, min(10.0, round(score, 1)))

    def _evaluate_appearance(self) -> float:
        positive = {
            "无划痕": 1.8,
            "无磨损": 1.6,
            "99新": 1.5,
            "98新": 1.2,
            "95新": 0.8,
            "完美": 1.2,
            "保护膜": 0.5,
            "壳套": 0.5,
            "原装": 0.5,
        }
        negative = {
            "严重划痕": -3.5,
            "裂痕": -3.8,
            "碎屏": -4.2,
            "磕碰": -2.4,
            "磨损": -2.0,
            "氧化": -1.6,
            "掉漆": -1.8,
            "变形": -2.6,
            "进水": -4.0,
            "发黄": -1.5,
            "脱漆": -2.0,
            "屏幕有划痕": -2.0,
        }
        return self._score_from_keywords(positive, negative, base=7.0)

    def _evaluate_functionality(self) -> float:
        positive = {
            "功能正常": 2.2,
            "全好": 1.8,
            "无拆修": 1.3,
            "电池健康": 1.4,
            "续航好": 1.0,
            "充电正常": 1.5,
            "摄像头正常": 1.2,
            "按键正常": 1.0,
            "接口正常": 1.0,
        }
        negative = {
            "无法开机": -4.2,
            "无信号": -3.2,
            "无网络": -2.8,
            "摄像头坏": -3.0,
            "扬声器坏": -2.5,
            "按键失灵": -2.5,
            "接口松动": -2.2,
            "充电异常": -3.0,
            "功能异常": -2.0,
            "电池报废": -3.4,
            "触摸失灵": -2.8,
        }
        return self._score_from_keywords(positive, negative, base=7.0)

    def _evaluate_accessories(self) -> float:
        text = self.text.lower()
        accessories = [
            "包装盒", "充电器", "数据线", "耳机", "说明书", "保修卡", "发票", "原装配件", "卡针"
        ]
        found = sum(1 for item in accessories if item.lower() in text)
        score = 5.0 + found * 0.8
        if "箱说全" in text or "全套" in text or "齐全" in text:
            score = max(score, 9.0)
        if "单机" in text or "裸机" in text or "无配件" in text:
            score = min(score, 3.0)
        return max(1.0, min(10.0, round(score, 1)))

    def _evaluate_warranty(self) -> float:
        text = self.text.lower()
        score = 5.0
        if "在保" in text or "保修中" in text or "全国联保" in text:
            score += 2.8
        elif "过保" in text or "无保修" in text:
            score -= 2.0

        if "国行" in text or "正品" in text or "官方" in text:
            score += 2.2
        elif "水货" in text or "美版" in text or "日版" in text or "港版" in text:
            score += 0.8

        if "发票" in text or "购买凭证" in text:
            score += 0.8
        if "剩余" in text or "个月" in text:
            score += 0.8
        return max(1.0, min(10.0, round(score, 1)))

    def _calculate_overall_grade(self, scores: List[float]) -> str:
        avg_score = sum(scores) / len(scores)
        if avg_score >= 9.0:
            return "S级：极品"
        elif avg_score >= 8.0:
            return "A级：优秀"
        elif avg_score >= 7.0:
            return "B级：良好"
        elif avg_score >= 6.0:
            return "C级：一般"
        return "D级：较差"

    def _generate_summary(self, scores: Dict[str, float]) -> str:
        text = self.text.lower()
        selling_points = []
        flaws = []

        if scores["外观完整性"] >= 8:
            selling_points.append("外观整洁，几乎无明显损伤")
        elif scores["外观完整性"] < 6:
            flaws.append("外观存在明显划痕或磨损")

        if scores["功能可用性"] >= 8:
            selling_points.append("功能状态稳定，核心功能正常")
        elif scores["功能可用性"] < 6:
            flaws.append("存在功能异常或隐患")

        if scores["配件齐全度"] >= 8:
            selling_points.append("配件齐全，适合直接上架交易")
        elif scores["配件齐全度"] < 5:
            flaws.append("配件缺失影响交易认可度")

        if scores["保修与来源"] >= 8:
            selling_points.append("来源清晰，保修/渠道信息较佳")
        elif scores["保修与来源"] < 5:
            flaws.append("保修或来源信息不足")

        if "电池健康" in text and "92" in text:
            selling_points.append("电池状态较好，续航表现正常")

        summary_parts = []
        if selling_points:
            summary_parts.append("核心卖点：" + "；".join(selling_points) + "。")
        if flaws:
            summary_parts.append("主要瑕疵：" + "；".join(flaws) + "。")
        return " ".join(summary_parts)

    def diagnose(self) -> DiagnosisResult:
        appearance = self._evaluate_appearance()
        functionality = self._evaluate_functionality()
        accessories = self._evaluate_accessories()
        warranty = self._evaluate_warranty()

        scores = {
            "外观完整性": appearance,
            "功能可用性": functionality,
            "配件齐全度": accessories,
            "保修与来源": warranty,
        }
        overall_grade = self._calculate_overall_grade(list(scores.values()))
        avg_score = round(sum(scores.values()) / len(scores), 1)
        summary = self._generate_summary(scores)

        return DiagnosisResult(
            appearance_score=appearance,
            functionality_score=functionality,
            accessories_score=accessories,
            warranty_score=warranty,
            overall_grade=f"{overall_grade}（平均分 {avg_score}）",
            summary=summary,
        )

    def generate_report(self) -> str:
        result = self.diagnose()
        avg_score = round((result.appearance_score + result.functionality_score + result.accessories_score + result.warranty_score) / 4, 1)
        report = (
            "## 二手数码产品成色诊断报告\n\n"
            "| 评估维度 | 得分（1-10） | 详细说明 |\n"
            "|---------|-------------|---------|\n"
            f"| 外观完整性 | {result.appearance_score} | 外壳/屏幕是否有明显划痕、磕碰、氧化、掉漆或变形；结合描述判断外观养护状态。 |\n"
            f"| 功能可用性 | {result.functionality_score} | 检查照相、充电、按键、接口、通信、屏幕及电池状态等功能是否稳定可用。 |\n"
            f"| 配件齐全度 | {result.accessories_score} | 评估包装盒、充电器、数据线、说明书、保修卡、发票等是否齐全。 |\n"
            f"| 保修与来源 | {result.warranty_score} | 核对保修剩余时长、购买渠道及是否为国行/官方或非正规渠道。 |\n"
            f"| **综合评级** | **{result.overall_grade}** | **平均分 {avg_score}** |\n\n"
            f"{result.summary}"
        )
        return report