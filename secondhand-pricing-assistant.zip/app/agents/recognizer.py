import os
import json
import re
import base64
from typing import Dict
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

INFO_SYSTEM = (
    "你是设备信息识别专家。"
    "用户上传的是设备信息截图（如手机“关于本机”页面、电脑系统信息、购买凭证等）。"
    "请从截图中提取关键文字信息，识别品牌、型号、存储容量、电池健康、保修状态等。"
)

INFO_USER = (
    "请识别这张设备信息截图中的关键信息，返回 JSON：\n"
    '{"brand":"品牌","model":"型号","description":"详细描述"}\n'
    "说明：\n"
    "- brand: 品牌（如Apple、华为、小米）\n"
    "- model: 型号（如iPhone 14 Pro 256G、Mate 60 Pro 512G）\n"
    "- description: 截图中所有有用信息的详细描述，包括存储、电池健康、系统版本、保修状态等\n"
    "只返回JSON。"
)

APPEARANCE_SYSTEM = (
    "你是二手设备成色评估专家。"
    "用户上传的是设备外观照片。"
    "请仔细观察照片中设备的外观状态，包括屏幕、边框、背板、按键、接口等部位的磨损、划痕、磕磕、变色情况。"
)

APPEARANCE_USER = (
    "请评估这张设备外观照片的成色状态，返回 JSON：\n"
    '{"condition":"成色评估","details":"外观详细说明"}\n'
    "说明：\n"
    "- condition: 成色等级+简要说明（如“99新 屏幕无划痕”、“85新 边角轻微磕磕”、“7成新 屏幕有划痕背板磨损”）\n"
    "- details: 逐部位说明外观状态（屏幕、边框、背板、按键、接口等）\n"
    "只返回JSON。"
)


def _normalize_text(value):
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (list, tuple)):
        return "；".join(filter(None, (_normalize_text(v) for v in value)))
    if isinstance(value, dict):
        parts = []
        for key, val in value.items():
            text = _normalize_text(val)
            if text:
                parts.append(f"{key}：{text}")
        return "；".join(parts)
    return str(value)


def _call_vision(system: str, user: str, image_bytes: bytes, filename: str) -> Dict:
    api_key = os.getenv("OPENAI_API_KEY", "")
    base_url = os.getenv("OPENAI_BASE_URL", "")
    model = os.getenv("VISION_MODEL", "glm-4v-flash")
    if not api_key:
        return {"success": False, "message": "未配置API Key"}
    ext = os.path.splitext(filename)[1].lower() if filename else ".jpg"
    mime_map = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp"}
    mime = mime_map.get(ext, "image/jpeg")
    b64 = base64.b64encode(image_bytes).decode("utf-8")
    image_url = f"data:{mime};base64,{b64}"
    llm = ChatOpenAI(model=model, temperature=0.1, api_key=api_key, base_url=base_url)
    messages = [
        SystemMessage(content=system),
        HumanMessage(content=[
            {"type": "text", "text": user},
            {"type": "image_url", "image_url": {"url": image_url}},
        ]),
    ]
    try:
        resp = llm.invoke(messages)
        raw = resp.content.strip()
        if not raw:
            return {"success": False, "message": "LLM返回空内容"}
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
        if m:
            raw = m.group(1).strip()
        m2 = re.search(r"\{.*\}", raw, re.DOTALL)
        if m2:
            raw = m2.group(0)
        data = json.loads(raw)
        if isinstance(data, dict):
            for key in ("description", "details"):
                if key in data and not isinstance(data[key], str):
                    data[key] = _normalize_text(data[key])
        return {"success": True, **data}
    except json.JSONDecodeError as e:
        return {"success": False, "message": f"JSON解析失败: {e}"}
    except Exception as e:
        return {"success": False, "message": f"识别失败: {e}"}


def recognize_info_image(image_bytes: bytes, filename: str = "") -> Dict:
    return _call_vision(INFO_SYSTEM, INFO_USER, image_bytes, filename)


def recognize_appearance_image(image_bytes: bytes, filename: str = "") -> Dict:
    return _call_vision(APPEARANCE_SYSTEM, APPEARANCE_USER, image_bytes, filename)
