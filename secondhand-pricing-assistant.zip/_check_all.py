import py_compile, os, sys, importlib

BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"
sys.path.insert(0, BASE)
os.chdir(BASE)

files = [
    "app/main.py",
    "app/routes/api.py",
    "app/agents/diagnosis.py",
    "app/agents/recommend.py",
    "app/agents/plan.py",
    "app/tools/price_lookup.py",
    "app/knowledge/vector_store.py",
]

print("=" * 60)
print("1. 语法检查 (py_compile)")
print("=" * 60)
for f in files:
    try:
        py_compile.compile(f, doraise=True)
        print(f"  [OK] {f}")
    except py_compile.PyCompileError as e:
        print(f"  [FAIL] {f}: {e}")

print()
print("=" * 60)
print("2. 导入检查")
print("=" * 60)
modules = [
    "app.main",
    "app.routes.api",
    "app.agents.diagnosis",
    "app.agents.recommend",
    "app.agents.plan",
    "app.tools.price_lookup",
    "app.knowledge.vector_store",
]
for m in modules:
    try:
        importlib.import_module(m)
        print(f"  [OK] {m}")
    except Exception as e:
        print(f"  [FAIL] {m}: {e}")