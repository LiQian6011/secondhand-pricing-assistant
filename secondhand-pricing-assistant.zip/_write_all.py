import os

BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"

def write(rel_path, content):
    path = os.path.join(BASE, rel_path)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: {rel_path}")

# === main.py ===
write("app/main.py", '''import os
from contextlib import asynccontextmanager
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from app.routes import api

load_dotenv()


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("\u670d\u52a1\u542f\u52a8\u5b8c\u6210\uff0c\u5411\u91cf\u77e5\u8bc6\u5e93\u5c06\u5728\u9996\u6b21\u4f7f\u7528\u65f6\u60f0\u6027\u52a0\u8f7d")
    yield
    print("\u670d\u52a1\u5173\u95ed")


app = FastAPI(
    title="\u4e8c\u624b\u95f2\u7f6e\u5b9a\u4ef7\u667a\u80fd\u52a9\u624b",
    description="\u57fa\u4e8e LangChain + FastAPI \u7684\u4e8c\u624b\u7269\u54c1\u6210\u8272\u8bca\u65ad\u3001\u5e73\u53f0\u63a8\u8350\u4e0e\u5b9a\u4ef7\u7b56\u7565\u751f\u6210\u670d\u52a1",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api.router)

frontend_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend")
if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")


@app.get("/")
async def root():
    index_path = os.path.join(frontend_dir, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "\u4e8c\u624b\u95f2\u7f6e\u5b9a\u4ef7\u667a\u80fd\u52a9\u624b API \u670d\u52a1\u8fd0\u884c\u4e2d", "docs": "/docs"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8000)),
        reload=True,
    )
''')

# === diagnosis.py ===
write("app/agents/diagnosis.py", '''import re
from typing import Dict, List
from pydantic import BaseModel


class DiagnosisResult(BaseModel):
    appearance_score: float
    functionality_score: float
    accessories_score: float
    warranty_score: float
    overall_grade: str
    summary: str

    def to_dict(self) -> Dict:
        return {
            "\u5916\u89c2\u6210\u8272": self.appearance_score,
            "\u529f\u80fd\u5b8c\u597d\u6027": self.functionality_score,
            "\u914d\u4ef6\u5b8c\u6574\u5ea6": self.accessories_score,
            "\u4fdd\u4fee\u4e0e\u6765\u6e90": self.warranty_score,
            "\u7efc\u5408\u8bc4\u7ea7": self.overall_grade,
            "\u603b\u7ed3": self.summary,
        }


class DiagnosisAgent:
    def __init__(self, description: str, brand: str = "", model: str = "", condition: str = ""):
        self.description = description
        self.brand = brand
        self.model = model
        self.condition = condition

    def _evaluate_appearance(self) -> float:
        score = 7.0
        text = f"{self.description} {self.condition}".lower()
        if any(k in text for k in ["\u65e0\u5212\u75d5", "\u5168\u65b0", "\u672a\u4f7f\u7528", "99\u65b0", "\u5168\u65e0\u78d5\u78b0"]):
            score = 9.5
        elif any(k in text for k in ["\u5fae\u5c0f\u5212\u75d5", "\u8f7b\u5fae\u4f7f\u7528\u75d5\u8ff9", "95\u65b0", "9\u6210\u65b0"]):
            score = 8.5
        elif any(k in text for k in ["\u660e\u663e\u5212\u75d5", "\u78d5\u78b0", "8\u6210\u65b0", "\u6709\u78e8\u635f"]):
            score = 6.5
        elif any(k in text for k in ["\u5f00\u88c2", "\u7834\u635f", "\u5c4f\u5e55\u788e", "7\u6210\u65b0"]):
            score = 4.0
        if "\u5c4f\u5e55\u5b8c\u7f8e" in text or "\u5c4f\u5e55\u65e0\u5212\u75d5" in text:
            score = min(10.0, score + 1.0)
        if "\u8fb9\u6846\u6389\u6f06" in text or "\u8d34\u819c\u6c14\u6ce1" in text:
            score = max(1.0, score - 1.5)
        return max(1.0, min(10.0, score))

    def _evaluate_functionality(self) -> float:
        score = 7.0
        text = f"{self.description} {self.condition}".lower()
        if any(k in text for k in ["\u529f\u80fd\u6b63\u5e38", "\u5168\u529f\u80fd\u6b63\u5e38", "\u5b8c\u597d", "\u65e0\u6545\u969c"]):
            score = 9.5
        elif any(k in text for k in ["\u5c0f\u95ee\u9898", "\u5fae\u5c0f\u7455\u75b5"]):
            score = 7.5
        elif any(k in text for k in ["\u529f\u80fd\u5f02\u5e38", "\u6545\u969c", "\u4e0d\u80fd\u7528"]):
            score = 3.0
        if "\u7535\u6c60\u5065\u5eb7" in text:
            m = re.search(r"\u7535\u6c60\u5065\u5eb7(\d+)%", text)
            if m:
                bh = int(m.group(1))
                if bh >= 95:
                    score = min(10.0, score + 0.5)
                elif bh < 80:
                    score = max(1.0, score - 1.5)
        return max(1.0, min(10.0, score))

    def _evaluate_accessories(self) -> float:
        score = 5.0
        text = f"{self.description} {self.condition}".lower()
        accessories = ["\u5305\u88c5\u76d2", "\u5145\u7535\u5668", "\u6570\u636e\u7ebf", "\u8bf4\u660e\u4e66", "\u4fdd\u4fee\u5361", "\u53d1\u7968", "\u539f\u88c5\u914d\u4ef6"]
        found_count = sum(1 for acc in accessories if acc in text)
        score += found_count * 0.8
        if "\u7bb1\u8bf4\u5168" in text or "\u5168\u5957" in text or "\u9f50\u5168" in text:
            score = 9.0
        if "\u5355\u673a" in text or "\u88f8\u673a" in text or "\u65e0\u914d\u4ef6" in text:
            score = 3.0
        return max(1.0, min(10.0, score))

    def _evaluate_warranty(self) -> float:
        score = 5.0
        text = f"{self.description} {self.condition}".lower()
        if "\u5728\u4fdd" in text or "\u4fdd\u4fee\u4e2d" in text or "\u5168\u56fd\u8054\u4fdd" in text:
            score += 3.0
            if "\u5269\u4f59" in text or "\u4e2a\u6708" in text:
                score += 1.0
        elif "\u8fc7\u4fdd" in text or "\u65e0\u4fdd\u4fee" in text:
            score -= 2.0
        if "\u56fd\u884c" in text or "\u6b63\u54c1" in text or "\u5b98\u65b9" in text:
            score += 2.0
        elif "\u6c34\u8d27" in text or "\u7f8e\u7248" in text or "\u65e5\u7248" in text or "\u6e2f\u7248" in text:
            score += 0.5
        if "\u53d1\u7968" in text or "\u8d2d\u4e70\u51ed\u8bc1" in text:
            score += 1.0
        return max(1.0, min(10.0, score))

    def _calculate_overall_grade(self, scores: List[float]) -> str:
        avg_score = sum(scores) / len(scores)
        if avg_score > 9:
            return "S\u7ea7\uff1a\u6781\u54c1"
        elif avg_score >= 8:
            return "A\u7ea7\uff1a\u4f18\u79c0"
        elif avg_score >= 7:
            return "B\u7ea7\uff1a\u826f\u597d"
        elif avg_score >= 6:
            return "C\u7ea7\uff1a\u4e00\u822c"
        else:
            return "D\u7ea7\uff1a\u8f83\u5dee"

    def _generate_summary(self, scores: Dict[str, float]) -> str:
        text = f"{self.description} {self.condition}".lower()
        selling_points = []
        flaws = []
        if scores["\u5916\u89c2\u6210\u8272"] >= 8:
            selling_points.append("\u5916\u89c2\u6210\u8272\u4f18\u79c0\uff0c\u65e0\u660e\u663e\u4f7f\u7528\u75d5\u8ff9")
        elif scores["\u5916\u89c2\u6210\u8272"] < 6:
            flaws.append("\u5916\u89c2\u6709\u660e\u663e\u78e8\u635f\u6216\u635f\u4f24")
        if scores["\u529f\u80fd\u5b8c\u597d\u6027"] >= 8:
            selling_points.append("\u529f\u80fd\u5b8c\u597d\uff0c\u8fd0\u884c\u6b63\u5e38")
        elif scores["\u529f\u80fd\u5b8c\u597d\u6027"] < 6:
            flaws.append("\u5b58\u5728\u529f\u80fd\u6027\u95ee\u9898\u6216\u9690\u60a3")
        if scores["\u914d\u4ef6\u5b8c\u6574\u5ea6"] >= 8:
            selling_points.append("\u914d\u4ef6\u9f50\u5168\uff0c\u7bb1\u8bf4\u5b8c\u6574")
        elif scores["\u914d\u4ef6\u5b8c\u6574\u5ea6"] < 5:
            flaws.append("\u914d\u4ef6\u7f3a\u5931\uff0c\u5f71\u54cd\u4f7f\u7528\u4f53\u9a8c")
        if scores["\u4fdd\u4fee\u4e0e\u6765\u6e90"] >= 8:
            selling_points.append("\u56fd\u884c\u6b63\u54c1\uff0c\u4fdd\u4fee\u671f\u5185")
        elif scores["\u4fdd\u4fee\u4e0e\u6765\u6e90"] < 5:
            flaws.append("\u65e0\u4fdd\u4fee\u6216\u6765\u6e90\u4e0d\u660e")
        if "\u7535\u6c60\u5065\u5eb7" in text or "\u7535\u6c60" in text and scores["\u529f\u80fd\u5b8c\u597d\u6027"] >= 7:
            selling_points.append("\u7535\u6c60\u72b6\u6001\u826f\u597d")
        elif "\u7535\u6c60" in text and "\u6362\u8fc7" in text:
            flaws.append("\u7535\u6c60\u66fe\u66f4\u6362\uff0c\u975e\u539f\u88c5")
        summary = ""
        if selling_points:
            summary += "\u6838\u5fc3\u5356\u70b9\uff1a" + "\uff1b".join(selling_points) + "\u3002"
        if flaws:
            summary += "\u4e3b\u8981\u7455\u75b5\uff1a" + "\uff1b".join(flaws) + "\u3002"
        if not summary:
            summary = "\u8be5\u7269\u54c1\u6574\u4f53\u72b6\u51b5\u4e00\u822c\uff0c\u5efa\u8bae\u5b9e\u5730\u9a8c\u673a\u540e\u4ea4\u6613\u3002"
        return summary

    def diagnose(self) -> DiagnosisResult:
        appearance = self._evaluate_appearance()
        functionality = self._evaluate_functionality()
        accessories = self._evaluate_accessories()
        warranty = self._evaluate_warranty()
        scores = {
            "\u5916\u89c2\u6210\u8272": appearance,
            "\u529f\u80fd\u5b8c\u597d\u6027": functionality,
            "\u914d\u4ef6\u5b8c\u6574\u5ea6": accessories,
            "\u4fdd\u4fee\u4e0e\u6765\u6e90": warranty,
        }
        overall = self._calculate_overall_grade(list(scores.values()))
        summary = self._generate_summary(scores)
        return DiagnosisResult(
            appearance_score=round(appearance, 1),
            functionality_score=round(functionality, 1),
            accessories_score=round(accessories, 1),
            warranty_score=round(warranty, 1),
            overall_grade=overall,
            summary=summary,
        )

    def generate_report(self) -> str:
        result = self.diagnose()
        report = f"""## \u4e8c\u624b\u6570\u7801\u4ea7\u54c1\u6210\u8272\u8bca\u65ad\u62a5\u544a

| \u8bca\u65ad\u7ef4\u5ea6 | \u8bc4\u5206 (1-10) | \u8bc4\u7ea7\u8bf4\u660e |
|:---|:---:|:---|
| \u5916\u89c2\u6210\u8272 | {result.appearance_score} | \u8bc4\u4f30\u5916\u58f3\u5212\u75d5\u3001\u5c4f\u5e55\u8001\u5316/\u5212\u4f24\u3001\u6309\u952e\u78e8\u635f\u3001\u63a5\u53e3\u6c27\u5316\u60c5\u51b5 |
| \u529f\u80fd\u5b8c\u597d\u6027 | {result.functionality_score} | \u8bc4\u4f30\u6240\u6709\u529f\u80fd\uff08\u6444\u50cf\u5934\u3001Wi-Fi\u3001\u7535\u6c60\u5065\u5eb7\u5ea6\u3001\u626c\u58f0\u5668\u7b49\uff09\u662f\u5426\u6b63\u5e38 |
| \u914d\u4ef6\u5b8c\u6574\u5ea6 | {result.accessories_score} | \u8bc4\u4f30\u5305\u88c5\u76d2\u3001\u5145\u7535\u5668\u3001\u6570\u636e\u7ebf\u3001\u8bf4\u660e\u4e66\u7b49\u662f\u5426\u9f50\u5168 |
| \u4fdd\u4fee\u4e0e\u6765\u6e90 | {result.warranty_score} | \u8bc4\u4f30\u662f\u5426\u5728\u4fdd\u3001\u4fdd\u4fee\u5269\u4f59\u65f6\u957f\u3001\u8d2d\u4e70\u6e20\u9053\uff08\u56fd\u884c/\u6c34\u8d27\uff09 |
| **\u7efc\u5408\u8bc4\u7ea7** | **{result.overall_grade}** | **\u5e73\u5747\u5206: {(result.appearance_score + result.functionality_score + result.accessories_score + result.warranty_score) / 4:.1f}** |

### \u603b\u7ed3

{result.summary}
"""
        return report
''')

# === recommend.py ===
write("app/agents/recommend.py", '''import os
import re
import json
from typing import Dict, List, Optional, Tuple
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


class PlatformRecommendation(BaseModel):
    rank: int
    name: str
    reason: str
    price_range: str


class RecommendAgent:
    def __init__(
        self,
        description: str,
        brand: str = "",
        model: str = "",
        condition: str = "",
        diagnosis_result: Optional[Dict] = None,
        knowledge_results: Optional[List[Dict]] = None,
    ):
        self.description = description
        self.brand = brand
        self.model = model
        self.condition = condition
        self.diagnosis = diagnosis_result or {}
        self.knowledge_results = knowledge_results or []

    def _estimate_price(self) -> Tuple[int, int]:
        text = f"{self.brand} {self.model} {self.description} {self.condition}".lower()
        price_map = {
            "iphone 15 pro max": (6500, 8500),
            "iphone 15 pro": (5500, 7500),
            "iphone 15": (4000, 5500),
            "iphone 14 pro max": (5000, 7000),
            "iphone 14 pro": (4500, 6500),
            "iphone 14": (3000, 4500),
            "iphone 13 pro": (3500, 5000),
            "iphone 13": (2500, 3800),
            "macbook pro": (6000, 12000),
            "macbook air": (4000, 7000),
            "ipad pro": (4000, 7000),
            "ipad air": (2500, 4000),
            "ipad": (1500, 2500),
            "switch oled": (1500, 2000),
            "switch": (1000, 1500),
            "ps5": (2000, 3500),
        }
        for key, price in price_map.items():
            if key in text:
                low, high = price
                grade = self.diagnosis.get("\u7efc\u5408\u8bc4\u7ea7", "")
                if "S" in grade or "\u6781\u54c1" in grade:
                    return (int(low * 0.9), int(high * 0.95))
                elif "A" in grade or "\u4f18\u79c0" in grade:
                    return (int(low * 0.8), int(high * 0.85))
                elif "B" in grade or "\u826f\u597d" in grade:
                    return (int(low * 0.7), int(high * 0.75))
                elif "C" in grade or "\u4e00\u822c" in grade:
                    return (int(low * 0.6), int(high * 0.65))
                else:
                    return (int(low * 0.5), int(high * 0.55))
        return (500, 2000)

    def _extract_market_price(self) -> Optional[Tuple[int, int]]:
        if not self.knowledge_results:
            return None
        for r in self.knowledge_results:
            meta = r.get("metadata", {})
            price_str = meta.get("\u4ef7\u683c\u533a\u95f4", "")
            m = re.search(r"(\d+)-(\d+)", price_str)
            if m:
                return (int(m.group(1)), int(m.group(2)))
        return None

    def recommend(self) -> List[PlatformRecommendation]:
        estimated = self._extract_market_price() or self._estimate_price()
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return self._rule_based_fallback(estimated)
        system_prompt = (
            "\u4f60\u662f\u4e8c\u624b3C\u4ea7\u54c1\u4ea4\u6613\u5e73\u53f0\u63a8\u8350\u4e13\u5bb6\u3002"
            "\u6839\u636e\u7269\u54c1\u4fe1\u606f\u548c\u6210\u8272\u8bca\u65ad\uff0c\u63a8\u8350\u6700\u9002\u5408\u7684 3 \u4e2a\u4ea4\u6613\u5e73\u53f0\u3002"
        )
        user_prompt = (
            f"\u7269\u54c1\uff1a{self.brand} {self.model}\n"
            f"\u63cf\u8ff0\uff1a{self.description}\n"
            f"\u6210\u8272\uff1a{self.condition}\n"
            f"\u8bca\u65ad\uff1a{self.diagnosis}\n"
            f"\u77e5\u8bc6\u5e93\u53c2\u8003\uff1a{self._knowledge_text()}\n"
            f"\u4f30\u4ef7\uff1a{estimated[0]}-{estimated[1]} \u5143\n\n"
            "\u8bf7\u8fd4\u56de JSON \u6570\u7ec4\uff0c\u6bcf\u4e2a\u5143\u7d20\u683c\u5f0f\uff1a\n"
            '{{"name": "\u5e73\u53f0\u540d", "reason": "\u63a8\u8350\u7406\u7531\uff0820-40\u5b57\uff09", "price_range": "xxx-xxx\u5143"}}'
        )
        llm = ChatOpenAI(
            model=os.getenv("OPENAI_MODEL", "glm-4-flash"),
            temperature=0.4,
            api_key=os.getenv("OPENAI_API_KEY", ""),
            base_url=os.getenv("OPENAI_BASE_URL", ""),
        )
        try:
            resp = llm.invoke([
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_prompt),
            ])
            raw = resp.content.strip()
            if raw.startswith(""):
                raw = re.sub(r"^(?:json)?", "", raw)
                raw = re.sub(r"$", "", raw)
            items = json.loads(raw)
            recs = []
            for i, it in enumerate(items[:3], 1):
                recs.append(PlatformRecommendation(
                    rank=i,
                    name=str(it.get("name", "")),
                    reason=str(it.get("reason", "")),
                    price_range=str(it.get("price_range", "")),
                ))
            return recs
        except Exception as e:
            print(f"\u63a8\u8350 LLM \u8c03\u7528\u5931\u8d25\uff0c\u4f7f\u7528\u89c4\u5219\u5156\u5e95: {e}")
            return self._rule_based_fallback(estimated)

    def _rule_based_fallback(self, estimated: Tuple[int, int]) -> List[PlatformRecommendation]:
        low, high = estimated
        cat = self._infer_category()
        platforms = {
            "\u624b\u673a": [
                ("\u95f2\u9c7c", "\u6d41\u91cf\u6700\u5927\uff0c\u540c\u57ce\u81ea\u63d0\u65b9\u4fbf\uff0c\u9002\u54089\u6210\u65b0\u4ee5\u4e0a\u7cbe\u54c1\u673a"),
                ("\u8f6c\u8f6c", "3C\u6570\u7801\u5782\u76f4\u5e73\u53f0\uff0c\u6709\u9a8c\u673a\u670d\u52a1\uff0c\u4e70\u5bb6\u66f4\u7cbe\u51c6"),
                ("\u4eac\u4e1c\u62cd\u62cd", "\u5b98\u65b9\u56de\u6536+\u62cd\u5356\uff0c\u9760\u8c31\u7701\u5fc3\u4f46\u4ef7\u683c\u504f\u4f4e"),
            ],
            "\u7535\u8111": [
                ("\u95f2\u9c7c", "\u53d7\u4f17\u5e7f\uff0c\u914d\u4ef6\u6574\u673a\u90fd\u597d\u5356"),
                ("\u7b14\u8bb0\u672c\u5427/\u8bba\u575b", "\u76ee\u6807\u7528\u6237\u7cbe\u51c6\uff0c\u80fd\u5356\u4e2a\u597d\u4ef7"),
                ("\u7231\u56de\u6536", "\u4e0a\u95e8\u56de\u6536\u7701\u5fc3\uff0c\u901f\u5ea6\u5feb"),
            ],
        }
        table = platforms.get(cat, [
            ("\u95f2\u9c7c", "\u6d41\u91cf\u67387\u5927\uff0c\u8986\u76d6\u5168\u7f51\u7528\u6237\uff0c\u6210\u4ea4\u7387\u9ad8"),
            ("\u8f6c\u8f6c", "3C\u6570\u7801\u5782\u76f4\u5e73\u53f0\uff0c\u6709\u9a8c\u673a\u670d\u52a1\uff0c\u4fe1\u4efb\u5ea6\u9ad8"),
            ("\u4eac\u4e1c\u62cd\u62cd/\u7231\u56de\u6536", "\u5b98\u65b9\u6e20\u9053\uff0c\u56de\u6536\u9760\u8c31\u7701\u5fc3"),
        ])
        out = []
        for i, (name, reason) in enumerate(table, 1):
            out.append(PlatformRecommendation(
                rank=i, name=name, reason=reason,
                price_range=f"{low}-{high}\u5143",
            ))
        return out

    def _infer_category(self) -> str:
        text = f"{self.brand}{self.model}{self.description}"
        if any(k in text for k in ["iPhone", "\u624b\u673a", "\u534e\u4e3a", "\u5c0f\u7c73", "OPPO", "vivo"]):
            return "\u624b\u673a"
        if any(k in text for k in ["MacBook", "\u7b14\u8bb0\u672c", "\u7535\u8111", "ThinkPad"]):
            return "\u7535\u8111"
        return "\u901a\u7528"

    def _knowledge_text(self) -> str:
        if not self.knowledge_results:
            return "(\u65e0\u77e5\u8bc6\u5e93\u6570\u636e)"
        lines = []
        for r in self.knowledge_results[:3]:
            lines.append(f"- {r.get('document', '')}")
        return "\n".join(lines)

    def generate_report(self) -> str:
        recs = self.recommend()
        est = self._estimate_price()
        cat = self._infer_category()
        md = "## \u4ea4\u6613\u5e73\u53f0\u63a8\u8350\u62a5\u544a\n\n"
        md += f"**\u7269\u54c1\u7c7b\u522b**: {cat}  \n"
        md += f"**\u8bca\u65ad\u8bc4\u7ea7**: {self.diagnosis.get('\u7efc\u5408\u8bc4\u7ea7', '\u672a\u77e5')}  \n"
        md += f"**\u9884\u4f30\u5e02\u573a\u4ef7**: {est[0]} - {est[1]} \u5143\n\n"
        md += "| \u6392\u040d | \u5e73\u53f0 | \u63a8\u8350\u7406\u7531 | \u5efa\u8bae\u552e\u4ef7 |\n"
        md += "|:---:|:---|:---|:---:|\n"
        for r in recs:
            md += f"| {r.rank} | {r.name} | {r.reason} | {r.price_range} |\n"
        md += "\n### \u5c0f\u8d34\u58eb\n"
        md += "- \u7cbe\u54c1\u7269\u54c1\u4f18\u5148\u9009\u652f\u6301\u9a8c\u673a\u7684\u5e73\u53f0\uff0c\u53ef\u6ea2\u4ef7 10-20%\n"
        md += "- \u53d1\u5e03\u65f6\u591a\u62cd\u7ec6\u8282\u56fe\u548c\u529f\u80fd\u89c6\u9891\uff0c\u6ce8\u660e\u5728\u4fdd\u72b6\u6001\n"
        return md
''')

# === price_lookup.py ===
write("app/tools/price_lookup.py", '''import os
from langchain.tools import BaseTool
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


class PriceLookupTool(BaseTool):
    """\u4e8c\u624b\u7269\u54c1\u4ef7\u683c\u67e5\u8be2\u5de5\u5177\uff1a\u901a\u8fc7\u5927\u6a21\u578b\u67e5\u8be2\u5f53\u524d\u5e02\u573a\u53c2\u8003\u4ef7"""
    name: str = "price_lookup"
    description: str = (
        "\u67e5\u8be2\u4e8c\u624b\u7269\u54c1\u5728\u5f53\u524d\u5e02\u573a\u7684\u53c2\u8003\u4ef7\u683c\u533a\u95f4\u3002"
        "\u8f93\u5165\u5e94\u5305\u542b\u7269\u54c1\u54c1\u724c\u3001\u578b\u53f7\u3001\u6210\u8272\u7b49\u63cf\u8ff0\u4fe1\u606f\uff0c"
        "\u8f93\u51fa\u4e3a\u5e02\u573a\u53c2\u8003\u4ef7\u683c\u533a\u95f4\uff08\u5143\uff09\u3002"
    )

    def _run(self, query: str) -> str:
        api_key = os.getenv("OPENAI_API_KEY")
        base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        model = os.getenv("OPENAI_MODEL", "glm-4-flash")
        if not api_key:
            return "\u9519\u8bef\uff1a\u672a\u914d\u7f6e OPENAI_API_KEY\uff0c\u65e0\u6cd5\u67e5\u8be2\u4ef7\u683c\u3002"
        llm = ChatOpenAI(model=model, temperature=0.3, api_key=api_key, base_url=base_url)
        system_prompt = (
            "\u4f60\u662f\u4e00\u4f4d\u4e8c\u624b3C\u4ea7\u54c1\u884c\u60c5\u4e13\u5bb6\uff0c\u719f\u6089\u5404\u5927\u54c1\u724c\u624b\u673a\u3001\u5e73\u677f\u3001\u7b14\u8bb0\u672c\u3001\u76f8\u673a\u7b49\u4ea7\u54c1\u7684\u4e8c\u624b\u5e02\u573a\u4ef7\u3002"
            "\u8bf7\u6839\u636e\u7528\u6237\u63d0\u4f9b\u7684\u4fe1\u606f\uff0c\u7ed9\u51fa\u4e00\u4e2a\u5408\u7406\u7684\u5e02\u573a\u53c2\u8003\u4ef7\u683c\u533a\u95f4\uff08\u4eba\u6c11\u5e01\uff09\u3002"
            "\u53ea\u8f93\u51fa\u4ef7\u683c\u533a\u95f4\uff0c\u683c\u5f0f\u5982\uff1a3000-3500\u5143\u3002\u4e0d\u8981\u8f93\u51fa\u5176\u4ed6\u89e3\u91ca\u3002"
        )
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"\u8bf7\u67e5\u8be2\u4ee5\u4e0b\u7269\u54c1\u7684\u5e02\u573a\u53c2\u8003\u4ef7\uff1a{query}"),
        ]
        try:
            response = llm.invoke(messages)
            return response.content.strip()
        except Exception as e:
            return f"\u4ef7\u683c\u67e5\u8be2\u5931\u8d25\uff1a{str(e)}"

    async def _arun(self, query: str) -> str:
        api_key = os.getenv("OPENAI_API_KEY")
        base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        model = os.getenv("OPENAI_MODEL", "glm-4-flash")
        if not api_key:
            return "\u9519\u8bef\uff1a\u672a\u914d\u7f6e OPENAI_API_KEY\uff0c\u65e0\u6cd5\u67e5\u8be2\u4ef7\u683c\u3002"
        llm = ChatOpenAI(model=model, temperature=0.3, api_key=api_key, base_url=base_url)
        system_prompt = (
            "\u4f60\u662f\u4e00\u4f4d\u4e8c\u624b3C\u4ea7\u54c1\u884c\u60c5\u4e13\u5bb6\uff0c\u719f\u6089\u5404\u5927\u54c1\u724c\u624b\u673a\u3001\u5e73\u677f\u3001\u7b14\u8bb0\u672c\u3001\u76f8\u673a\u7b49\u4ea7\u54c1\u7684\u4e8c\u624b\u5e02\u573a\u4ef7\u3002"
            "\u8bf7\u6839\u636e\u7528\u6237\u63d0\u4f9b\u7684\u4fe1\u606f\uff0c\u7ed9\u51fa\u4e00\u4e2a\u5408\u7406\u7684\u5e02\u573a\u53c2\u8003\u4ef7\u683c\u533a\u95f4\uff08\u4eba\u6c11\u5e01\uff09\u3002"
            "\u53ea\u8f93\u51fa\u4ef7\u683c\u533a\u95f4\uff0c\u683c\u5f0f\u5982\uff1a3000-3500\u5143\u3002\u4e0d\u8981\u8f93\u51fa\u5176\u4ed6\u89e3\u91ca\u3002"
        )
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=f"\u8bf7\u67e5\u8be2\u4ee5\u4e0b\u7269\u54c1\u7684\u5e02\u573a\u53c2\u8003\u4ef7\uff1a{query}"),
        ]
        try:
            response = await llm.ainvoke(messages)
            return response.content.strip()
        except Exception as e:
            return f"\u4ef7\u683c\u67e5\u8be2\u5931\u8d25\uff1a{str(e)}"


def get_price_lookup_tool() -> PriceLookupTool:
    return PriceLookupTool()
''')

print("All files written successfully!")