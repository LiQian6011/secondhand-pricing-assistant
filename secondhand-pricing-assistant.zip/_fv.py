import os
base = "/home/wjx1202/projects/secondhand-pricing-assistant"
files = ["app/routes/api.py", "app/agents/recommend.py", "app/agents/diagnosis.py", "app/agents/plan.py", "app/tools/price_lookup.py", "app/main.py", "app/knowledge/vector_store.py"]
results = []
for f in files:
    path = os.path.join(base, f)
    try:
        with open(path) as fh:
            content = fh.read()
        compile(content, f, "exec")
        results.append(f + ": OK")
    except SyntaxError as e:
        results.append(f + ": FAIL - " + str(e))
with open(base + "/_verify.txt", "w") as fh:
    fh.write("\n".join(results))