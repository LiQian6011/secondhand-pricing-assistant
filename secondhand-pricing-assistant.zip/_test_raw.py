import requests
BASE = "http://localhost:8000/api"
r = requests.post(BASE + "/generate-plan", json={
    "description": "iPhone 14 Pro 256G 国行",
    "brand": "Apple",
    "model": "iPhone 14 Pro",
    "condition": "99新",
}, stream=True, timeout=60)
count = 0
for line in r.iter_lines(decode_unicode=True):
    print(f"RAW: {line}")
    count += 1
    if count > 20:
        print("... (truncated)")
        break