path = "/home/wjx1202/projects/secondhand-pricing-assistant/app/agents/recommend.py"
content = """import os
import re
import json
from typing import Dict, List, Optional, Tuple
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


class PlatformRecommendation(BaseModel):
    rank: int
    name: str
    reason: str
    price_range: str
    advantage: str = ""


PLATFORM_PROFILES = {
    "\u95f2\u9c7c": {
        "price_ratio": (0.95, 1.0),
        "tags": ["\u6d41\u91cf\u6700\u5927", "\u540c\u57ce\u81ea\u63d0", "\u4e2a\u4eba\u5356\u5bb6"],
        "best_for": ["\u7cbe\u54c1", "\u7a00\u7f3a\u6b3e", "\u81ea\u63d0\u65b9\u4fbf"],
        "worst_for": ["\u6025\u7528\u94b1", "\u4e0d\u60f3\u6253\u5305"],
    },
    "\u8f6c\u8f6c": {
        "price_ratio": (0.88, 0.95),
        "tags": ["3C\u5782\u76f4", "\u9a8c\u673a\u62a5\u544a", "\u5b98\u65b9\u4fdd\u969c"],
        "best_for": ["\u624b\u673a", "\u7535\u8111", "\u60f3\u8981\u9a8c\u673a\u8bc1"],
        "worst_for": ["\u975e3C\u7c7b"],
    },
    "\u4eac\u4e1c\u62cd\u62cd": {
        "price_ratio": (0.80, 0.88),
        "tags": ["\u5b98\u65b9\u56de\u6536", "\u62cd\u5356", "\u6781\u901f\u5230\u8d26"],
        "best_for": ["\u6025\u7528\u94b1", "\u4e0d\u60f3\u6253\u5305", "\u4fe1\u4efb\u5b98\u65b9"],
        "worst_for": ["\u60f3\u5356\u9ad8\u4ef7"],
    },
    "\u7231\u56de\u6536": {
        "price_ratio": (0.75, 0.85),
        "tags": ["\u4e0a\u95e8\u56de\u6536", "\u5373\u65f6\u5230\u8d26", "\u514d\u8d39\u4e0a\u95e8"],
        "best_for": ["\u6025\u7528\u94b1", "\u5927\u4ef6\u4e0d\u4fbf\u5bc4", "\u7b80\u5355\u5feb\u6377"],
        "worst_for": ["\u60f3\u5356\u9ad8\u4ef7", "\u7cbe\u54c1\u6ea2\u4ef7"],
    },
    "\u56de\u6536\u5b9d": {
        "price_ratio": (0.78, 0.86),
        "tags": ["\u5728\u7ebf\u4f30\u4ef7", "\u987a\u4e30\u5305\u90ae", "\u900f\u660e\u62a5\u4ef7"],
        "best_for": ["\u624b\u673a", "\u7535\u8111", "\u4e0d\u60f3\u89c1\u9762\u4ea4\u6613"],
        "worst_for": ["\u60f3\u5356\u6700\u9ad8\u4ef7"],
    },
    "\u591a\u62bd\u9c7c": {
        "price_ratio": (0.90, 0.98),
        "tags": ["\u4e66\u7c4d\u4e13\u7cbe", "\u81ea\u52a8\u4f30\u4ef7", "\u54c1\u8d28\u4fdd\u8bc1"],
        "best_for": ["\u4e66\u7c4d", "Kindle", "\u6e38\u620f\u5361\u5e26"],
        "worst_for": ["\u7535\u5b50\u4ea7\u54c1"],
    },
    "\u7b14\u8bb0\u672c\u5427": {
        "price_ratio": (0.92, 1.02),
        "tags": ["\u7cbe\u51c6\u53d7\u4f17", "\u8bba\u575b\u4ea4\u6613", "\u53ef\u6ea2\u4ef7"],
        "best_for": ["\u7b14\u8bb0\u672c", "\u7535\u8111", "\u7a00\u7f3a\u914d\u7f6e"],
        "worst_for": ["\u624b\u673a", "\u5c0f\u7269"],
    },
    "\u4f18\u54c1\u62cd\u62cd": {
        "price_ratio": (0.82, 0.90),
        "tags": ["\u4e13\u4e1a\u9a8c\u673a", "\u8d28\u68c0\u62a5\u544a", "\u4e70\u5bb6\u4fe1\u4efb"],
        "best_for": ["\u624b\u673a", "\u60f3\u8981\u9a8c\u673a\u62a5\u544a"],
        "worst_for": ["\u6025\u7528\u94b1"],
    },
    "\u5c0f\u7c73\u6709\u54c1": {
        "price_ratio": (0.85, 0.92),
        "tags": ["\u5c0f\u7c73\u5b98\u65b9", "\u54c1\u8d28\u4fdd\u8bc1", "\u4e00\u624b\u4ea4\u6613"],
        "best_for": ["\u5c0f\u7c73\u4ea7\u54c1", "\u534e\u4e3a\u4ea7\u54c1"],
        "worst_for": ["Apple\u4ea7\u54c1"],
    },
}


class RecommendAgent:
    def __init__(
        self,
        description: str,
        brand: str = "",
        model: str = "",
        condition: str = "",
        diagnosis_result: Optional[Dict] = None,
        knowledge_results: Optional[List[Dict]] = None,
    ):
        self.description = description
        self.brand = brand
        self.model = model
        self.condition = condition
        self.diagnosis = diagnosis_result or {}
        self.knowledge_results = knowledge_results or []

    def _estimate_price(self) -> Tuple[int, int]:
        text = f"{self.brand} {self.model} {self.description} {self.condition}".lower()
        price_map = {
            "iphone 15 pro max": (6500, 8500),
            "iphone 15 pro": (5500, 7500),
            "iphone 15": (4000, 5500),
            "iphone 14 pro max": (5000, 7000),
            "iphone 14 pro": (4500, 6500),
            "iphone 14": (3000, 4500),
            "iphone 13 pro": (3500, 5000),
            "iphone 13": (2500, 3800),
            "macbook pro": (6000, 12000),
            "macbook air": (4000, 7000),
            "ipad pro": (4000, 7000),
            "ipad air": (2500, 4000),
            "ipad": (1500, 2500),
            "switch oled": (1500, 2000),
            "switch": (1000, 1500),
            "ps5": (2000, 3500),
            "redmibook": (1500, 3000),
            "thinkpad": (2000, 5000),
        }
        for key, price in price_map.items():
            if key in text:
                low, high = price
                grade = self.diagnosis.get("\u7efc\u5408\u8bc4\u7ea7", "")
                if "S" in grade or "\u6781\u54c1" in grade:
                    return (int(low * 0.9), int(high * 0.95))
                elif "A" in grade or "\u4f18\u79c0" in grade:
                    return (int(low * 0.8), int(high * 0.85))
                elif "B" in grade or "\u826f\u597d" in grade:
                    return (int(low * 0.7), int(high * 0.75))
                elif "C" in grade or "\u4e00\u822c" in grade:
                    return (int(low * 0.6), int(high * 0.65))
                else:
                    return (int(low * 0.5), int(high * 0.55))
        return (500, 2000)

    def _extract_market_price(self) -> Optional[Tuple[int, int]]:
        if not self.knowledge_results:
            return None
        for r in self.knowledge_results:
            meta = r.get("metadata", {})
            price_str = meta.get("\u4ef7\u683c\u533a\u95f4", "")
            m = re.search(r"(\\d+)-(\\d+)", price_str)
            if m:
                return (int(m.group(1)), int(m.group(2)))
        return None

    def _infer_category(self) -> str:
        text = f"{self.brand}{self.model}{self.description}"
        if any(k in text for k in ["iPhone", "\u624b\u673a", "\u534e\u4e3a", "\u5c0f\u7c73", "OPPO", "vivo", "\u7ea2\u7c73"]):
            return "\u624b\u673a"
        if any(k in text for k in ["MacBook", "\u7b14\u8bb0\u672c", "\u7535\u8111", "ThinkPad", "RedmiBook"]):
            return "\u7535\u8111"
        if any(k in text for k in ["iPad", "\u5e73\u677f"]):
            return "\u5e73\u677f"
        if any(k in text for k in ["Switch", "PS5", "\u6e38\u620f\u673a"]):
            return "\u6e38\u620f\u673a"
        return "\u901a\u7528"

    def _select_platforms(self) -> List[Tuple[str, Dict]]:
        cat = self._infer_category()
        grade = self.diagnosis.get("\u7efc\u5408\u8bc4\u7ea7", "")
        is_premium = "S" in grade or "A" in grade or "\u6781\u54c1" in grade or "\u4f18\u79c0" in grade
        if cat == "\u624b\u673a":
            names = ["\u95f2\u9c7c", "\u8f6c\u8f6c", "\u4eac\u4e1c\u62cd\u62cd", "\u7231\u56de\u6536", "\u56de\u6536\u5b9d", "\u4f18\u54c1\u62cd\u62cd"]
        elif cat == "\u7535\u8111":
            names = ["\u95f2\u9c7c", "\u7b14\u8bb0\u672c\u5427", "\u8f6c\u8f6c", "\u7231\u56de\u6536", "\u56de\u6536\u5b9d"]
        elif cat == "\u5e73\u677f":
            names = ["\u95f2\u9c7c", "\u8f6c\u8f6c", "\u4eac\u4e1c\u62cd\u62cd", "\u7231\u56de\u6536", "\u56de\u6536\u5b9d"]
        elif cat == "\u6e38\u620f\u673a":
            names = ["\u95f2\u9c7c", "\u8f6c\u8f6c", "\u591a\u62bd\u9c7c", "\u4eac\u4e1c\u62cd\u62cd"]
        else:
            names = ["\u95f2\u9c7c", "\u8f6c\u8f6c", "\u4eac\u4e1c\u62cd\u62cd", "\u7231\u56de\u6536"]
        result = []
        for n in names:
            if n in PLATFORM_PROFILES:
                result.append((n, PLATFORM_PROFILES[n]))
        return result

    def _build_reason(self, name: str, profile: Dict, cat: str, is_premium: bool) -> str:
        tags = " | ".join(profile["tags"])
        if is_premium:
            if name in ["\u95f2\u9c7c", "\u7b14\u8bb0\u672c\u5427"]:
                return f"\u7cbe\u54c1\u53ef\u6ea2\u4ef710-20%\uff0c{tags}\u3002\u5efa\u8bae\u591a\u62cd\u7ec6\u8282\u56fe+\u89c6\u9891\u9a8c\u673a\uff0c\u5f3a\u8c03\u5728\u4fdd\u72b6\u6001\u3002"
            elif name in ["\u8f6c\u8f6c", "\u4f18\u54c1\u62cd\u62cd"]:
                return f"\u63d0\u4f9b\u5b98\u65b9\u9a8c\u673a\u62a5\u544a\uff0c{tags}\u3002\u7cbe\u54c1\u6709\u9a8c\u673a\u80cc\u4e66\u66f4\u5bb9\u6613\u6210\u4ea4\u3002"
            elif name in ["\u4eac\u4e1c\u62cd\u62cd", "\u7231\u56de\u6536", "\u56de\u6536\u5b9d"]:
                return f"\u4ef7\u683c\u504f\u4f4e\u4f46\u6781\u901f\u5230\u8d26\uff0c{tags}\u3002\u9002\u5408\u6025\u7528\u94b1\u3001\u4e0d\u60f3\u6253\u5305\u7684\u573a\u666f\u3002"
        else:
            if name in ["\u95f2\u9c7c", "\u7b14\u8bb0\u672c\u5427"]:
                return f"\u81ea\u5b9a\u4ef7\u7075\u6d3b\uff0c{tags}\u3002\u5efa\u8bae\u5b9e\u62cd\u7ec6\u8282+\u5766\u8bda\u8bf4\u660e\u7455\u75b5\uff0c\u5b9a\u4ef7\u7565\u4f4e\u66f4\u6613\u6210\u4ea4\u3002"
            elif name in ["\u8f6c\u8f6c", "\u4f18\u54c1\u62cd\u62cd"]:
                return f"\u9a8c\u673a\u589e\u4fe1\u4efb\uff0c{tags}\u3002\u6210\u8272\u4e00\u822c\u7684\u7269\u54c1\u6709\u9a8c\u673a\u62a5\u544a\u66f4\u5bb9\u6613\u5356\u51fa\u3002"
            elif name in ["\u4eac\u4e1c\u62cd\u62cd", "\u7231\u56de\u6536", "\u56de\u6536\u5b9d"]:
                return f"\u56de\u6536\u4ef7\u4f4e\u4f46\u7701\u5fc3\uff0c{tags}\u3002\u6210\u8272\u4e00\u822c\u65f6\u4e0e\u5176\u4ed6\u5e73\u53f0\u5dee\u4ef7\u4e0d\u5927\uff0c\u7701\u53bb\u6c9f\u901a\u6210\u672c\u3002"
        return tags

    def recommend(self) -> List[PlatformRecommendation]:
        estimated = self._extract_market_price() or self._estimate_price()
        base_low, base_high = estimated
        cat = self._infer_category()
        grade = self.diagnosis.get("\u7efc\u5408\u8bc4\u7ea7", "")
        is_premium = "S" in grade or "A" in grade or "\u6781\u54c1" in grade or "\u4f18\u79c0" in grade
        platforms = self._select_platforms()

        api_key = os.getenv("OPENAI_API_KEY")
        if api_key:
            try:
                llm_recs = self._llm_recommend(base_low, base_high, cat, platforms)
                if llm_recs:
                    return llm_recs
            except Exception as e:
                print(f"\u63a8\u8350 LLM \u8c03\u7528\u5931\u8d25\uff0c\u4f7f\u7528\u89c4\u5219\u5156\u5e95: {e}")

        return self._rule_based_recommend(base_low, base_high, cat, is_premium, platforms)

    def _llm_recommend(self, base_low: int, base_high: int, cat: str, platforms: List) -> Optional[List[PlatformRecommendation]]:
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return None
        platform_info = ""
        for name, profile in platforms:
            ratio = profile["price_ratio"]
            p_low = int(base_low * ratio[0])
            p_high = int(base_high * ratio[1])
            platform_info += f"- {name}: \u4f30\u4ef7{p_low}-{p_high}\u5143\uff0c\u7279\u70b9\uff1a{'/'.join(profile['tags'])}\\n"

        system_prompt = (
            "\u4f60\u662f\u4e8c\u624b3C\u4ea7\u54c1\u4ea4\u6613\u5e73\u53f0\u63a8\u8350\u4e13\u5bb6\u3002"
            "\u6839\u636e\u7269\u54c1\u4fe1\u606f\u3001\u6210\u8272\u8bca\u65ad\u548c\u5404\u5e73\u53f0\u7279\u70b9\uff0c\u63a8\u8350\u6700\u9002\u5408\u7684 5 \u4e2a\u4ea4\u6613\u5e73\u53f0\u3002"
            "\u6bcf\u4e2a\u5e73\u53f0\u5fc5\u987b\u6709\u5dee\u5f02\u5316\u7684\u4ef7\u683c\u548c\u63a8\u8350\u7406\u7531\uff0c\u4f53\u73b0\u5404\u5e73\u53f0\u7684\u72ec\u7279\u4f18\u52bf\u3002"
        )
        user_prompt = (
            f"\u7269\u54c1\uff1a{self.brand} {self.model}\\n"
            f"\u63cf\u8ff0\uff1a{self.description}\\n"
            f"\u6210\u8272\uff1a{self.condition}\\n"
            f"\u8bca\u65ad\uff1a{self.diagnosis}\\n"
            f"\u77e5\u8bc6\u5e93\uff1a{self._knowledge_text()}\\n"
            f"\u57fa\u51c6\u4f30\u4ef7\uff1a{base_low}-{base_high}\u5143\\n\\n"
            f"\u5404\u5e73\u53f0\u4f30\u4ef7\u4e0e\u7279\u70b9\uff1a\\n{platform_info}\\n"
            "\u8bf7\u8fd4\u56de JSON \u6570\u7ec4\uff0c\u6bcf\u4e2a\u5143\u7d20\u683c\u5f0f\uff1a\\n"
            '{"name":"\u5e73\u53f0\u540d","reason":"\u5dee\u5f02\u5316\u63a8\u8350\u7406\u7531(30-60\u5b57)","price_range":"xxx-xxx\u5143","advantage":"\u8be5\u5e73\u53f0\u72ec\u7279\u4f18\u52bf(10-20\u5b57)"}'
        )
        llm = ChatOpenAI(
            model=os.getenv("OPENAI_MODEL", "glm-4-flash"),
            temperature=0.4,
            api_key=os.getenv("OPENAI_API_KEY", ""),
            base_url=os.getenv("OPENAI_BASE_URL", ""),
        )
        resp = llm.invoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ])
        raw = resp.content.strip()
        if raw.startswith("`"):
            raw = re.sub(r"^`(?:json)?", "", raw)
            raw = re.sub(r"`$", "", raw)
        items = json.loads(raw)
        recs = []
        for i, it in enumerate(items[:5], 1):
            recs.append(PlatformRecommendation(
                rank=i,
                name=str(it.get("name", "")),
                reason=str(it.get("reason", "")),
                price_range=str(it.get("price_range", "")),
                advantage=str(it.get("advantage", "")),
            ))
        return recs

    def _rule_based_recommend(self, base_low: int, base_high: int, cat: str, is_premium: bool, platforms: List) -> List[PlatformRecommendation]:
        recs = []
        for i, (name, profile) in enumerate(platforms, 1):
            ratio = profile["price_ratio"]
            p_low = int(base_low * ratio[0])
            p_high = int(base_high * ratio[1])
            reason = self._build_reason(name, profile, cat, is_premium)
            advantage = profile["tags"][0] if profile["tags"] else ""
            recs.append(PlatformRecommendation(
                rank=i, name=name, reason=reason,
                price_range=f"{p_low}-{p_high}\u5143",
                advantage=advantage,
            ))
        return recs

    def _knowledge_text(self) -> str:
        if not self.knowledge_results:
            return "(\u65e0\u77e5\u8bc6\u5e93\u6570\u636e)"
        lines = []
        for r in self.knowledge_results[:3]:
            lines.append(f"- {r.get('document', '')}")
        return "\\n".join(lines)

    def generate_report(self) -> str:
        recs = self.recommend()
        est = self._estimate_price()
        cat = self._infer_category()
        grade = self.diagnosis.get("\u7efc\u5408\u8bc4\u7ea7", "\u672a\u77e5")
        md = "## \u4ea4\u6613\u5e73\u53f0\u63a8\u8350\u62a5\u544a\\n\\n"
        md += f"**\u7269\u54c1\u7c7b\u522b**: {cat} | **\u8bca\u65ad\u8bc4\u7ea7**: {grade} | **\u57fa\u51c6\u4f30\u4ef7**: {est[0]}-{est[1]}\u5140\\n\\n"
        md += "| \u6392\u540d | \u5e73\u53f0 | \u5efa\u8bae\u552e\u4ef7 | \u72ec\u7279\u4f18\u52bf | \u63a8\u8350\u7406\u7531 |\\n"
        md += "|:---:|:---|:---:|:---|:---|\\n"
        for r in recs:
            adv = r.advantage if r.advantage else "-"
            md += f"| {r.rank} | **{r.name}** | {r.price_range} | {adv} | {r.reason} |\\n"
        md += "\\n### \u5404\u5e73\u53f0\u4ef7\u5dee\u5bf9\u6bd4\\n\\n"
        if len(recs) >= 2:
            prices = []
            for r in recs:
                m = re.search(r"(\\d+)-(\\d+)", r.price_range)
                if m:
                    prices.append((r.name, (int(m.group(1)) + int(m.group(2))) // 2))
            if len(prices) >= 2:
                prices.sort(key=lambda x: x[1], reverse=True)
                md += f"\u6700\u9ad8\u4ef7\u5e73\u53f0 **{prices[0][0]}** \u5747\u4ef7\u7ea6{prices[0][1]}\u5143\uff0c\u6700\u4f4e\u4ef7\u5e73\u53f0 **{prices[-1][0]}** \u5747\u4ef7\u7ea6{prices[-1][1]}\u5143\uff0c\u5dee\u4ef7\u7ea6{prices[0][1]-prices[-1][1]}\u5143\u3002\\n\\n"
        md += "### \u5c0f\u8d34\u58eb\\n\\n"
        md += "- \u7cbe\u54c1\u7269\u54c1\u4f18\u5148\u9009\u95f2\u9c7c/\u8bba\u575b\uff0c\u53ef\u6ea2\u4ef7 10-20%\\n"
        md += "- \u6025\u7528\u94b1\u9009\u7231\u56de\u6536/\u4eac\u4e1c\u62cd\u62cd\uff0c\u4ef7\u4f4e\u4f46\u6781\u901f\u5230\u8d26\\n"
        md += "- \u53d1\u5e03\u65f6\u591a\u62cd\u7ec6\u8282\u56fe+\u529f\u80fd\u89c6\u9891\uff0c\u6ce8\u660e\u5728\u4fdd\u72b6\u6001\\n"
        return md
"""
with open(path, "w", encoding="utf-8") as f:
    f.write(content)

try:
    compile(content, path, "exec")
    print("recommend.py: OK")
except SyntaxError as e:
    print(f"recommend.py: FAIL - {e}")