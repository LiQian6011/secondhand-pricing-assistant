import time
import requests
for i in range(10):
    try:
        r = requests.get("http://localhost:8000/api/health", timeout=3)
        print("OK:", r.text)
        break
    except Exception as e:
        print(f"retry {i+1}:", e)
        time.sleep(3)