with open("frontend/index.html", "r", encoding="utf-8") as f:
    content = f.read()
garbled = [c for c in "缁鍏澶鍔姣瀹" if c in content]
print("乱码:", "YES" if garbled else "NO")
print("app挂载点:", "YES" if 'id="app"' in content else "NO")
print("marked:", "YES" if "marked" in content else "NO")
print("app.js:", "YES" if "app.js" in content else "NO")
print("大小:", len(content))