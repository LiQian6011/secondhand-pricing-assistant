import os
BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"

def write(rel, content):
    path = os.path.join(BASE, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: {rel} ({len(content)} chars)")

# ===== recognizer.py =====
write("app/agents/recognizer.py", """import os
import json
import re
import base64
from typing import Dict, Optional
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

SYSTEM_PROMPT = (
    "\u4f60\u662f\u4e8c\u624b\u7269\u54c1\u8bc6\u522b\u4e13\u5bb6\u3002"
    "\u6839\u636e\u7528\u6237\u4e0a\u4f20\u7684\u7269\u54c1\u7167\u7247\uff0c\u8bc6\u522b\u51fa\u7269\u54c1\u7684\u54c1\u724c\u3001\u578b\u53f7\u3001\u6210\u8272\u72b6\u51b5\u548c\u8be6\u7ec6\u63cf\u8ff0\u3002"
    "\u8bf7\u4ed4\u7ec6\u89c2\u5bdf\u7167\u7247\u4e2d\u7684\u7269\u54c1\u5916\u89c2\u3001\u5c4f\u5e55\u72b6\u6001\u3001\u78e8\u635f\u60c5\u51b5\u3001\u914d\u4ef6\u7b49\u3002"
)

USER_PROMPT = (
    "\u8bf7\u8bc6\u522b\u8fd9\u5f20\u7167\u7247\u4e2d\u7684\u4e8c\u624b\u7269\u54c1\uff0c\u8fd4\u56de JSON \u683c\u5f0f\uff1a\\n"
    '{"brand":"\u54c1\u724c","model":"\u578b\u53f7","condition":"\u6210\u8272\u8bc4\u4f30","description":"\u8be6\u7ec6\u63cf\u8ff0"}\\n'
    "\u6ce8\u610f\uff1a\\n"
    "- brand: \u54c1\u724c\u540d\uff08\u5982Apple\u3001\u534e\u4e3a\u3001\u5c0f\u7c73\u7b49\uff09\\n"
    "- model: \u5177\u4f53\u578b\u53f7\uff08\u5982iPhone 14 Pro\u3001Mate 60 Pro\u7b49\uff09\\n"
    "- condition: \u4ece\u7167\u7247\u89c2\u5bdf\u6210\u8272\uff0c\u5982\u201c99\u65b0\u65e0\u5212\u75d5\u201d\u3001\u201c8\u6210\u65b0\u6709\u78e8\u635f\u201d\u7b49\\n"
    "- description: \u8be6\u7ec6\u63cf\u8ff0\u7269\u54c1\u72b6\u6001\uff0c\u5305\u62ec\u5916\u89c2\u3001\u5c4f\u5e55\u3001\u7535\u6c60\u3001\u529f\u80fd\u3001\u914d\u4ef6\u7b49\\n"
    "\u53ea\u8fd4\u56deJSON\uff0c\u4e0d\u8981\u5176\u4ed6\u5185\u5bb9\u3002"
)


def recognize_image(image_bytes: bytes, filename: str = "") -> Dict:
    api_key = os.getenv("OPENAI_API_KEY", "")
    base_url = os.getenv("OPENAI_BASE_URL", "")
    model = os.getenv("VISION_MODEL", "glm-4v-flash")

    if not api_key:
        return {"success": False, "message": "\u672a\u914d\u7f6eAPI Key"}

    ext = os.path.splitext(filename)[1].lower() if filename else ".jpg"
    mime_map = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp"}
    mime = mime_map.get(ext, "image/jpeg")

    b64 = base64.b64encode(image_bytes).decode("utf-8")
    image_url = f"data:{mime};base64,{b64}"

    llm = ChatOpenAI(
        model=model,
        temperature=0.1,
        api_key=api_key,
        base_url=base_url,
    )

    messages = [
        SystemMessage(content=SYSTEM_PROMPT),
        HumanMessage(content=[
            {"type": "text", "text": USER_PROMPT},
            {"type": "image_url", "image_url": {"url": image_url}},
        ]),
    ]

    try:
        resp = llm.invoke(messages)
        raw = resp.content.strip()
        if not raw:
            return {"success": False, "message": "LLM\u8fd4\u56de\u7a7a\u5185\u5bb9"}

        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", raw)
        if m:
            raw = m.group(1).strip()
        m2 = re.search(r"\{.*\}", raw, re.DOTALL)
        if m2:
            raw = m2.group(0)

        data = json.loads(raw)
        return {
            "success": True,
            "brand": str(data.get("brand", "")),
            "model": str(data.get("model", "")),
            "condition": str(data.get("condition", "")),
            "description": str(data.get("description", "")),
        }
    except json.JSONDecodeError as e:
        return {"success": False, "message": f"JSON\u89e3\u6790\u5931\u8d25: {e}"}
    except Exception as e:
        return {"success": False, "message": f"\u8bc6\u522b\u5931\u8d25: {e}"}
""")

# ===== api.py - add recognize endpoint =====
with open(os.path.join(BASE, "app/routes/api.py"), encoding="utf-8") as f:
    api_content = f.read()

if "recognize-image" not in api_content:
    api_content = api_content.replace(
        "from app.agents.plan import generate_plan_stream",
        "from app.agents.plan import generate_plan_stream\nfrom app.agents.recognizer import recognize_image"
    )
    api_content += '''

@router.post("/recognize-image", summary="\u56fe\u7247\u8bc6\u522b\u7269\u54c1\u4fe1\u606f")
async def recognize_image_endpoint(file: UploadFile = File(...)):
    image_bytes = await file.read()
    if len(image_bytes) > 10 * 1024 * 1024:
        return {"success": False, "message": "\u56fe\u7247\u5927\u5c0f\u8d85\u8fc710MB\u9650\u5236"}
    result = recognize_image(image_bytes, file.filename or "")
    return result
'''
    # Add UploadFile and File imports
    if "UploadFile" not in api_content:
        api_content = api_content.replace(
            "from fastapi import APIRouter, Request",
            "from fastapi import APIRouter, Request, UploadFile, File"
        )

with open(os.path.join(BASE, "app/routes/api.py"), "w", encoding="utf-8") as f:
    f.write(api_content)

try:
    compile(api_content, "api.py", "exec")
    print("api.py: OK")
except SyntaxError as e:
    print(f"api.py: FAIL - {e}")

# ===== app.js =====
with open(os.path.join(BASE, "frontend/app.js"), encoding="utf-8") as f:
    js_content = f.read()

# Add image upload data and methods
if "imagePreview" not in js_content:
    # Add to data()
    js_content = js_content.replace(
        '            error: null,',
        '            error: null,\n            imagePreview: null,\n            recognizing: false,'
    )
    # Add methods before go()
    js_content = js_content.replace(
        '        go(target) {',
        '''        async uploadImage(event) {
            const file = event.target.files[0];
            if (!file) return;
            if (!file.type.startsWith("image/")) {
                this.error = "\u8bf7\u4e0a\u4f20\u56fe\u7247\u6587\u4ef6";
                return;
            }
            if (file.size > 10 * 1024 * 1024) {
                this.error = "\u56fe\u7247\u5927\u5c0f\u4e0d\u80fd\u8d85\u8fc710MB";
                return;
            }
            this.imagePreview = URL.createObjectURL(file);
            this.recognizing = true;
            this.error = null;
            try {
                const formData = new FormData();
                formData.append("file", file);
                const res = await fetch(API_BASE + "/recognize-image", {
                    method: "POST",
                    body: formData,
                });
                const data = await res.json();
                if (data.success) {
                    if (data.description) this.form.description = data.description;
                    if (data.brand) this.form.brand = data.brand;
                    if (data.model) this.form.model = data.model;
                    if (data.condition) this.form.condition = data.condition;
                    this.autoFilled.brand = !!data.brand;
                    this.autoFilled.model = !!data.model;
                    this.autoFilled.condition = !!data.condition;
                    setTimeout(() => {
                        this.autoFilled.brand = false;
                        this.autoFilled.model = false;
                        this.autoFilled.condition = false;
                    }, 2000);
                } else {
                    this.error = data.message || "\u56fe\u7247\u8bc6\u522b\u5931\u8d25";
                }
            } catch (e) {
                this.error = "\u56fe\u7247\u8bc6\u522b\u5931\u8d25\uff1a" + e.message;
            }
            this.recognizing = false;
        },
        clearImage() {
            this.imagePreview = null;
            const input = document.getElementById("image-input");
            if (input) input.value = "";
        },
        go(target) {'''
    )

with open(os.path.join(BASE, "frontend/app.js"), "w", encoding="utf-8") as f:
    f.write(js_content)
print("app.js: OK")

# ===== index.html - add image upload area =====
with open(os.path.join(BASE, "frontend/index.html"), encoding="utf-8") as f:
    html_content = f.read()

if "image-input" not in html_content:
    # Add CSS for image upload
    html_content = html_content.replace(
        ".empty-hint{text-align:center;padding:60px 0;color:#bbb;font-size:16px}",
        """.empty-hint{text-align:center;padding:60px 0;color:#bbb;font-size:16px}
.upload-area{border:2px dashed #d0d0d0;border-radius:12px;padding:24px;text-align:center;cursor:pointer;transition:all .2s;margin-bottom:18px;position:relative}
.upload-area:hover{border-color:#667eea;background:#f8f9ff}
.upload-area.dragover{border-color:#667eea;background:#eef0ff}
.upload-icon{font-size:36px;color:#bbb;margin-bottom:8px}
.upload-text{color:#888;font-size:14px}
.upload-text em{color:#667eea;font-style:normal}
.img-preview{max-height:200px;max-width:100%;border-radius:8px;margin:8px 0}
.img-overlay{position:absolute;top:8px;right:8px;background:rgba(0,0,0,.5);color:#fff;border:none;border-radius:50%;width:28px;height:28px;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center}
.recognizing-overlay{position:absolute;inset:0;background:rgba(255,255,255,.85);display:flex;flex-direction:column;align-items:center;justify-content:center;border-radius:12px}"""
    )
    # Add image upload HTML before the description textarea
    html_content = html_content.replace(
        '  <div class="form-group">\n    <label>\u7269\u54c1\u63cf\u8ff0</label>',
        '''  <div class="form-group">
    <label>\u62cd\u7167/\u4e0a\u4f20\u7269\u54c1\u7167\u7247</label>
    <div class="upload-area" @click="$refs.imageInput.click()" @dragover.prevent="uploadAreaDragover=true" @dragleave="uploadAreaDragover=false" @drop.prevent="handleDrop" :class="{dragover: uploadAreaDragover}">
      <input ref="imageInput" id="image-input" type="file" accept="image/*" @change="uploadImage" style="display:none">
      <template v-if="imagePreview">
        <img :src="imagePreview" class="img-preview">
        <button class="img-overlay" @click.stop="clearImage">&times;</button>
      </template>
      <template v-else>
        <div class="upload-icon">&#128247;</div>
        <div class="upload-text">\u70b9\u51fb\u4e0a\u4f20\u6216\u62d6\u62fd\u7269\u54c1\u7167\u7247\uff0c<em>AI\u81ea\u52a8\u8bc6\u522b</em>\u54c1\u724c\u578b\u53f7\u6210\u8272</div>
      </template>
      <div v-if="recognizing" class="recognizing-overlay">
        <div class="spinner"></div>
        <div style="margin-top:8px;color:#667eea;font-size:14px">AI \u6b63\u5728\u8bc6\u522b\u7269\u54c1\u4fe1\u606f...</div>
      </div>
    </div>
  </div>
  <div class="form-group">
    <label>\u7269\u54c1\u63cf\u8ff0</label>'''
    )
    # Add uploadAreaDragover to data
    if "uploadAreaDragover" not in html_content:
        # We need to add it in app.js data
        pass

with open(os.path.join(BASE, "frontend/index.html"), "w", encoding="utf-8") as f:
    f.write(html_content)
print("index.html: OK")

# Add uploadAreaDragover and handleDrop to app.js
with open(os.path.join(BASE, "frontend/app.js"), encoding="utf-8") as f:
    js_content = f.read()

if "uploadAreaDragover" not in js_content:
    js_content = js_content.replace(
        "            recognizing: false,",
        "            recognizing: false,\n            uploadAreaDragover: false,"
    )
    js_content = js_content.replace(
        "        async uploadImage(event) {",
        """        handleDrop(event) {
            this.uploadAreaDragover = false;
            const file = event.dataTransfer.files[0];
            if (file && file.type.startsWith("image/")) {
                const fakeEvent = { target: { files: [file] } };
                this.uploadImage(fakeEvent);
            }
        },
        async uploadImage(event) {"""
    )

with open(os.path.join(BASE, "frontend/app.js"), "w", encoding="utf-8") as f:
    f.write(js_content)
print("app.js final: OK")

# Verify Python files
for f in ["app/agents/recognizer.py", "app/routes/api.py"]:
    path = os.path.join(BASE, f)
    content = open(path, encoding="utf-8").read()
    try:
        compile(content, f, "exec")
        print(f"VERIFY {f}: OK")
    except SyntaxError as e:
        print(f"VERIFY {f}: FAIL - {e}")

print("\nAll done!")