import sys
sys.path.insert(0, ".")
import app.main
import app.routes.api
import app.tools.price_lookup
print("ALL IMPORTS OK")