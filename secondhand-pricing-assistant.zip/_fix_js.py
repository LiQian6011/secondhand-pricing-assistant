path = "/home/wjx1202/projects/secondhand-pricing-assistant/frontend/app.js"
with open(path) as f:
    content = f.read()

old = """                let currentEvent = "";
                let currentData = "";
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split("\\n");
                    buffer = lines.pop();
                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (trimmed.startsWith("event:")) {
                            currentEvent = trimmed.slice(6).trim();
                            currentData = "";
                        } else if (trimmed.startsWith("data:")) {
                            currentData += (currentData ? "\\n" : "") + trimmed.slice(5).trim();
                        } else if (trimmed === "") {
                            if (currentEvent === "delta" && currentData) {
                                this.result.plan += currentData;
                            } else if (currentEvent === "end" && currentData) {
                                this.result.plan = currentData;
                            }
                            currentEvent = "";
                            currentData = "";
                        }
                    }
                }
                if (currentEvent === "delta" && currentData) { this.result.plan += currentData; }
                else if (currentEvent === "end" && currentData) { this.result.plan = currentData; }"""

new = """                let currentEvent = "";
                let currentData = "";
                let fullText = "";
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split("\\n");
                    buffer = lines.pop();
                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (trimmed.startsWith("event:")) {
                            currentEvent = trimmed.slice(6).trim();
                            currentData = "";
                        } else if (trimmed.startsWith("data:")) {
                            currentData += (currentData ? "\\n" : "") + trimmed.slice(5).trim();
                        } else if (trimmed === "") {
                            if (currentEvent === "delta" && currentData) {
                                fullText += currentData;
                            } else if (currentEvent === "end" && currentData) {
                                fullText = currentData;
                            }
                            currentEvent = "";
                            currentData = "";
                        }
                    }
                }
                if (currentEvent === "delta" && currentData) { fullText += currentData; }
                else if (currentEvent === "end" && currentData) { fullText = currentData; }
                this.result.plan = fullText;"""

content = content.replace(old, new)
with open(path, "w") as f:
    f.write(content)
print("app.js fixed - show final result only")