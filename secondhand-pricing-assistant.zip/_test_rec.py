import os, sys
sys.path.insert(0, "/home/wjx1202/projects/secondhand-pricing-assistant")
os.chdir("/home/wjx1202/projects/secondhand-pricing-assistant")
from dotenv import load_dotenv
load_dotenv()

from app.agents.recommend import RecommendAgent

agent = RecommendAgent(
    description="iPhone 14 Pro 256G 国行 在保到2025年12月 电池健康98% 屏幕无划痕 全功能正常 箱说全",
    brand="Apple",
    model="iPhone 14 Pro",
    condition="99新",
    diagnosis_result={"外观成色": 9.5, "功能完好性": 9.5, "配件完整度": 9.0, "保修与来源": 8.0, "综合评级": "A级：优秀", "总结": "核心卖点：外观成色优秀；功能完好"},
)

recs = agent.recommend()
print(f"Got {len(recs)} recommendations")
for r in recs:
    print(f"  {r.rank}. {r.name} | {r.price_range} | {r.advantage}")
    print(f"     {r.reason[:80]}...")

report = agent.generate_report()
print(f"\nReport length: {len(report)} chars")