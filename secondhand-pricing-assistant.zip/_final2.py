import py_compile, os, sys, importlib, re

BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"
os.chdir(BASE)
sys.path.insert(0, BASE)

errors = []
garbled_chars = "\u7f01\u9497\u566a\u9494\u59c9\u5bfa"

print("=" * 60)
print("\u6700\u7ec8\u5168\u9762\u68c0\u67e5")
print("=" * 60)

py_files = [
    "app/main.py", "app/routes/api.py", "app/agents/diagnosis.py",
    "app/agents/recommend.py", "app/agents/plan.py",
    "app/tools/price_lookup.py", "app/knowledge/vector_store.py",
]

# 1. Syntax
print("\n1. \u8bed\u6cd5\u68c0\u67e5")
for f in py_files:
    try:
        py_compile.compile(f, doraise=True)
        print(f"  [OK] {f}")
    except Exception as e:
        errors.append(f"\u8bed\u6cd5\u9519\u8bef {f}: {e}")
        print(f"  [FAIL] {f}: {e}")

# 2. Import
print("\n2. \u5bfc\u5165\u68c0\u67e5")
for m in ["app.main", "app.routes.api", "app.agents.diagnosis",
          "app.agents.recommend", "app.agents.plan",
          "app.tools.price_lookup", "app.knowledge.vector_store"]:
    try:
        importlib.import_module(m)
        print(f"  [OK] {m}")
    except Exception as e:
        errors.append(f"\u5bfc\u5165\u9519\u8bef {m}: {e}")
        print(f"  [FAIL] {m}: {e}")

# 3. Garbled text
print("\n3. \u4e71\u7801\u68c0\u67e5")
for f in py_files + ["frontend/index.html", "frontend/app.js"]:
    with open(f, "r", encoding="utf-8") as fh:
        content = fh.read()
    found = [c for c in garbled_chars if c in content]
    if found:
        errors.append(f"\u4e71\u7801 {f}")
        print(f"  [FAIL] {f}")
    else:
        print(f"  [OK] {f}")

# 4. Env vars
print("\n4. \u73af\u5883\u53d8\u91cf\u4e00\u81f4\u6027")
env_pattern = re.compile(r'os\.getenv\("([^"]+)"')
for f in ["app/agents/recommend.py", "app/agents/plan.py", "app/tools/price_lookup.py"]:
    with open(f, "r") as fh:
        envs = set(env_pattern.findall(fh.read()))
    if "OPENAI_API_KEY" in envs:
        print(f"  [OK] {f}: OPENAI_API_KEY present")
    else:
        errors.append(f"{f} \u7f3a\u5c11 OPENAI_API_KEY")
        print(f"  [FAIL] {f}")

# 5. .env
print("\n5. .env \u6587\u4ef6")
with open(".env", "r") as f:
    env = f.read()
if "OPENAI_API_KEY" in env:
    print("  [OK]")
else:
    errors.append(".env \u7f3a\u5c11 OPENAI_API_KEY")
    print("  [FAIL]")

# 6. Frontend
print("\n6. \u524d\u7aef\u6587\u4ef6")
for fn in ["frontend/index.html", "frontend/app.js"]:
    sz = os.path.getsize(fn)
    print(f"  {fn}: {sz} bytes {'OK' if sz > 100 else 'FAIL'}")

# 7. CSV
print("\n7. CSV \u6570\u636e")
with open("app/knowledge/secondhand_data.csv", "r", encoding="utf-8") as f:
    lines = f.readlines()
print(f"  {len(lines)-1} \u6761\u6570\u636e {'OK' if len(lines) > 2 else 'FAIL'}")

# 8. Runtime test
print("\n8. \u8fd0\u884c\u65f6\u6d4b\u8bd5")
from app.agents.diagnosis import DiagnosisAgent
agent = DiagnosisAgent(description="\u6d4b\u8bd5", brand="Apple", model="iPhone 14", condition="99\u65b0")
result = agent.diagnose().to_dict()
print(f"  diagnosis: \u7efc\u5408\u8bc4\u7ea7={result.get('\u7efc\u5408\u8bc4\u7ea7', 'MISSING')} {'OK' if '\u7efc\u5408\u8bc4\u7ea7' in result else 'FAIL'}")

from app.agents.recommend import RecommendAgent
agent2 = RecommendAgent(description="iPhone", brand="Apple", model="iPhone 14", condition="99\u65b0",
                         diagnosis_result={"\u7efc\u5408\u8bc4\u7ea7": "S\u7ea7\uff1a\u6781\u54c1", "\u5916\u89c2\u6210\u8272": 9, "\u529f\u80fd\u5b8c\u597d\u6027": 10})
fallback = agent2._rule_based_fallback(agent2._estimate_price())
print(f"  recommend \u5156\u5e95: {len(fallback)} \u4e2a\u63a8\u8350 {'OK' if len(fallback)==3 else 'FAIL'}")

print()
print("=" * 60)
if errors:
    print(f"\u53d1\u73b0 {len(errors)} \u4e2a\u95ee\u9898\uff1a")
    for i, e in enumerate(errors, 1):
        print(f"  {i}. {e}")
else:
    print("\u5168\u90e8\u68c0\u67e5\u901a\u8fc7\uff01\u65e0\u9519\u8bef\u3002")