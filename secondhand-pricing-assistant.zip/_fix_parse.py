path = "/home/wjx1202/projects/secondhand-pricing-assistant/app/agents/recommend.py"
with open(path, encoding="utf-8") as f:
    content = f.read()

# Fix 1: More robust JSON extraction from LLM response
old_parse = """        raw = resp.content.strip()
        if raw.startswith("`"):
            raw = re.sub(r"^`(?:json)?", "", raw)
            raw = re.sub(r"`$", "", raw)
        items = json.loads(raw)"""

new_parse = """        raw = resp.content.strip()
        if not raw:
            return None
        # Extract JSON from markdown code blocks
        m = re.search(r"```(?:json)?\\s*([\\s\\S]*?)```", raw)
        if m:
            raw = m.group(1).strip()
        # Try to find JSON array directly
        m2 = re.search(r"\\[.*\\]", raw, re.DOTALL)
        if m2:
            raw = m2.group(0)
        items = json.loads(raw)"""

content = content.replace(old_parse, new_parse)

# Fix 2: Add better error logging
old_except = """            except Exception as e:
                print(f"\\u63a8\\u8350 LLM \\u8c03\\u7528\\u5931\\u8d25\\uff0c\\u4f7f\\u7528\\u89c4\\u5219\\u5156\\u5e95: {e}")"""

new_except = """            except Exception as e:
                print(f"\\u63a8\\u8350 LLM \\u8c03\\u7528\\u5931\\u8d25\\uff0c\\u4f7f\\u7528\\u89c4\\u5219\\u5156\\u5e95: {e}")
                import traceback
                traceback.print_exc()"""

content = content.replace(old_except, new_except)

with open(path, "w", encoding="utf-8") as f:
    f.write(content)

try:
    compile(content, path, "exec")
    print("recommend.py: OK")
except SyntaxError as e:
    print(f"recommend.py: FAIL - {e}")