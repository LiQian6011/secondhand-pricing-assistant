import requests, json
BASE = "http://localhost:8000/api"

# 1. 诊断
r = requests.post(BASE + "/diagnose", json={
    "description": "iPhone 14 Pro 256G 国行 在保3个月 电池健康92% 外观无划痕 功能正常 箱说全",
    "brand": "Apple",
    "model": "iPhone 14 Pro",
    "condition": "99新",
})
print("=== 诊断 ===")
print(json.dumps(r.json(), ensure_ascii=False, indent=2))

# 2. 平台推荐
r = requests.post(BASE + "/recommend", json={
    "description": "iPhone 14 Pro 256G 国行 在保3个月 电池健康92% 外观无划痕 功能正常 箱说全",
    "brand": "Apple",
    "model": "iPhone 14 Pro",
    "condition": "99新",
})
print("=== 推荐 ===")
print(json.dumps(r.json(), ensure_ascii=False, indent=2))