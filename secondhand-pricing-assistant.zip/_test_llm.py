import os
from dotenv import load_dotenv
load_dotenv()

print("API Key:", os.getenv("OPENAI_API_KEY", "")[:10] + "...")
print("Base URL:", os.getenv("OPENAI_BASE_URL"))
print("Model:", os.getenv("OPENAI_MODEL"))

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

llm = ChatOpenAI(
    model=os.getenv("OPENAI_MODEL", "glm-4-flash"),
    temperature=0.3,
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL"),
)
try:
    resp = llm.invoke([HumanMessage(content="你好，请用一句话回复")])
    print("LLM 响应:", resp.content)
except Exception as e:
    print("LLM 错误:", e)