import py_compile, os, sys, importlib, re

BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"
os.chdir(BASE)
sys.path.insert(0, BASE)

errors = []
garbled_chars = "缁鍏澶鍔姣瀹"

print("=" * 60)
print("最终全面检查")
print("=" * 60)

# 1. Python 语法 + 导入
py_files = [
    "app/main.py", "app/routes/api.py", "app/agents/diagnosis.py",
    "app/agents/recommend.py", "app/agents/plan.py",
    "app/tools/price_lookup.py", "app/knowledge/vector_store.py",
]
for f in py_files:
    try:
        py_compile.compile(f, doraise=True)
    except Exception as e:
        errors.append(f"语法错误 {f}: {e}")
        print(f"  [FAIL] 语法: {f}")

modules = ["app.main", "app.routes.api", "app.agents.diagnosis",
           "app.agents.recommend", "app.agents.plan",
           "app.tools.price_lookup", "app.knowledge.vector_store"]
for m in modules:
    try:
        importlib.import_module(m)
    except Exception as e:
        errors.append(f"导入错误 {m}: {e}")
        print(f"  [FAIL] 导入: {m}")

print(f"  Python 语法+导入: {'FAIL' if errors else 'OK'}")

# 2. 乱码检查
for f in py_files + ["frontend/index.html", "frontend/app.js"]:
    with open(f, "r", encoding="utf-8") as fh:
        content = fh.read()
    found = [c for c in garbled_chars if c in content]
    if found:
        errors.append(f"乱码 {f}: {found}")
        print(f"  [FAIL] 乱码: {f}")
print(f"  乱码检查: {'FAIL' if any('乱码' in e for e in errors) else 'OK'}")

# 3. 环境变量一致性
env_pattern = re.compile(r'os\.getenv\("([^"]+)"')
all_envs = set()
for f in ["app/agents/recommend.py", "app/agents/plan.py", "app/tools/price_lookup.py"]:
    with open(f, "r") as fh:
        envs = set(env_pattern.findall(fh.read()))
        all_envs.update(envs)
primary = {"OPENAI_API_KEY", "OPENAI_BASE_URL", "OPENAI_MODEL"}
if primary.issubset(all_envs):
    print(f"  环境变量: OK (使用 {sorted(primary)})")
else:
    errors.append(f"环境变量不一致: 缺少 {primary - all_envs}")
    print(f"  [FAIL] 环境变量不一致")

# 4. .env 文件
with open(".env", "r") as f:
    env = f.read()
if "OPENAI_API_KEY" in env:
    print("  .env: OK (有模板)")
else:
    errors.append(".env 缺少 OPENAI_API_KEY")
    print("  [FAIL] .env 缺少配置")

# 5. 前端文件
for fn in ["frontend/index.html", "frontend/app.js"]:
    sz = os.path.getsize(fn)
    if sz < 100:
        errors.append(f"{fn} 文件过小 ({sz} bytes)")
        print(f"  [FAIL] {fn} 过小")
    else:
        print(f"  {fn}: OK ({sz} bytes)")

# 6. CSV 数据
with open("app/knowledge/secondhand_data.csv", "r", encoding="utf-8") as f:
    lines = f.readlines()
if len(lines) >= 2:
    print(f"  CSV: OK ({len(lines)-1} 条数据)")
else:
    errors.append("CSV 数据不足")
    print("  [FAIL] CSV 数据不足")

# 7. diagnosis 运行时测试
from app.agents.diagnosis import DiagnosisAgent
agent = DiagnosisAgent(description="测试", brand="Apple", model="iPhone 14", condition="99新")
result = agent.diagnose().to_dict()
if "综合评级" in result:
    print(f"  diagnosis 运行时: OK (评级={result['综合评级']})")
else:
    errors.append("diagnosis 运行时缺少综合评级")
    print("  [FAIL] diagnosis 运行时")

# 8. recommend 兜底测试
from app.agents.recommend import RecommendAgent
agent2 = RecommendAgent(description="iPhone", brand="Apple", model="iPhone 14", condition="99新",
                         diagnosis_result={"综合评级": "S级", "外观成色": 9, "功能完好性": 10})
fallback = agent2._rule_based_fallback(agent2._estimate_price())
if len(fallback) == 3:
    print(f"  recommend 兜底: OK ({len(fallback)} 个推荐)")
else:
    errors.append(f"recommend 兜底异常: {len(fallback)} 个")
    print(f"  [FAIL] recommend 兜底: {len(fallback)} 个")

print()
print("=" * 60)
if errors:
    print(f"发现 {len(errors)} 个问题：")
    for i, e in enumerate(errors, 1):
        print(f"  {i}. {e}")
else:
    print("全部检查通过！无错误。")