import os

BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"

def write(rel_path, content):
    path = os.path.join(BASE, rel_path)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: {rel_path} ({len(content)} chars)")

# ===== index.html =====
write("frontend/index.html", r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>二手闲置定价智能助手</title>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#f0f2f5;min-height:100vh}

.nav{background:linear-gradient(135deg,#667eea,#764ba2);padding:16px 24px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 2px 12px rgba(0,0,0,.15)}
.nav h1{color:#fff;font-size:20px;cursor:pointer}
.nav-tabs{display:flex;gap:8px}
.nav-tab{padding:8px 20px;border-radius:8px;border:none;font-size:14px;font-weight:600;cursor:pointer;transition:all .2s;color:rgba(255,255,255,.7);background:transparent}
.nav-tab:hover{color:#fff;background:rgba(255,255,255,.15)}
.nav-tab.active{color:#764ba2;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.1)}

.page{max-width:900px;margin:24px auto;padding:0 20px}
.card{background:#fff;border-radius:12px;padding:28px;box-shadow:0 2px 12px rgba(0,0,0,.06);margin-bottom:20px}
.card-title{font-size:18px;font-weight:700;color:#333;margin-bottom:20px;padding-bottom:12px;border-bottom:2px solid #667eea;display:flex;align-items:center;gap:8px}

.form-group{margin-bottom:18px}
.form-group label{display:block;margin-bottom:6px;font-weight:600;color:#555;font-size:14px}
.form-group input,.form-group textarea{width:100%;padding:10px 14px;border:2px solid #e0e0e0;border-radius:8px;font-size:14px;transition:border-color .2s}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:#667eea}
.form-group textarea{min-height:90px;resize:vertical}
.row{display:flex;gap:14px}
.row .form-group{flex:1}

.btn-row{display:flex;gap:12px;margin-top:20px}
.btn{flex:1;padding:12px 20px;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;transition:all .2s;color:#fff}
.btn-d{background:#667eea}.btn-d:hover{background:#5a6fd6;transform:translateY(-1px)}
.btn-r{background:#764ba2}.btn-r:hover{background:#6a4190;transform:translateY(-1px)}
.btn-p{background:linear-gradient(135deg,#f093fb,#f5576c)}.btn-p:hover{transform:translateY(-1px)}
.btn:disabled{opacity:.5;cursor:not-allowed;transform:none!important}
.btn-back{background:#f0f2f5;color:#555;border:2px solid #e0e0e0;flex:none;padding:10px 24px}
.btn-back:hover{border-color:#667eea;color:#667eea}

.result{padding:8px 0}
.result table{width:100%;border-collapse:collapse;margin:12px 0;background:#fafafa;border-radius:8px;overflow:hidden}
.result th,.result td{padding:10px 14px;text-align:left;border-bottom:1px solid #eee;font-size:14px}
.result th{background:#667eea;color:#fff;font-weight:600}
.result tr:hover{background:#f0f2f5}

.plan-content{line-height:1.8;color:#444}
.plan-content p{margin-bottom:8px}
.plan-content ul,.plan-content ol{margin:8px 0 8px 20px}
.plan-content h1,.plan-content h2,.plan-content h3,.plan-content h4{margin:16px 0 8px;color:#333}

.loading-box{text-align:center;padding:40px 0}
.spinner{display:inline-block;width:32px;height:32px;border:3px solid #e0e0e0;border-top-color:#667eea;border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.loading-text{margin-top:12px;color:#888;font-size:14px}

.empty-hint{text-align:center;padding:60px 0;color:#bbb;font-size:16px}

.fade-enter{opacity:0;transform:translateY(10px)}
.fade-active{transition:all .3s}
</style>
</head>
<body>
<div id="app">

<div class="nav">
  <h1 @click="go('home')">&#128230; 二手定价助手</h1>
  <div class="nav-tabs">
    <button class="nav-tab" :class="{active:page==='diagnosis'}" @click="go('diagnosis')">&#128269; 成色诊断</button>
    <button class="nav-tab" :class="{active:page==='recommend'}" @click="go('recommend')">&#128640; 平台推荐</button>
    <button class="nav-tab" :class="{active:page==='plan'}" @click="go('plan')">&#9997;&#65039; 定价策略</button>
  </div>
</div>

<div class="page">

<!-- HOME -->
<div v-if="page==='home'" class="card">
  <div class="card-title">&#128221; 物品信息录入</div>
  <div class="form-group">
    <label>物品描述</label>
    <textarea v-model="form.description" placeholder="请详细描述物品状况，例如：iPhone 14 Pro 256G 国行 在保3个月 电池健康92% 外观无划痕 功能正常 箱说全"></textarea>
  </div>
  <div class="row">
    <div class="form-group"><label>品牌</label><input v-model="form.brand" placeholder="如：Apple、华为、小米"></div>
    <div class="form-group"><label>型号</label><input v-model="form.model" placeholder="如：iPhone 14 Pro"></div>
  </div>
  <div class="form-group"><label>成色补充</label><input v-model="form.condition" placeholder="如：99新、轻微划痕、无拆修"></div>
  <div class="btn-row">
    <button class="btn btn-d" @click="go('diagnosis')" :disabled="!form.description">&#128269; 成色诊断</button>
    <button class="btn btn-r" @click="go('recommend')" :disabled="!form.description">&#128640; 平台推荐</button>
    <button class="btn btn-p" @click="go('plan')" :disabled="!form.description">&#9997;&#65039; 定价策略</button>
  </div>
</div>

<!-- DIAGNOSIS PAGE -->
<div v-if="page==='diagnosis'">
  <div class="card">
    <div class="card-title">&#128269; 成色诊断报告
      <button class="btn btn-back" @click="go('home')" style="margin-left:auto">&#8592; 返回</button>
    </div>
    <div v-if="loading.diagnosis" class="loading-box">
      <div class="spinner"></div>
      <div class="loading-text">正在诊断成色...</div>
    </div>
    <div v-else-if="result.diagnosis" class="result" v-html="renderMarkdown(result.diagnosis.report)"></div>
    <div v-else class="empty-hint">暂无诊断结果，请先在首页填写物品信息</div>
  </div>
</div>

<!-- RECOMMEND PAGE -->
<div v-if="page==='recommend'">
  <div class="card">
    <div class="card-title">&#128640; 交易平台推荐
      <button class="btn btn-back" @click="go('home')" style="margin-left:auto">&#8592; 返回</button>
    </div>
    <div v-if="loading.recommend" class="loading-box">
      <div class="spinner"></div>
      <div class="loading-text">正在推荐平台...</div>
    </div>
    <div v-else-if="result.recommend" class="result" v-html="renderMarkdown(result.recommend.report)"></div>
    <div v-else class="empty-hint">暂无推荐结果，请先在首页填写物品信息</div>
  </div>
</div>

<!-- PLAN PAGE -->
<div v-if="page==='plan'">
  <div class="card">
    <div class="card-title">&#9997;&#65039; 定价策略方案
      <button class="btn btn-back" @click="go('home')" style="margin-left:auto">&#8592; 返回</button>
    </div>
    <div v-if="loading.plan && !result.plan" class="loading-box">
      <div class="spinner"></div>
      <div class="loading-text">正在生成定价策略...</div>
    </div>
    <div v-else-if="result.plan" class="plan-content" v-html="renderMarkdown(result.plan)"></div>
    <div v-else class="empty-hint">暂无定价策略，请先在首页填写物品信息</div>
  </div>
</div>

<div v-if="error" style="background:#fdf2f2;color:#e74c3c;padding:14px 20px;border-radius:8px;margin-bottom:20px;font-size:14px">&#10060; {{ error }}</div>

</div>
</div>

<script src="/static/app.js"></script>
</body>
</html>
""")

# ===== app.js =====
write("frontend/app.js", r"""const { createApp } = Vue;
const API_BASE = window.location.origin + "/api";

createApp({
    data() {
        return {
            page: "home",
            form: { description: "", brand: "", model: "", condition: "" },
            loading: { diagnosis: false, recommend: false, plan: false },
            result: { diagnosis: null, recommend: null, plan: "" },
            error: null,
        };
    },
    methods: {
        renderMarkdown(text) {
            if (!text) return "";
            return marked.parse(text);
        },
        go(target) {
            this.error = null;
            if (target === "diagnosis") {
                this.page = "diagnosis";
                
            } else if (target === "recommend") {
                this.page = "recommend";
                
            } else if (target === "plan") {
                this.page = "plan";
                
            } else {
                this.page = "home";
            }
        },
        async runDiagnosis() {
            this.loading.diagnosis = true;
            this.error = null;
            try {
                const res = await fetch(API_BASE + "/diagnose", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(this.form),
                });
                const data = await res.json();
                if (data.success) { this.result.diagnosis = data; }
                else { this.error = data.message || "诊断失败"; }
            } catch (e) { this.error = "网络错误：" + e.message; }
            this.loading.diagnosis = false;
        },
        async runRecommend() {
            this.loading.recommend = true;
            this.error = null;
            try {
                const payload = Object.assign({}, this.form);
                if (this.result.diagnosis) { payload.diagnosis = this.result.diagnosis.data; }
                const res = await fetch(API_BASE + "/recommend", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload),
                });
                const data = await res.json();
                if (data.success) {
                    this.result.recommend = data;
                    if (data.diagnosis) { this.result.diagnosis = { data: data.diagnosis, report: "" }; }
                } else { this.error = data.message || "推荐失败"; }
            } catch (e) { this.error = "网络错误：" + e.message; }
            this.loading.recommend = false;
        },
        async runPlan() {
            this.loading.plan = true;
            this.error = null;
            this.result.plan = "";
            try {
                const res = await fetch(API_BASE + "/generate-plan", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(this.form),
                });
                const reader = res.body.getReader();
                const decoder = new TextDecoder();
                let buffer = "";
                let currentEvent = "";
                let currentData = "";
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split("\n");
                    buffer = lines.pop();
                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (trimmed.startsWith("event:")) {
                            currentEvent = trimmed.slice(6).trim();
                            currentData = "";
                        } else if (trimmed.startsWith("data:")) {
                            currentData += (currentData ? "\n" : "") + trimmed.slice(5).trim();
                        } else if (trimmed === "") {
                            if (currentEvent === "delta" && currentData) {
                                this.result.plan += currentData;
                            } else if (currentEvent === "end" && currentData) {
                                this.result.plan = currentData;
                            }
                            currentEvent = "";
                            currentData = "";
                        }
                    }
                }
                if (currentEvent === "delta" && currentData) { this.result.plan += currentData; }
                else if (currentEvent === "end" && currentData) { this.result.plan = currentData; }
            } catch (e) { this.error = "网络错误：" + e.message; }
            this.loading.plan = false;
        },
    },
}).mount("#app");
""")

print("Frontend rewritten with multi-page navigation!")