import os
BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"

def write(rel, content):
    path = os.path.join(BASE, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    print(f"OK: {rel} ({len(content)} chars)")

# ===== recognizer.py =====
write("app/agents/recognizer.py", """import os
import json
import re
import base64
from typing import Dict
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

INFO_SYSTEM = (
    "\u4f60\u662f\u8bbe\u5907\u4fe1\u606f\u8bc6\u522b\u4e13\u5bb6\u3002"
    "\u7528\u6237\u4e0a\u4f20\u7684\u662f\u8bbe\u5907\u4fe1\u606f\u622a\u56fe\uff08\u5982\u624b\u673a\u201c\u5173\u4e8e\u672c\u673a\u201d\u9875\u9762\u3001\u7535\u8111\u7cfb\u7edf\u4fe1\u606f\u3001\u8d2d\u4e70\u51ed\u8bc1\u7b49\uff09\u3002"
    "\u8bf7\u4ece\u622a\u56fe\u4e2d\u63d0\u53d6\u5173\u952e\u6587\u5b57\u4fe1\u606f\uff0c\u8bc6\u522b\u54c1\u724c\u3001\u578b\u53f7\u3001\u5b58\u50a8\u5bb9\u91cf\u3001\u7535\u6c60\u5065\u5eb7\u3001\u4fdd\u4fee\u72b6\u6001\u7b49\u3002"
)

INFO_USER = (
    "\u8bf7\u8bc6\u522b\u8fd9\u5f20\u8bbe\u5907\u4fe1\u606f\u622a\u56fe\u4e2d\u7684\u5173\u952e\u4fe1\u606f\uff0c\u8fd4\u56de JSON\uff1a\\n"
    '{"brand":"\u54c1\u724c","model":"\u578b\u53f7","description":"\u8be6\u7ec6\u63cf\u8ff0"}\\n'
    "\u8bf4\u660e\uff1a\\n"
    "- brand: \u54c1\u724c\uff08\u5982Apple\u3001\u534e\u4e3a\u3001\u5c0f\u7c73\uff09\\n"
    "- model: \u578b\u53f7\uff08\u5982iPhone 14 Pro 256G\u3001Mate 60 Pro 512G\uff09\\n"
    "- description: \u622a\u56fe\u4e2d\u6240\u6709\u6709\u7528\u4fe1\u606f\u7684\u8be6\u7ec6\u63cf\u8ff0\uff0c\u5305\u62ec\u5b58\u50a8\u3001\u7535\u6c60\u5065\u5eb7\u3001\u7cfb\u7edf\u7248\u672c\u3001\u4fdd\u4fee\u72b6\u6001\u7b49\\n"
    "\u53ea\u8fd4\u56deJSON\u3002"
)

APPEARANCE_SYSTEM = (
    "\u4f60\u662f\u4e8c\u624b\u8bbe\u5907\u6210\u8272\u8bc4\u4f30\u4e13\u5bb6\u3002"
    "\u7528\u6237\u4e0a\u4f20\u7684\u662f\u8bbe\u5907\u5916\u89c2\u7167\u7247\u3002"
    "\u8bf7\u4ed4\u7ec6\u89c2\u5bdf\u7167\u7247\u4e2d\u8bbe\u5907\u7684\u5916\u89c2\u72b6\u6001\uff0c\u5305\u62ec\u5c4f\u5e55\u3001\u8fb9\u6846\u3001\u80cc\u677f\u3001\u6309\u952e\u3001\u63a5\u53e3\u7b49\u90e8\u4f4d\u7684\u78e8\u635f\u3001\u5212\u75d5\u3001\u78d5\u78d5\u3001\u53d8\u8272\u60c5\u51b5\u3002"
)

APPEARANCE_USER = (
    "\u8bf7\u8bc4\u4f30\u8fd9\u5f20\u8bbe\u5907\u5916\u89c2\u7167\u7247\u7684\u6210\u8272\u72b6\u6001\uff0c\u8fd4\u56de JSON\uff1a\\n"
    '{"condition":"\u6210\u8272\u8bc4\u4f30","details":"\u5916\u89c2\u8be6\u7ec6\u8bf4\u660e"}\\n'
    "\u8bf4\u660e\uff1a\\n"
    "- condition: \u6210\u8272\u7b49\u7ea7+\u7b80\u8981\u8bf4\u660e\uff08\u5982\u201c99\u65b0 \u5c4f\u5e55\u65e0\u5212\u75d5\u201d\u3001\u201c85\u65b0 \u8fb9\u89d2\u8f7b\u5fae\u78d5\u78d5\u201d\u3001\u201c7\u6210\u65b0 \u5c4f\u5e55\u6709\u5212\u75d5\u80cc\u677f\u78e8\u635f\u201d\uff09\\n"
    "- details: \u9010\u90e8\u4f4d\u8bf4\u660e\u5916\u89c2\u72b6\u6001\uff08\u5c4f\u5e55\u3001\u8fb9\u6846\u3001\u80cc\u677f\u3001\u6309\u952e\u3001\u63a5\u53e3\u7b49\uff09\\n"
    "\u53ea\u8fd4\u56deJSON\u3002"
)


def _call_vision(system: str, user: str, image_bytes: bytes, filename: str) -> Dict:
    api_key = os.getenv("OPENAI_API_KEY", "")
    base_url = os.getenv("OPENAI_BASE_URL", "")
    model = os.getenv("VISION_MODEL", "glm-4v-flash")
    if not api_key:
        return {"success": False, "message": "\u672a\u914d\u7f6eAPI Key"}
    ext = os.path.splitext(filename)[1].lower() if filename else ".jpg"
    mime_map = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp"}
    mime = mime_map.get(ext, "image/jpeg")
    b64 = base64.b64encode(image_bytes).decode("utf-8")
    image_url = f"data:{mime};base64,{b64}"
    llm = ChatOpenAI(model=model, temperature=0.1, api_key=api_key, base_url=base_url)
    messages = [
        SystemMessage(content=system),
        HumanMessage(content=[
            {"type": "text", "text": user},
            {"type": "image_url", "image_url": {"url": image_url}},
        ]),
    ]
    try:
        resp = llm.invoke(messages)
        raw = resp.content.strip()
        if not raw:
            return {"success": False, "message": "LLM\u8fd4\u56de\u7a7a\u5185\u5bb9"}
        m = re.search(r"```(?:json)?\\s*([\\s\\S]*?)```", raw)
        if m:
            raw = m.group(1).strip()
        m2 = re.search(r"\\{.*\\}", raw, re.DOTALL)
        if m2:
            raw = m2.group(0)
        data = json.loads(raw)
        return {"success": True, **data}
    except json.JSONDecodeError as e:
        return {"success": False, "message": f"JSON\u89e3\u6790\u5931\u8d25: {e}"}
    except Exception as e:
        return {"success": False, "message": f"\u8bc6\u522b\u5931\u8d25: {e}"}


def recognize_info_image(image_bytes: bytes, filename: str = "") -> Dict:
    return _call_vision(INFO_SYSTEM, INFO_USER, image_bytes, filename)


def recognize_appearance_image(image_bytes: bytes, filename: str = "") -> Dict:
    return _call_vision(APPEARANCE_SYSTEM, APPEARANCE_USER, image_bytes, filename)
""")

# ===== api.py =====
write("app/routes/api.py", """from fastapi import APIRouter, Request, UploadFile, File
from pydantic import BaseModel
from typing import Optional
from app.agents.diagnosis import DiagnosisAgent
from app.agents.recommend import RecommendAgent
from app.agents.plan import generate_plan_stream
from app.agents.recognizer import recognize_info_image, recognize_appearance_image
from app.tools.price_lookup import get_price_lookup_tool

router = APIRouter(prefix="/api", tags=["secondhand"])


class DiagnosisRequest(BaseModel):
    description: str
    brand: Optional[str] = ""
    model: Optional[str] = ""
    condition: Optional[str] = ""


class RecommendRequest(BaseModel):
    description: str
    brand: Optional[str] = ""
    model: Optional[str] = ""
    condition: Optional[str] = ""
    diagnosis: Optional[dict] = None


class PlanRequest(BaseModel):
    description: str
    brand: Optional[str] = ""
    model: Optional[str] = ""
    condition: Optional[str] = ""


class PriceLookupRequest(BaseModel):
    query: str


@router.post("/diagnose", summary="\u7269\u54c1\u6210\u8272\u8bca\u65ad")
async def diagnose_item(request: DiagnosisRequest):
    agent = DiagnosisAgent(
        description=request.description,
        brand=request.brand or "",
        model=request.model or "",
        condition=request.condition or "",
    )
    result = agent.diagnose()
    return {
        "success": True,
        "data": result.to_dict(),
        "report": agent.generate_report(),
    }


@router.post("/recommend", summary="\u4ea4\u6613\u5e73\u53f0\u63a8\u8350\uff08Top-3\uff09")
async def recommend_platforms(request: RecommendRequest):
    from app.knowledge.vector_store import get_vector_store

    diagnosis = request.diagnosis
    if not diagnosis:
        diag_agent = DiagnosisAgent(
            description=request.description,
            brand=request.brand or "",
            model=request.model or "",
            condition=request.condition or "",
        )
        diagnosis = diag_agent.diagnose().to_dict()

    knowledge_results = []
    try:
        vector_store = get_vector_store()
        query = f"{request.brand} {request.model} {request.description}".strip()
        knowledge_results = vector_store.search(query, top_k=3)
    except Exception as e:
        print(f"\u5411\u91cf\u68c0\u7d22\u5931\u8d25: {e}")

    agent = RecommendAgent(
        description=request.description,
        brand=request.brand or "",
        model=request.model or "",
        condition=request.condition or "",
        diagnosis_result=diagnosis,
        knowledge_results=knowledge_results,
    )
    recs = agent.recommend()
    return {
        "success": True,
        "diagnosis": diagnosis,
        "knowledge_references": [
            {"document": r.get("document", ""), "metadata": r.get("metadata", {})}
            for r in knowledge_results
        ],
        "recommendations": [
            {"rank": r.rank, "name": r.name, "reason": r.reason, "price_range": r.price_range}
            for r in recs
        ],
        "report": agent.generate_report(),
    }


@router.post("/generate-plan", summary="\u5b9a\u4ef7\u7b56\u7565\u65b9\u6848\u751f\u6210\uff08SSE\u6d41\u5f0f\uff09")
async def generate_plan_endpoint(request: Request, plan_request: PlanRequest):
    from sse_starlette.sse import EventSourceResponse

    async def event_generator():
        async for event in generate_plan_stream(
            description=plan_request.description,
            brand=plan_request.brand or "",
            model=plan_request.model or "",
            condition=plan_request.condition or "",
        ):
            if await request.is_disconnected():
                break
            yield event

    return EventSourceResponse(event_generator(), media_type="text/event-stream")


@router.post("/recognize-info", summary="\u8bbe\u5907\u4fe1\u606f\u622a\u56fe\u8bc6\u522b")
async def recognize_info_endpoint(file: UploadFile = File(...)):
    image_bytes = await file.read()
    if len(image_bytes) > 10 * 1024 * 1024:
        return {"success": False, "message": "\u56fe\u7247\u5927\u5c0f\u8d85\u8fc710MB\u9650\u5236"}
    result = recognize_info_image(image_bytes, file.filename or "")
    return result


@router.post("/recognize-appearance", summary="\u8bbe\u5907\u5916\u89c2\u7167\u7247\u8bc6\u522b")
async def recognize_appearance_endpoint(file: UploadFile = File(...)):
    image_bytes = await file.read()
    if len(image_bytes) > 10 * 1024 * 1024:
        return {"success": False, "message": "\u56fe\u7247\u5927\u5c0f\u8d85\u8fc710MB\u9650\u5236"}
    result = recognize_appearance_image(image_bytes, file.filename or "")
    return result


@router.post("/price-lookup", summary="\u67e5\u8be2\u4e8c\u624b\u5e02\u573a\u53c2\u8003\u4ef7")
async def price_lookup(request: PriceLookupRequest):
    tool = get_price_lookup_tool()
    result = tool._run(request.query)
    return {"success": True, "query": request.query, "price": result}


@router.get("/health", summary="\u5065\u5eb7\u68c0\u67e5")
async def health_check():
    return {"status": "ok", "service": "secondhand-pricing-assistant"}
""")

# ===== app.js =====
write("frontend/app.js", r"""const { createApp } = Vue;
const API_BASE = window.location.origin + "/api";

const BRAND_MAP = {
    "iphone": "Apple", "ipad": "Apple", "macbook": "Apple", "imac": "Apple",
    "airpods": "Apple", "apple watch": "Apple", "mac mini": "Apple",
    "huawei": "\u534e\u4e3a", "mate": "\u534e\u4e3a", "pura": "\u534e\u4e3a", "nova": "\u534e\u4e3a",
    "xiaomi": "\u5c0f\u7c73", "redmi": "\u5c0f\u7c73", "\u7ea2\u7c73": "\u5c0f\u7c73", "mi ": "\u5c0f\u7c73",
    "oppo": "OPPO", "reno": "OPPO", "find": "OPPO",
    "vivo": "vivo", "iqoo": "vivo",
    "samsung": "\u4e09\u661f", "galaxy": "\u4e09\u661f",
    "nintendo": "Nintendo", "switch": "Nintendo",
    "sony": "Sony", "playstation": "Sony", "ps5": "Sony", "ps4": "Sony",
    "thinkpad": "Lenovo", "lenovo": "Lenovo",
    "asus": "ASUS", "rog": "ASUS",
    "dell": "Dell",
    "surface": "Microsoft",
    "kindle": "Amazon",
};

const MODEL_PATTERNS = [
    { re: /iphone\s*(15\s*pro\s*max|15\s*pro|15\s*plus|15|14\s*pro\s*max|14\s*pro|14\s*plus|14|13\s*pro\s*max|13\s*pro|13\s*mini|13|12\s*pro|12|se\d?|11)/i, prefix: "iPhone " },
    { re: /ipad\s*(pro\s*\d*|air\s*\d*|mini\s*\d*|\d+)/i, prefix: "iPad " },
    { re: /macbook\s*(pro\s*\d*|air\s*\d*)/i, prefix: "MacBook " },
    { re: /switch\s*(oled|lite)?/i, prefix: "Switch " },
    { re: /ps(5|4)/i, prefix: "PS" },
    { re: /mate\s*(60\s*pro|60|50\s*pro|50|40\s*pro|40)/i, prefix: "Mate " },
    { re: /pura\s*(70\s*pro|70)/i, prefix: "Pura " },
    { re: /nova\s*(12\s*pro|12|11)/i, prefix: "Nova " },
    { re: /(\u7ea2\u7c73|redmi)\s*(k60\s*pro|k60|k70\s*pro|k70|note\s*\d+)/i, prefix: "" },
    { re: /thinkpad\s*(x1|t14|t16|e14|p14)/i, prefix: "ThinkPad " },
    { re: /surface\s*(pro\s*\d*|laptop\s*\d*|go)/i, prefix: "Surface " },
    { re: /airpods\s*(pro\s*\d*|max|\d*)/i, prefix: "AirPods " },
    { re: /apple\s*watch\s*(ultra|se|s\d|series\s*\d)/i, prefix: "Apple Watch " },
    { re: /kindle\s*(paperwhite|oasis|voyage)/i, prefix: "Kindle " },
];

const CONDITION_PATTERNS = [
    { re: /\u5168\u65b0/, val: "\u5168\u65b0\u672a\u62c6" },
    { re: /99\u65b0/, val: "99\u65b0" },
    { re: /95\u65b0/, val: "95\u65b0" },
    { re: /9\u6210\u65b0/, val: "9\u6210\u65b0" },
    { re: /85\u65b0/, val: "85\u65b0" },
    { re: /8\u6210\u65b0/, val: "8\u6210\u65b0" },
    { re: /7\u6210\u65b0/, val: "7\u6210\u65b0" },
    { re: /\u5168\u529f\u80fd\u6b63\u5e38/, val: "\u529f\u80fd\u5b8c\u597d" },
    { re: /\u65e0\u62c6\u4fee/, val: "\u65e0\u62c6\u4fee" },
    { re: /\u5728\u4fdd/, val: "\u5728\u4fdd" },
    { re: /\u8f7b\u5fae\u4f7f\u7528\u75d5\u8ff9/, val: "\u8f7b\u5fae\u4f7f\u7528\u75d5\u8ff9" },
    { re: /\u65e0\u5212\u75d5/, val: "\u5c4f\u5e55\u65e0\u5212\u75d5" },
];

function autoParse(text) {
    if (!text || text.length < 3) return { brand: "", model: "", condition: "" };
    const lower = text.toLowerCase();
    let brand = "";
    for (const [key, val] of Object.entries(BRAND_MAP)) {
        if (lower.includes(key)) { brand = val; break; }
    }
    let model = "";
    for (const p of MODEL_PATTERNS) {
        const m = text.match(p.re);
        if (m) { model = (p.prefix + m[1].trim().replace(/\s+/g, " ")).trim(); break; }
    }
    let conditions = [];
    for (const p of CONDITION_PATTERNS) {
        if (p.re.test(text)) { conditions.push(p.val); }
    }
    const condition = conditions.join(" | ");
    return { brand, model, condition };
}

createApp({
    data() {
        return {
            page: "home",
            form: { description: "", brand: "", model: "", condition: "" },
            loading: { diagnosis: false, recommend: false, plan: false },
            result: { diagnosis: null, recommend: null, plan: "" },
            error: null,
            autoFilled: { brand: false, model: false, condition: false },
            debounceTimer: null,
            infoPreview: null,
            appearancePreview: null,
            recognizingInfo: false,
            recognizingAppearance: false,
        };
    },
    watch: {
        "form.description"(val) {
            clearTimeout(this.debounceTimer);
            this.debounceTimer = setTimeout(() => {
                const parsed = autoParse(val);
                if (parsed.brand && !this.form.brand) {
                    this.form.brand = parsed.brand;
                    this.autoFilled.brand = true;
                    setTimeout(() => { this.autoFilled.brand = false; }, 1500);
                }
                if (parsed.model && !this.form.model) {
                    this.form.model = parsed.model;
                    this.autoFilled.model = true;
                    setTimeout(() => { this.autoFilled.model = false; }, 1500);
                }
                if (parsed.condition && !this.form.condition) {
                    this.form.condition = parsed.condition;
                    this.autoFilled.condition = true;
                    setTimeout(() => { this.autoFilled.condition = false; }, 1500);
                }
            }, 400);
        },
    },
    methods: {
        renderMarkdown(text) {
            if (!text) return "";
            return marked.parse(text);
        },
        reAutoParse() {
            const parsed = autoParse(this.form.description);
            if (parsed.brand) this.form.brand = parsed.brand;
            if (parsed.model) this.form.model = parsed.model;
            if (parsed.condition) this.form.condition = parsed.condition;
            this.autoFilled.brand = !!parsed.brand;
            this.autoFilled.model = !!parsed.model;
            this.autoFilled.condition = !!parsed.condition;
            setTimeout(() => {
                this.autoFilled.brand = false;
                this.autoFilled.model = false;
                this.autoFilled.condition = false;
            }, 1500);
        },
        async uploadInfoImage(event) {
            const file = event.target.files[0];
            if (!file) return;
            if (!file.type.startsWith("image/")) { this.error = "\u8bf7\u4e0a\u4f20\u56fe\u7247\u6587\u4ef6"; return; }
            this.infoPreview = URL.createObjectURL(file);
            this.recognizingInfo = true;
            this.error = null;
            try {
                const formData = new FormData();
                formData.append("file", file);
                const res = await fetch(API_BASE + "/recognize-info", { method: "POST", body: formData });
                const data = await res.json();
                if (data.success) {
                    if (data.description) this.form.description = data.description;
                    if (data.brand) this.form.brand = data.brand;
                    if (data.model) this.form.model = data.model;
                    this.autoFilled.brand = !!data.brand;
                    this.autoFilled.model = !!data.model;
                    setTimeout(() => { this.autoFilled.brand = false; this.autoFilled.model = false; }, 2000);
                } else { this.error = data.message || "\u4fe1\u606f\u8bc6\u522b\u5931\u8d25"; }
            } catch (e) { this.error = "\u4fe1\u606f\u8bc6\u522b\u5931\u8d25\uff1a" + e.message; }
            this.recognizingInfo = false;
        },
        async uploadAppearanceImage(event) {
            const file = event.target.files[0];
            if (!file) return;
            if (!file.type.startsWith("image/")) { this.error = "\u8bf7\u4e0a\u4f20\u56fe\u7247\u6587\u4ef6"; return; }
            this.appearancePreview = URL.createObjectURL(file);
            this.recognizingAppearance = true;
            this.error = null;
            try {
                const formData = new FormData();
                formData.append("file", file);
                const res = await fetch(API_BASE + "/recognize-appearance", { method: "POST", body: formData });
                const data = await res.json();
                if (data.success) {
                    if (data.condition) this.form.condition = data.condition;
                    if (data.details && this.form.description) {
                        this.form.description += "\n" + data.details;
                    } else if (data.details) {
                        this.form.description = data.details;
                    }
                    this.autoFilled.condition = !!data.condition;
                    setTimeout(() => { this.autoFilled.condition = false; }, 2000);
                } else { this.error = data.message || "\u5916\u89c2\u8bc6\u522b\u5931\u8d25"; }
            } catch (e) { this.error = "\u5916\u89c2\u8bc6\u522b\u5931\u8d25\uff1a" + e.message; }
            this.recognizingAppearance = false;
        },
        clearInfoImage() {
            this.infoPreview = null;
            const input = document.getElementById("info-image-input");
            if (input) input.value = "";
        },
        clearAppearanceImage() {
            this.appearancePreview = null;
            const input = document.getElementById("appearance-image-input");
            if (input) input.value = "";
        },
        go(target) {
            this.error = null;
            if (target === "diagnosis") {
                this.page = "diagnosis";
                
            } else if (target === "recommend") {
                this.page = "recommend";
                
            } else if (target === "plan") {
                this.page = "plan";
                
            } else {
                this.page = "home";
            }
        },
        async runDiagnosis() {
            this.loading.diagnosis = true;
            this.error = null;
            try {
                const res = await fetch(API_BASE + "/diagnose", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(this.form),
                });
                const data = await res.json();
                if (data.success) { this.result.diagnosis = data; }
                else { this.error = data.message || "\u8bca\u65ad\u5931\u8d25"; }
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.diagnosis = false;
        },
        async runRecommend() {
            this.loading.recommend = true;
            this.error = null;
            try {
                const payload = Object.assign({}, this.form);
                if (this.result.diagnosis) { payload.diagnosis = this.result.diagnosis.data; }
                const res = await fetch(API_BASE + "/recommend", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(payload),
                });
                const data = await res.json();
                if (data.success) {
                    this.result.recommend = data;
                    if (data.diagnosis && !this.result.diagnosis) { this.result.diagnosis = { data: data.diagnosis, report: "" }; }
                } else { this.error = data.message || "\u63a8\u8350\u5931\u8d25"; }
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.recommend = false;
        },
        async runPlan() {
            this.loading.plan = true;
            this.error = null;
            this.result.plan = "";
            try {
                const res = await fetch(API_BASE + "/generate-plan", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(this.form),
                });
                const reader = res.body.getReader();
                const decoder = new TextDecoder();
                let buffer = "";
                let currentEvent = "";
                let currentData = "";
                let fullText = "";
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split("\n");
                    buffer = lines.pop();
                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (trimmed.startsWith("event:")) {
                            currentEvent = trimmed.slice(6).trim();
                            currentData = "";
                        } else if (trimmed.startsWith("data:")) {
                            currentData += (currentData ? "\n" : "") + trimmed.slice(5).trim();
                        } else if (trimmed === "") {
                            if (currentEvent === "delta" && currentData) {
                                fullText += currentData;
                            } else if (currentEvent === "end" && currentData) {
                                fullText = currentData;
                            }
                            currentEvent = "";
                            currentData = "";
                        }
                    }
                }
                if (currentEvent === "delta" && currentData) { fullText += currentData; }
                else if (currentEvent === "end" && currentData) { fullText = currentData; }
                this.result.plan = fullText;
            } catch (e) { this.error = "\u7f51\u7edc\u9519\u8bef\uff1a" + e.message; }
            this.loading.plan = false;
        },
    },
}).mount("#app");
""")

# ===== index.html =====
write("frontend/index.html", r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>二手闲置定价智能助手</title>
<script src="https://unpkg.com/vue@3/dist/vue.global.prod.js"></script>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#f0f2f5;min-height:100vh}

.nav{background:linear-gradient(135deg,#667eea,#764ba2);padding:16px 24px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 2px 12px rgba(0,0,0,.15)}
.nav h1{color:#fff;font-size:20px;cursor:pointer}
.nav-tabs{display:flex;gap:8px}
.nav-tab{padding:8px 20px;border-radius:8px;border:none;font-size:14px;font-weight:600;cursor:pointer;transition:all .2s;color:rgba(255,255,255,.7);background:transparent}
.nav-tab:hover{color:#fff;background:rgba(255,255,255,.15)}
.nav-tab.active{color:#764ba2;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.1)}

.page{max-width:900px;margin:24px auto;padding:0 20px}
.card{background:#fff;border-radius:12px;padding:28px;box-shadow:0 2px 12px rgba(0,0,0,.06);margin-bottom:20px}
.card-title{font-size:18px;font-weight:700;color:#333;margin-bottom:20px;padding-bottom:12px;border-bottom:2px solid #667eea;display:flex;align-items:center;gap:8px}

.form-group{margin-bottom:18px}
.form-group label{display:block;margin-bottom:6px;font-weight:600;color:#555;font-size:14px}
.form-group input,.form-group textarea{width:100%;padding:10px 14px;border:2px solid #e0e0e0;border-radius:8px;font-size:14px;transition:border-color .2s}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:#667eea}
.form-group textarea{min-height:90px;resize:vertical}
.row{display:flex;gap:14px}
.row .form-group{flex:1}

.upload-area{border:2px dashed #d0d0d0;border-radius:12px;padding:20px;text-align:center;cursor:pointer;transition:all .2s;position:relative;min-height:100px;display:flex;flex-direction:column;align-items:center;justify-content:center}
.upload-area:hover{border-color:#667eea;background:#f8f9ff}
.upload-icon{font-size:32px;color:#bbb;margin-bottom:6px}
.upload-text{color:#888;font-size:13px}
.upload-text em{color:#667eea;font-style:normal;font-weight:600}
.upload-label{font-size:14px;font-weight:700;color:#555;margin-bottom:8px;text-align:left;width:100%}
.img-preview{max-height:160px;max-width:100%;border-radius:8px;margin:4px 0}
.img-close{position:absolute;top:6px;right:6px;background:rgba(0,0,0,.5);color:#fff;border:none;border-radius:50%;width:24px;height:24px;cursor:pointer;font-size:13px;display:flex;align-items:center;justify-content:center}
.recognizing-mask{position:absolute;inset:0;background:rgba(255,255,255,.85);display:flex;flex-direction:column;align-items:center;justify-content:center;border-radius:12px}

.auto-badge{display:inline-block;background:#e8f5e9;color:#2e7d32;font-size:12px;padding:2px 8px;border-radius:4px;margin-left:8px;animation:fadeBadge 1.5s ease forwards}
@keyframes fadeBadge{0%{opacity:1}70%{opacity:1}100%{opacity:0}}
.reparse-btn{display:inline-block;margin-left:8px;padding:2px 10px;border:1px solid #667eea;border-radius:4px;background:#f0f0ff;color:#667eea;font-size:12px;cursor:pointer;transition:all .2s}
.reparse-btn:hover{background:#667eea;color:#fff}

.btn-row{display:flex;gap:12px;margin-top:20px}
.btn{flex:1;padding:12px 20px;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;transition:all .2s;color:#fff}
.btn-d{background:#667eea}.btn-d:hover{background:#5a6fd6;transform:translateY(-1px)}
.btn-r{background:#764ba2}.btn-r:hover{background:#6a4190;transform:translateY(-1px)}
.btn-p{background:linear-gradient(135deg,#f093fb,#f5576c)}.btn-p:hover{transform:translateY(-1px)}
.btn:disabled{opacity:.5;cursor:not-allowed;transform:none!important}
.btn-back{background:#f0f2f5;color:#555;border:2px solid #e0e0e0;flex:none;padding:10px 24px}
.btn-back:hover{border-color:#667eea;color:#667eea}

.result{padding:8px 0}
.result table{width:100%;border-collapse:collapse;margin:12px 0;background:#fafafa;border-radius:8px;overflow:hidden}
.result th,.result td{padding:10px 14px;text-align:left;border-bottom:1px solid #eee;font-size:14px}
.result th{background:#667eea;color:#fff;font-weight:600}
.result tr:hover{background:#f0f2f5}

.plan-content{line-height:1.8;color:#444}
.plan-content p{margin-bottom:8px}
.plan-content ul,.plan-content ol{margin:8px 0 8px 20px}
.plan-content h1,.plan-content h2,.plan-content h3,.plan-content h4{margin:16px 0 8px;color:#333}

.loading-box{text-align:center;padding:40px 0}
.spinner{display:inline-block;width:32px;height:32px;border:3px solid #e0e0e0;border-top-color:#667eea;border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.loading-text{margin-top:12px;color:#888;font-size:14px}
.empty-hint{text-align:center;padding:60px 0;color:#bbb;font-size:16px}

.upload-row{display:flex;gap:14px;margin-bottom:18px}
.upload-row .upload-col{flex:1}
</style>
</head>
<body>
<div id="app">

<div class="nav">
  <h1 @click="go('home')">&#128230; 二手定价助手</h1>
  <div class="nav-tabs">
    <button class="nav-tab" :class="{active:page==='diagnosis'}" @click="go('diagnosis')">&#128269; 成色诊断</button>
    <button class="nav-tab" :class="{active:page==='recommend'}" @click="go('recommend')">&#128640; 平台推荐</button>
    <button class="nav-tab" :class="{active:page==='plan'}" @click="go('plan')">&#9997;&#65039; 定价策略</button>
  </div>
</div>

<div class="page">

<!-- HOME -->
<div v-if="page==='home'" class="card">
  <div class="card-title">&#128221; 物品信息录入</div>

  <div class="upload-row">
    <div class="upload-col">
      <div class="upload-label">&#128196; 设备信息截图</div>
      <div class="upload-area" @click="$refs.infoInput.click()">
        <input ref="infoInput" id="info-image-input" type="file" accept="image/*" @change="uploadInfoImage" style="display:none">
        <template v-if="infoPreview">
          <img :src="infoPreview" class="img-preview">
          <button class="img-close" @click.stop="clearInfoImage">&times;</button>
        </template>
        <template v-else>
          <div class="upload-icon">&#128247;</div>
          <div class="upload-text"><em>&#128196; 点击上传</em> 设备信息截图<br>（关于本机、系统信息、购买凭证等）</div>
        </template>
        <div v-if="recognizingInfo" class="recognizing-mask">
          <div class="spinner"></div>
          <div style="margin-top:6px;color:#667eea;font-size:13px">AI 识别文字信息...</div>
        </div>
      </div>
    </div>
    <div class="upload-col">
      <div class="upload-label">&#128065; 设备外观照片</div>
      <div class="upload-area" @click="$refs.appearInput.click()">
        <input ref="appearInput" id="appearance-image-input" type="file" accept="image/*" @change="uploadAppearanceImage" style="display:none">
        <template v-if="appearancePreview">
          <img :src="appearancePreview" class="img-preview">
          <button class="img-close" @click.stop="clearAppearanceImage">&times;</button>
        </template>
        <template v-else>
          <div class="upload-icon">&#128247;</div>
          <div class="upload-text"><em>&#128065; 点击上传</em> 设备外观照片<br>（正面、屏幕、边角等特写）</div>
        </template>
        <div v-if="recognizingAppearance" class="recognizing-mask">
          <div class="spinner"></div>
          <div style="margin-top:6px;color:#667eea;font-size:13px">AI 评估外观成色...</div>
        </div>
      </div>
    </div>
  </div>

  <div class="form-group">
    <label>物品描述</label>
    <textarea v-model="form.description" placeholder="可手动输入或通过左侧截图自动识别"></textarea>
  </div>
  <div class="row">
    <div class="form-group">
      <label>品牌 <span v-if="autoFilled.brand" class="auto-badge">&#9989; 自动识别</span></label>
      <input v-model="form.brand" placeholder="自动识别，可手动修改">
    </div>
    <div class="form-group">
      <label>型号 <span v-if="autoFilled.model" class="auto-badge">&#9989; 自动识别</span></label>
      <input v-model="form.model" placeholder="自动识别，可手动修改">
    </div>
  </div>
  <div class="form-group">
    <label>成色补充 <span v-if="autoFilled.condition" class="auto-badge">&#9989; 自动识别</span> <span class="reparse-btn" @click="reAutoParse">&#128260; 重新识别</span></label>
    <input v-model="form.condition" placeholder="自动识别，可手动修改">
  </div>
  <div class="btn-row">
    <button class="btn btn-d" @click="go('diagnosis')" :disabled="!form.description">&#128269; 成色诊断</button>
    <button class="btn btn-r" @click="go('recommend')" :disabled="!form.description">&#128640; 平台推荐</button>
    <button class="btn btn-p" @click="go('plan')" :disabled="!form.description">&#9997;&#65039; 定价策略</button>
  </div>
</div>

<!-- DIAGNOSIS PAGE -->
<div v-if="page==='diagnosis'">
  <div class="card">
    <div class="card-title">&#128269; 成色诊断报告
      <button class="btn btn-back" @click="go('home')" style="margin-left:auto">&#8592; 返回</button>
    </div>
    <div v-if="loading.diagnosis" class="loading-box">
      <div class="spinner"></div>
      <div class="loading-text">正在诊断成色...</div>
    </div>
    <div v-else-if="result.diagnosis" class="result" v-html="renderMarkdown(result.diagnosis.report)"></div>
    <div v-else class="empty-hint">暂无诊断结果，请先在首页填写物品信息</div>
  </div>
</div>

<!-- RECOMMEND PAGE -->
<div v-if="page==='recommend'">
  <div class="card">
    <div class="card-title">&#128640; 交易平台推荐
      <button class="btn btn-back" @click="go('home')" style="margin-left:auto">&#8592; 返回</button>
    </div>
    <div v-if="loading.recommend" class="loading-box">
      <div class="spinner"></div>
      <div class="loading-text">正在推荐平台...</div>
    </div>
    <div v-else-if="result.recommend" class="result" v-html="renderMarkdown(result.recommend.report)"></div>
    <div v-else class="empty-hint">暂无推荐结果，请先在首页填写物品信息</div>
  </div>
</div>

<!-- PLAN PAGE -->
<div v-if="page==='plan'">
  <div class="card">
    <div class="card-title">&#9997;&#65039; 定价策略方案
      <button class="btn btn-back" @click="go('home')" style="margin-left:auto">&#8592; 返回</button>
    </div>
    <div v-if="loading.plan && !result.plan" class="loading-box">
      <div class="spinner"></div>
      <div class="loading-text">正在生成定价策略...</div>
    </div>
    <div v-else-if="result.plan" class="plan-content" v-html="renderMarkdown(result.plan)"></div>
    <div v-else class="empty-hint">暂无定价策略，请先在首页填写物品信息</div>
  </div>
</div>

<div v-if="error" style="background:#fdf2f2;color:#e74c3c;padding:14px 20px;border-radius:8px;margin-bottom:20px;font-size:14px">&#10060; {{ error }}</div>

</div>
</div>

<script src="/static/app.js"></script>
</body>
</html>
""")

# Verify Python files
for f in ["app/agents/recognizer.py", "app/routes/api.py"]:
    path = os.path.join(BASE, f)
    content = open(path, encoding="utf-8").read()
    try:
        compile(content, f, "exec")
        print(f"VERIFY {f}: OK")
    except SyntaxError as e:
        print(f"VERIFY {f}: FAIL - {e}")

print("\nAll done!")