import os, sys
BASE = "/home/wjx1202/projects/secondhand-pricing-assistant"
os.chdir(BASE)

errors = []

# 1. CSV 格式检查
print("=" * 60)
print("1. CSV 格式详细检查")
print("=" * 60)
with open("app/knowledge/secondhand_data.csv", "r", encoding="utf-8") as f:
    lines = f.readlines()
header = lines[0].strip()
print(f"  表头: {header}")
cols = header.split(",")
print(f"  列数: {len(cols)}")
if len(cols) < 3:
    errors.append(f"CSV 列数异常({len(cols)})，可能分隔符不对")
    print(f"  [FAIL] 列数={len(cols)}，可能不是逗号分隔")
    # try tab
    cols2 = header.split("\t")
    print(f"  Tab分隔列数: {len(cols2)}")
else:
    print(f"  [OK] 列名: {cols}")
# check data rows
for i, line in enumerate(lines[1:], 2):
    row_cols = line.strip().split(",")
    if len(row_cols) != len(cols):
        print(f"  [WARN] 第{i}行列数={len(row_cols)}(期望{len(cols)})")

# 2. 环境变量名一致性检查
print()
print("=" * 60)
print("2. 环境变量名一致性检查")
print("=" * 60)
import re
for pyfile in ["app/agents/recommend.py", "app/agents/plan.py", "app/tools/price_lookup.py"]:
    with open(pyfile, "r") as f:
        content = f.read()
    env_vars = set(re.findall(r'os\.getenv\("([^"]+)"', content))
    print(f"  {pyfile}: {sorted(env_vars)}")

# 3. diagnosis.py 运行时逻辑检查
print()
print("=" * 60)
print("3. diagnosis.py 关键类/方法检查")
print("=" * 60)
sys.path.insert(0, BASE)
from app.agents.diagnosis import DiagnosisAgent, DiagnosisResult
agent = DiagnosisAgent(
    description="测试", brand="Apple", model="iPhone 14", condition="99新"
)
result = agent.diagnose()
print(f"  diagnose() 返回类型: {type(result).__name__}")
d = result.to_dict()
print(f"  to_dict() keys: {list(d.keys())}")
report = agent.generate_report()
print(f"  generate_report() 长度: {len(report)}")
if "综合评级" not in d:
    errors.append("diagnosis.py to_dict() 缺少 '综合评级' key")
    print("  [FAIL] 缺少 '综合评级'")
else:
    print(f"  [OK] 综合评级: {d['综合评级']}")

# 4. recommend.py 关键方法检查
print()
print("=" * 60)
print("4. recommend.py 关键类/方法检查")
print("=" * 60)
from app.agents.recommend import RecommendAgent, PlatformRecommendation
agent2 = RecommendAgent(
    description="iPhone 14 Pro", brand="Apple", model="iPhone 14 Pro",
    condition="99新", diagnosis_result={"综合评级": "S级：极品", "外观成色": 9, "功能完好性": 10}
)
price = agent2._estimate_price()
print(f"  _estimate_price(): {price}")
cat = agent2._infer_category()
print(f"  _infer_category(): {cat}")
fallback = agent2._rule_based_fallback(price)
print(f"  _rule_based_fallback(): {len(fallback)} 个推荐")
for r in fallback:
    print(f"    #{r.rank} {r.name}: {r.price_range}")

# 5. plan.py 检查
print()
print("=" * 60)
print("5. plan.py 函数签名检查")
print("=" * 60)
from app.agents.plan import generate_plan_stream, SYSTEM_PROMPT, USER_PROMPT_TEMPLATE
import inspect
sig = inspect.signature(generate_plan_stream)
print(f"  generate_plan_stream{sig}")
print(f"  SYSTEM_PROMPT 长度: {len(SYSTEM_PROMPT)}")
print(f"  是否含乱码: {'是' if any(c in SYSTEM_PROMPT for c in '缁鍏澶鍔姣瀹') else '否'}")

# Summary
print()
print("=" * 60)
print("总结")
print("=" * 60)
if errors:
    print(f"发现 {len(errors)} 个问题：")
    for i, e in enumerate(errors, 1):
        print(f"  {i}. {e}")
else:
    print("所有检查通过！")