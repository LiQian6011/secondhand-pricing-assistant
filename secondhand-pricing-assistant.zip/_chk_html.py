with open("frontend/index.html", "r", encoding="utf-8") as f:
    content = f.read()
garbled = [c for c in "缁鍏澶鍔姣瀹" if c in content]
if garbled:
    print(f"[FAIL] index.html 包含乱码字符: {garbled}")
else:
    print("[OK] index.html 无乱码")
# Check for missing commas in JS objects (rough check)
import re
# Check Vue template structure
if 'id="app"' in content:
    print("[OK] Vue app 挂载点存在")
else:
    print("[FAIL] 缺少 id=app")
if 'marked' in content:
    print("[OK] marked.js 引用存在")
else:
    print("[FAIL] 缺少 marked.js")
if 'app.js' in content:
    print("[OK] app.js 引用存在")
else:
    print("[FAIL] 缺少 app.js 引用")
print(f"文件大小: {len(content)} bytes")