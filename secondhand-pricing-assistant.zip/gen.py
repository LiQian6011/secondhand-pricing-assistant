import os
base = /home/wjx1202/projects/secondhand-pricing-assistant
os.makedirs(base, exist_ok=True)
files = {}

files[app/tools/price_lookup.py] = "import os
from langchain.tools import BaseTool
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage


class PriceLookupTool(BaseTool):
    """二手物品价格查询工具：通过大模型查询当前市场参考价"""

    name: str = price_lookup
    description: str = (
        查询二手物品在当前市场的参考价格区间。
        输入应包含物品品牌、型号、成色等描述信息，
        输出为市场参考价格区间（元）。
    )

    def _run(self, query: str) -> str:
        api_key = os.getenv(OPENAI_API_KEY)
        base_url = os.getenv(OPENAI_BASE_URL, https://api.openai.com/v1)
        model = os.getenv(OPENAI_MODEL, gpt-4o-mini)
        if not api_key:
            return 错误：未配置
