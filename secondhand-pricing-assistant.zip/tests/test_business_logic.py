import asyncio
import re

from app.agents.diagnosis import DiagnosisAgent
from app.agents.recommend import RecommendAgent
from app.agents.plan import generate_plan_stream


def test_diagnosis_report_uses_required_dimensions_and_grade():
    agent = DiagnosisAgent(
        description="iPhone 14 Pro 256G 国行 在保3个月 电池健康92% 外观无划痕 功能正常 箱说全",
        brand="Apple",
        model="iPhone 14 Pro",
        condition="99新",
    )
    result = agent.diagnose()

    assert result.appearance_score >= 8
    assert result.functionality_score >= 8
    assert result.accessories_score >= 8
    assert result.warranty_score >= 8
    assert "S级" in result.overall_grade or "A级" in result.overall_grade

    report = agent.generate_report()
    assert "| 外观完整性 |" in report
    assert "| 功能可用性 |" in report
    assert "| 配件齐全度 |" in report
    assert "| 保修与来源 |" in report
    assert "核心卖点" in report or "建议定价区间" in report


def test_recommendation_uses_knowledge_results():
    agent = RecommendAgent(
        description="iPhone 14 Pro 256G 国行 在保3个月 电池健康92% 外观无划痕 功能正常 箱说全",
        brand="Apple",
        model="iPhone 14 Pro",
        condition="99新",
        diagnosis_result={"综合评级": "S级：极品"},
        knowledge_results=[
            {"document": "品类: 手机 | 品牌: Apple | 型号: iPhone 14 Pro 256G | 成色: 99新 | 参考价低: 5800 | 参考价高: 6500 | 平台: 闲鱼 | 备注: 国行在保",
             "metadata": {"平台": "闲鱼", "参考价低": "5800", "参考价高": "6500"}}
        ],
    )
    recs = agent.recommend()
    assert len(recs) >= 1
    assert recs[0].name
    assert any("元" in recs[0].price_range for _ in [0])


def test_recommendation_for_vivo_s16_pro_is_realistic():
    agent = RecommendAgent(
        description="vivo S16 Pro 256G 95新 背板有细微划痕 机身无磕碰",
        brand="vivo",
        model="S16 Pro",
        condition="95新",
        diagnosis_result={"综合评级": "A级：良好"},
        knowledge_results=[
            {"document": "品类: 手机 | 品牌: vivo | 型号: S16 Pro 256G | 成色: 95新 | 参考价低: 2300 | 参考价高: 2800 | 平台: 闲鱼 | 备注: 95新",
             "metadata": {"平台": "闲鱼", "参考价低": "2300", "参考价高": "2800"}},
            {"document": "品类: 手机 | 品牌: vivo | 型号: S16 Pro 256G | 成色: 95新 | 参考价低: 2100 | 参考价高: 2500 | 平台: 转转 | 备注: 实拍",
             "metadata": {"平台": "转转", "参考价低": "2100", "参考价高": "2500"}},
            {"document": "品类: 手机 | 品牌: vivo | 型号: S16 Pro 256G | 成色: 95新 | 参考价低: 1800 | 参考价高: 2300 | 平台: 京东拍拍 | 备注: 快速到账",
             "metadata": {"平台": "京东拍拍", "参考价低": "1800", "参考价高": "2300"}},
        ],
    )
    recs = agent.recommend()
    assert len(recs) >= 3
    prices = []
    for r in recs:
        m = re.search(r"(\d+)\s*[-~]\s*(\d+)", r.price_range)
        if m:
            prices.append((int(m.group(1)), int(m.group(2))))
    assert prices
    assert max(high for _, high in prices) <= 5000
    assert len({r.name for r in recs}) >= 3
    assert any("闲鱼" in r.name for r in recs)
    assert any("转转" in r.name for r in recs)
    assert any("京东拍拍" in r.name for r in recs)


async def _collect_plan_stream():
    events = []
    async for event in generate_plan_stream(
        description="iPhone 14 Pro 256G 国行 在保3个月 电池健康92% 外观无划痕 功能正常 箱说全",
        brand="Apple",
        model="iPhone 14 Pro",
        condition="99新",
        platform_data="闲鱼：5800-6500元\n转转：5600-6100元",
    ):
        events.append(event)
    return events


def test_plan_stream_returns_real_strategy_content():
    events = asyncio.run(_collect_plan_stream())
    merged = "\n".join(str(e.get("data", "")) for e in events if isinstance(e, dict))
    assert "最终建议售价" in merged or "定价策略" in merged
    assert "商品文案" in merged or "卖点" in merged
    assert "交易建议" in merged
