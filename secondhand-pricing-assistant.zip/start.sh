#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8000}"

cleanup_port() {
  local pids=""

  if command -v lsof >/dev/null 2>&1; then
    pids="$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)"
  elif command -v ss >/dev/null 2>&1; then
    pids="$(ss -lntp 2>/dev/null | awk -v port=":${PORT}" '$4 ~ port {print $NF}' | sed -E 's/.*pid=([0-9]+).*/\1/' | sort -u || true)"
  else
    echo "[start.sh] 未找到 lsof/ss，无法自动清理端口 ${PORT}"
    return 0
  fi

  if [ -n "$pids" ]; then
    echo "[start.sh] 发现端口 ${PORT} 被占用，正在清理进程: ${pids}"
    kill -9 $pids || true
  fi
}

restart_server() {
  while true; do
    echo "[start.sh] 正在启动服务: http://${HOST}:${PORT}"
    uv run python -m uvicorn app.main:app --host "$HOST" --port "$PORT"

    echo "[start.sh] 服务已退出，等待 2 秒后自动重启..."
    sleep 2
  done
}

cleanup_port

if ! command -v uv >/dev/null 2>&1; then
  echo "[start.sh] 未找到 uv，请先安装 uv 或在项目环境中使用它。"
  exit 1
fi

restart_server
