import requests
import json

BASE = "http://localhost:8000/api"

print("=== 1. 诊断 ===")
r = requests.post(BASE + "/diagnose", json={
    "description": "iPhone 14 Pro 256G 国行 在保到2025年12月 电池健康98% 屏幕无划痕 全功能正常 箱说全",
    "brand": "Apple",
    "model": "iPhone 14 Pro",
    "condition": "99新",
}, timeout=30)
d = r.json()
print("success:", d.get("success"))

print("\n=== 2. 推荐 ===")
r = requests.post(BASE + "/recommend", json={
    "description": "iPhone 14 Pro 256G 国行 在保到2025年12月 电池健康98%",
    "brand": "Apple",
    "model": "iPhone 14 Pro",
    "condition": "99新",
}, timeout=30)
d = r.json()
print("success:", d.get("success"))

print("\n=== 3. 定价策略 SSE ===")
r = requests.post(BASE + "/generate-plan", json={
    "description": "iPhone 14 Pro 256G 国行 在保到2025年12月 电池健康98%",
    "brand": "Apple",
    "model": "iPhone 14 Pro",
    "condition": "99新",
}, stream=True, timeout=60)

collected = ""
for line in r.iter_lines(decode_unicode=True):
    if line and line.startswith("data:"):
        payload = line[5:].strip()
        if not payload or payload == "[DONE]":
            continue
        try:
            event = json.loads(payload)
            if event.get("event") == "delta":
                collected += event.get("data", "")
            elif event.get("event") == "end":
                collected = event.get("data", collected)
        except:
            pass

print(f"SSE collected {len(collected)} chars")
print("First 200:", collected[:200])