import chromadb
print("chromadb:", chromadb.__version__)
try:
    from chromadb.utils.embedding_functions import DefaultEmbeddingFunction
    print("DefaultEmbeddingFunction: OK")
except Exception as e:
    print("DefaultEmbeddingFunction:", e)
try:
    from chromadb.utils.embedding_functions.onnx_mini_lm_l6_v2 import ONNXMiniLM_L6_V2
    print("ONNXMiniLM_L6_V2: OK")
except Exception as e:
    print("ONNXMiniLM_L6_V2:", e)