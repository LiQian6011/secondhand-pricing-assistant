def main() -> None:
    print("Hello from secondhand-pricing-assistant!")
